/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50505
 Source Host           : localhost
 Source Database       : 66173

 Target Server Type    : MySQL
 Target Server Version : 50505
 File Encoding         : utf-8

 Date: 12/22/2015 23:35:18 PM
*/

SET NAMES utf8;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
--  Table structure for `sell_audit_logs`
-- ----------------------------
DROP TABLE IF EXISTS `sell_audit_logs`;
CREATE TABLE `sell_audit_logs` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(15) DEFAULT NULL COMMENT '用户id',
  `channel_id` int(5) DEFAULT '1' COMMENT '渠道ID',
  `game_id` int(11) DEFAULT NULL COMMENT '游戏ID',
  `serv_id` int(5) DEFAULT NULL COMMENT '区服ID',
  `type` smallint(2) NOT NULL DEFAULT '0' COMMENT '商品类型： 4、账号 5、游戏币 6、道具  0、默认',
  `create_time` varchar(20) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `status` smallint(2) NOT NULL DEFAULT '2' COMMENT '审核状态：1、通过  2、拒绝',
  `operation_id` int(15) NOT NULL COMMENT '操作人ID',
  `desc` varchar(255) DEFAULT NULL COMMENT '描述',
  `end_time` varchar(20) NOT NULL DEFAULT '0' COMMENT '结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

SET FOREIGN_KEY_CHECKS = 1;
