$(".page_top_left2").click(function () {
    history.back()
});
var u = navigator.userAgent;
var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
if(isAndroid){
    $(".price_collection .price").css("font-size","1.1rem");
    $(".price_collection .price").css("margin-top","0.32rem")
}else{
    $(".price_collection .price").css("font-size","1rem");
    $(".price_collection .price").css("margin-top","0.35rem")
}
$(".clear_all_good").click(function () {
    $(".alert_two").show();
    $(".mask").show();
});
$(".alert_two_cancel").click(function () {
    $(".alert_two").hide();
    $(".mask").hide();
});
$(".collect_footer").click(function () {
    $(".alert_one").show();
    $(".mask").show();
});
$(".alert_one_cancel").click(function () {
    $(".alert_one").hide();
    $(".mask").hide();
});
$(document).ready(function () {
    $(".alert_one").css("display","none");
    $(".alert_two").css("display","none");
    $(".mask").css("display","none");
    $(".allChecked").css("display","none");
    $(".check_icon").css("display","none");
    $(".collect_footer").css("display","none");
    $(".collection_list").css("margin-top","60px")
});
//=====================
$(".login_my2").click(function () {
    if ($(".check_icon").is(":hidden")){
        $(".check_icon").show();
        $(".collect_footer").show();
        $(".login_my2").html("取消");
        arr=[];
        $(".check_icon .check_img").show();
        $(".check_icon .check_img2").hide();
        $(".check_img_11").show();
        $(".check_img_112").hide();
        $(".allChecked").show();
        $(".collection_list").css("margin-top","0px")
        $(".check_item").css("margin-left","4%")
    }else {
        $(".check_icon").hide();
        $(".collect_footer").hide();
        $(".login_my2").html("编辑");
        $(".allChecked").hide();
        $(".collection_list").css("margin-top","60px")
        $(".check_item").css("margin-left","10%")
    }
});
$(".check_icon .check_img").each(function () {
    $(this).click(function () {
        if($(this).is(":hidden")){
            $(this).show();
            $(this).siblings().hide()
        }else {
            $(this).siblings().show();
            $(this).hide();
        }
    })
});
$(".check_icon .check_img2").each(function () {
    $(this).click(function () {
        if($(this).is(":hidden")){
            $(this).show();
            $(this).siblings().hide()
        }else {
            $(this).siblings().show();
            $(this).hide();
        }
    })
});
arr=[]; //定义删除空数组开始============
$(".allChecked_all").click(function () {
    if($(".check_img_11").is(":hidden")){
        $(".check_img_11").show();
        $(".check_img_112").hide();
        $(".check_icon .check_img").show();
        $(".check_icon .check_img2").hide();
        arr=[];  //取消全选中
    }else{
        $(".check_img_112").show();
        $(".check_icon .check_img2").show();
        $(".check_icon .check_img").hide();
        $(".check_img_11").hide();
        $(".collection_list>.collection_list_item").each(function ( ) {
            var id=$(this).attr("data-id");
            arr.push(id);  //全选中
        })
    }
});
$(".check_img").click(function(){
    var id=$(this).attr("data-id");
    arr.push(id);
});
$(".check_img2").click(function(){
    var id=$(this).attr("data-id");
    arr.splice( arr.indexOf(id),1);
});
//base64解码
$(".alert_one_confirm").click(function () {
    $(".alert_one").hide();
    $(".mask").hide();
    var pagehash=$.trim($(".pagehash").val());
    var user_id=$.trim($(".user_id").val());
    $.ajax({
        url: "/delCollect",
        type: "POST",
        data: {
            user_id:user_id,
            goods_list:arr,
            pagehash:pagehash
        },
        dataType: "text",
        success: function (res) {
            var json=$.parseJSON(base64decode(res.substr(1)));
            if(json.code==1){
                window.location.reload();
            }else{
                alert(json.msg);
            }
        }
    })
});
//清空失效接口
$(".alert_two_confirm").click(function () {
    $(".alert_two").hide();
    $(".mask").hide();
    var user_id=$.trim($(".user_id").val());
    var pagehash=$.trim($(".pagehash").val());
    $.ajax({
        url: "/clearInvalid",
        type: "POST",
        data: {
            user_id:user_id,
            pagehash:pagehash
        },
        dataType: "text",
        success: function (res) {
            // res =JSON.parse(res)
          var json=$.parseJSON(base64decode(res.substr(1)));
            if(json.code==1){
                window.location.reload();
            }else{
                alert(json.msg);
            }
        }
    })
});

//==================