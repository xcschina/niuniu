$(".page_top_left2").click(function () {
    history.back()
})
function isphone2(inputString)
{
    var partten = /^1[3,5,8]\d{9}$/;
    var fl=false;
    if(partten.test(inputString))
    {
        return true;
    }
    else
    {
        return false;
    }
}
var countdown=60;
function sendmsg(){
    if(countdown==0){
        $(".phone_input_right").html("获取验证码");
        $(".phone_input_right").attr("disabled",false);
        countdown=60;
        return false;
    }
    else{
        $(".phone_input_right").html(countdown+"s");
        $(".phone_input_right").attr("disabled",true);
        countdown--;
    }
    setTimeout(function(){
        sendmsg();
    },1000);
}
$(".phone_number").bind("input propertychange",function(event){
    $(".input_name").blur(function(){
        if($(".phone_number").val()!=""&&$(".phone_code").val()!=""){
            $(".save_btn").css("background","#f96652")
        }
    });
});
$(".phone_code").bind("input propertychange",function(event){
    if($(".phone_number").val()!=""&&$(".phone_code").val()!=""){
        $(".save_btn").css("background","#f96652");
    }
});
function getCode() { //获取验证码
    if ($.trim($('.phone_number').val()).length == 0) {
        $(".tips_message").show();
        $(".tips_message").html("提示：请输入手机号！");
        $('.phone_number').focus();
    }
    else if(isphone2($.trim($('.phone_number').val())) == false){
        $(".tips_message").show();
        $(".tips_message").html("提示：非法的手机号！");
        $('.phone_number').val("");
    }else{
        $(".tips_message").html("");
        sendmsg();
        var pagehash=$.trim($(".pagehash").val());
        var mobile=$.trim($(".phone_number").val());
        $.ajax({
            url: "trading_center.php?act=sms_code",
            type: "POST",
            data: {
                mobile:mobile,
                pagehash:pagehash
            },
            dataType: "text",
            success: function (res) {
                var json=$.parseJSON(base64decode(res.substr(1)));
                if(json.code==1){
                    alert(json.msg);
                }else{
                    alert(json.msg);
                }
            }
        })
    }
}
$(".save_btn").click(function () {   //点击保存
    if($.trim($(".phone_number").val())==""||$.trim($(".phone_code").val())==""){
        $(".tips_message").show();
        $(".tips_message").html("提示：验证码或者手机号不能为空！");
    }else{
        $(".phone_message").html("");
        var mobile=$.trim($(".phone_code").val());
        var sms_code=$.trim($(".phone_number").val());
        var pagehash=$.trim($(".pagehash").val());
        $.ajax({
            url: "/doPhoneBind",
            type: "POST",
            data: {
                mobile:mobile,
                sms_code:sms_code,
                pagehash:pagehash
            },
            dataType: "text",
            success: function (res) {
                var json=$.parseJSON(base64decode(res.substr(1)));
                if(json.code==1){
                    alert(json.msg);
                    window.location.reload();
                }else{
                    alert(json.msg)
                }
            }
        })
    }
})