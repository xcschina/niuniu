$(".page_top_left2").click(function () {
   window.location.href = "/accountCenter"
});
$(document).ready(function () {
    $(".close_div_pay").css("display","none");
    $(".mask2").css("display","none");
    $(".close_div_pay2").css("display","none");
});
$(".close_pay").click(function () {
    $(".close_div_pay").show();
    $(".mask2").show();
});
$(".close_yes_x").click(function () {
    $(".close_div_pay").hide();
    $(".mask2").hide();
});
$(".cancel").click(function () {
    $(".mask2").hide();
    $(".close_div_pay2").hide();
});
$(".confirm_Receive").click(function () {
    $(".mask2").show();
    $(".close_div_pay2").show();
});
$(".paylist_number").each(function () {
    if ($(this).text().length>20) {
        var text = $(this).text()
            // .substring(0, 20) + "...";
        $(this).html(text);
    }else{
        var text = $(this).text();
        $(this).html(text);
    }
});
index = 1;
$(".reason_li").click(function () {
    $(this).children("div").removeClass("none_yes");
    $(this).siblings().children("div").addClass("none_yes");
    index=$(this).index()+1;
    console.log(index);
});
//关闭交易接口
$(".close_yes_y").click(function () {
    $(".close_div_pay").hide();
    $(".mask2").hide();
    var id=$(".close_pay").attr("data-id");
    var type=index;
    $.ajax({
        url: "/closeTrade",
        type: "POST",
        data: {
            id:id,
            type:type
        },
        dataType: "text",
        success: function (res) {
            var json=$.parseJSON(base64decode(res.substr(1)));

            if(json.code==1){
                window.location.reload();
            }else{
                alert(json.msg);
            }
        }
    })
});
//确认收货接口
$(".comfirm").click(function () {
    var id=$(".confirm_Receive").attr("data-id");
    $(".close_div_pay2").hide();
    $(".mask2").hide();
    console.log(id);
    $.ajax({
        url: "/confirmTrade",
        type: "POST",
        data: {
            id:id,
        },
        dataType: "text",
        success: function (res) {
            var json=$.parseJSON(base64decode(res.substr(1)));
            if(json.code==1){
                window.location.reload();
            }else{
                alert(json.msg);
            }
        }
    })
});