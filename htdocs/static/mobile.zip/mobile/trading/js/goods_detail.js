$(".page_top_left2").click(function () {
    history.back()
});
var u = navigator.userAgent;
var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端
if(isAndroid){
    $(".icon_txt").css("margin","0.82rem 0 0.47rem 0");
    $(".price_collection2 .price").css("margin-top","0.45rem");
    // $(".icon_img2").css("margin","0.85rem 5px");
    $(".price_collection2 .Stock").css("margin-top","0.6rem")
}else{
    $(".price_collection2 .price").css("margin-top","0.265rem");
    $(".price_collection2 .Stock").css("margin-top","0.5rem");
    // $(".icon_img2").css("margin","0.96rem 5px");
    $(".icon_txt").css("margin","0.73rem 0 0.47rem 0")
}
var swiper1 = new Swiper('.swiper-container', {
    pagination: '.swiper-pagination',
    autoplay:3000,
    crossFade: true ,
    preloadImages: false,
    lazyLoading: true,
    paginationClickable: true,
    autoplayDisableOnInteraction: false
});
$(document).ready(function () {
    var h=window.innerHeight-350+"px";
    $(".fenxiang_img_arrow2 img").css("margin-top",h)
    console.log(h);
    $(".tab_contant_two").hide();
    var len = $(".type_name_title").text();
    var len2 = $(".type_name_title_game_coin").text();
    if(len2.length>20){
        $(".type_name_title_game_coin").css("margin-top","18px");
        $(".good_top_left_x").css("margin-top","3.5%");
    }else{
        $(".type_name_title_game_coin").css("margin-top","0");
        $(".good_top_left_x").css("margin-top","1.5%");
    }

    if(len.length>15){
        $(".type_name_title").css("margin-top","18px");
        $(".good_top_left_x").css("margin-top","3.5%");
    }else{
        $(".type_name_title").css("margin-top","0");
        $(".good_top_left_x").css("margin-top","1.5%");
    }
});
$(".tab_one").click(function () {
    $(".tab_one").addClass("style_color");
    $(".tab_two").removeClass("style_color");
    $(".tab_contant_one").show();
    $(".tab_contant_two").hide();
});
$(".tab_two").click(function () {
    $(".tab_two").addClass("style_color");
    $(".tab_one").removeClass("style_color");
    $(".tab_contant_two").show();
    $(".tab_contant_one").hide();
});
//判断是否是移动设备打开。browser代码在下面
var ua = navigator.userAgent.toLowerCase();
if (ua.match(/MicroMessenger/i) == "micromessenger") {
    $(".enjoy_icon").click(function () {
        $(".fenxiang_img_arrow").fadeIn(300);
    })
    $(".fenxiang_img_arrow").click(function () {
        $(".fenxiang_img_arrow").fadeOut(300)
    })
}
else if (ua.match(/WeiBo/i) == "weibo") {
    $(".enjoy_icon").click(function () {
        $(".fenxiang_img_arrow").fadeIn(300);
    })
    $(".fenxiang_img_arrow").click(function () {
        $(".fenxiang_img_arrow").fadeOut(300)
    })
}
else if (ua.match(/QQ/i) == "qq") {
    $(".enjoy_icon").click(function () {
        $(".fenxiang_img_arrow").fadeIn(300);
    })
    $(".fenxiang_img_arrow").click(function () {
        $(".fenxiang_img_arrow").fadeOut(300)
    })
}else{
    $(".enjoy_icon").click(function () {
        $(".fenxiang_img_arrow2").fadeIn(300);
    })
    $(".fenxiang_img_arrow2").click(function () {
        $(".fenxiang_img_arrow2").fadeOut(300)
    })
}
//=============================
$(".good_detail_top_right").click(function () {
    if($('.collect_img').is(":hidden")){
        var id=$(".ididid").val(); //取消收藏接口
        console.log(id)
        $.ajax({
            url: "/cancleCollect/"+id,
            type: "get",
            dataType: "text",
            success: function (res) {
                var json=$.parseJSON(base64decode(res.substr(1)));
                if(json.code==1){
                    // alert(json.msg)
                    console.log("取消收藏")
                    $('.collect_img2').hide();
                    $('.collect_img').show();
                    $(".collect_text").html("收藏")
                }else{
                    alert(json.msg)
                }
            }
        })
    }else{
        var id=$(".ididid").val(); //收藏接口
        //收藏接口
        $.ajax({
            url: "/updateCollect/"+id,
            type: "get",
            dataType: "text",
            success: function (res) {
                var json=$.parseJSON(base64decode(res.substr(1)));
                if(json.code==1){
                    // alert(json.msg)
                    console.log("收藏")
                    $('.collect_img2').show();
                    $('.collect_img').hide();
                    $(".collect_text").html("已收藏")
                }else{
                    window.location.href=json.url;

                }
            }
        })
    }
});