$(".top_left").click(function () {
    history.back()
})
$(".pay_btn").click(function () {
    $(".pay_btn").css("background","#f96652");
    var agreement;
    if($(".agree_txt").is(":hidden")){
        agreement=0
    }else{
        agreement=1
    }
    //所需参数如下
    var pagehash=$.trim($(".pagehash").val());
    var order_id=$.trim($(".order_id").val());
    var pay_mode=$.trim($(".pay_mode").val());
    if(pay_mode==1){
        $(".cheeck_img_img").show();
    }
    if($(".cheeck_img_img").is(":hidden")){
        pay_mode=5
    }else {
        pay_mode=1
    };
    $.ajax({
        url: "/doContinuePay",
        type: "POST",
        data: {
            pagehash:pagehash,
            order_id: order_id,
            pay_mode:pay_mode
        },
        dataType: "text",
        success: function (res) {
            var json=$.parseJSON(base64decode(res.substr(1)));
            if(json.code==1){
                window.location.href = json.url;
            }else{
                alert(json.msg)
            }
        }
    })

});
$(".label_agree").click(function () {
    if($(".agree_txt").is(":hidden")){
        $(".agree_txt").show();
        $(".agree_txt4").hide()
    }else{
        $(".agree_txt4").show();
        $(".agree_txt").hide()
    }
});
function aaa() {
    if($(".cheeck_img_img").is(":hidden")){
        $(".cheeck_img_img").show();
        $(".cheeck_img_img2").hide();
        $(".cheeck_img_img3").hide();
        $(".cheeck_img_img4").show();
    }
}
function bbb() {
    if($(".cheeck_img_img3").is(":hidden")){
        $(".cheeck_img_img2").show();
        $(".cheeck_img_img").hide();
        $(".cheeck_img_img3").show();
        $(".cheeck_img_img4").hide();
    }
}
var base64DecodeChars = new Array(
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63,
    52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1,
    -1, 0, 1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1,
    -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1);

function base64decode(str) {
    var c1, c2, c3, c4;
    var i, len, out;
    len = str.length;
    i = 0;
    out = "";
    while(i < len) {
        /* c1 */
        do {
            c1 = base64DecodeChars[str.charCodeAt(i++) & 0xff];
        } while(i < len && c1 == -1);
        if(c1 == -1)
            break;
        /* c2 */
        do {
            c2 = base64DecodeChars[str.charCodeAt(i++) & 0xff];
        } while(i < len && c2 == -1);
        if(c2 == -1)
            break;
        out += String.fromCharCode((c1 << 2) | ((c2 & 0x30) >> 4));
        /* c3 */
        do {
            c3 = str.charCodeAt(i++) & 0xff;
            if(c3 == 61)
                return out;
            c3 = base64DecodeChars[c3];
        } while(i < len && c3 == -1);
        if(c3 == -1)
            break;
        out += String.fromCharCode(((c2 & 0XF) << 4) | ((c3 & 0x3C) >> 2));
        /* c4 */
        do {
            c4 = str.charCodeAt(i++) & 0xff;
            if(c4 == 61)
                return out;
            c4 = base64DecodeChars[c4];
        } while(i < len && c4 == -1);
        if(c4 == -1)
            break;
        out += String.fromCharCode(((c3 & 0x03) << 6) | c4);
    }
    return out;
}