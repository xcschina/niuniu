$(document).ready(function () {
    $(".tips_message").hide();
})
function isCardNo(card) {
    var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
    if(reg.test(card) === false)
    {
        // alert("提示：身份证号输入不合法！");
        $(".true_idCard_input").val("");
        $(".tips_message").fadeIn(1000);
        $(".tips_message").html("提示：身份证号输入不合法！");
        return false;
    }else{
        var user_name=$.trim($(".true_name_input").val());
        var id_number=$.trim($(".true_idCard_input").val());
        var pagehash=$.trim($(".pagehash").val());
        $.ajax({
            url: "/doRealVerify",
            type: "POST",
            data: {
                user_name:user_name,
                id_number:id_number,
                pagehash:pagehash
            },
            dataType: "text",
            success: function (res) {
                var json=$.parseJSON(base64decode(res.substr(1)));
                if(json.code==1){
                    alert(json.msg);
                    window.location.reload();
                }else{
                    alert(json.msg);
                }
            }
        })
    }
}
function baocun() {
    var name_n=$.trim($(".true_name_input").val());
    var card=$.trim($(".true_idCard_input").val());
    if(name_n==""||card==""){
        // alert("提示：身份证号或者名字不能为空！");
        $(".tips_message").fadeIn(1000);
        $(".tips_message").html("提示：身份证号或者名字不能为空！")
    }else{
        isCardNo(card);
    };
    if($(".tips_message").is(":hidden")){
        console.log(1)
    }else{
        $(".tips_message").fadeOut(2000);
    }
}
$(".true_name_input").bind("input propertychange",function(event){
    console.log($(".input_name").val());
    $(".input_name").blur(function(){
        if($(".true_name_input").val()!=""&&$(".true_idCard_input").val()!=""){
            $(".check_btn").css("background","#f96652")
        }
    });
});
$(".true_idCard_input").bind("input propertychange",function(event){
    if($(".true_name_input").val()!=""&&$(".true_idCard_input").val()!=""){
        $(".check_btn").css("background","#f96652");
    }
});
$(".page_top_left2").click(function () {
    history.back()
})