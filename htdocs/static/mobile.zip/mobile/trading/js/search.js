$(".page_top_left2").click(function () {
    history.back()
});
$(document).ready(function () {
    $(".title_text").each(function () {
        var len = $(this).text();
        if(len.length>18){
            $(this).parents(".search_game_right_div_s").siblings(".search_game_right_div_x").css("min-height","10px");
            $(this).parents(".search_game_right_div_s").siblings(".search_game_right_div_z").css("min-height","10px");
            $(this).parents(".search_game_right").css("margin-top","0px")
            $(this).css("font-size","0.93rem");
        }else{
        }
    })
});
$(document).ready(function () {
    var platform =$("input[name='platform']").val();
    var type = $("input[name='type']").val();
    if(platform==1){
        $(".choose_model").html("安卓");
        $(".slect111 li").eq(1).addClass("focus").siblings("li").removeClass("focus");
    }else if(platform==2){
        $(".choose_model").html("IOS");
        $(".slect111 li").eq(2).addClass("focus").siblings("li").removeClass("focus");
    }else {
        $(".choose_model").html("选择机型");
        $(".slect111 li").eq(0).addClass("focus").siblings("li").removeClass("focus");
    }

    if(type==4){
        $(".good_type").html("账号");
        $(".slect222 li").eq(1).addClass("focus").siblings("li").removeClass("focus");
    }else if(type==5){
        $(".good_type").html("游戏币");
        $(".slect222 li").eq(2).addClass("focus").siblings("li").removeClass("focus");
    }else if(type==6){
        $(".good_type").html("道具");
        $(".slect222 li").eq(3).addClass("focus").siblings("li").removeClass("focus");
    }else{
        $(".good_type").html("商品类别");
        $(".slect222 li").eq(0).addClass("focus").siblings("li").removeClass("focus");
    }
});
$(".price_choose_btn .price_item").click(function () {
    var val=$(this).children(".low_price").html();
    var val2=$(this).children(".high_price").html();
    $(".choose_input_s").val(val);
    $(".choose_input_s2").val(val2);
});
price_order2=""; //排序顺序
$(" .li_price_order").click(function () {
    $(this).addClass("bgbg_bg").siblings().removeClass("bgbg_bg");
    price_order2=$(this).attr("data-name");
});
var id_all;
var type2;
var ser_id;
var ch_id;
var ser_id2;
$(".search_txt_s").click(function () {  //点击服务区搜索框搜索服务区
    var ser_name =$("#search_title2").val();
    var id = id_all;
    var game_id = $("#game_id").val();

    $(".result_ul").html('');
    $.ajax({
        url: "/serverName",
        type: "post",
        data:{
            id:id,
            serv_name:ser_name,
            game_id:game_id
        },
        dataType: "text",
        success: function (res) {
            var json = $.parseJSON(base64decode(res.substr(1)));
            var arr2 = json.data;
            var list2="";
            if(arr2){
                for(var i = 0; i < arr2.length;i++){
                    list2 += "<li class='result_serv_name' data-id="+arr2[i].id+">"+arr2[i].serv_name+"</li>";
                }
            }
            list="<ul>"+list2+"</ul>";
            $(".result_ul").html(list2);
            $(".result_ul li").eq(0).addClass("red_color");
            console.log("5555");
            $(".result_ul li").click(function () {
                $(this).addClass("red_color").siblings("li").removeClass("red_color");
                var id_d = $(this).attr("data-id");
                $(".fuwuqi_div").hide();
                ser_id = $(this).attr("data-id");
                ser_id2 = id_d;
                console.log(ser_id2);
                var text = $(this).text();
                if ($(this).text().length > 3) {
                    text = $(this).text().substring(0, 3) + "...";
                }
                $(".server_select").html(text);
                //$(".look_more1").hide();
                yes_submit();
            });
            if(json.code==1){

            }else{

            }
        }

    })
});
$(document).on('click touchstart','.p_select',function(){
// $(".p_select").click(function () { //点击渠道
    var id = $(this).attr("data-id");
    id_all = id;
    $(".input_s").val("");
    var id_game = $("#game_id").val();
    $(".result_ul").html("");
    $(".quan_all_select").html("");
    $(".quan_all_select").removeClass("red_color");

    $.ajax({
        url: "/gameServer",
        type: "post",
        data:{
            id:id,
            game_id:id_game

        },
        dataType: "text",
        success: function (res) {
            var json = $.parseJSON(base64decode(res.substr(1)));
            var arr = json.data;
            var list="";
            if(ser_id == ''){
                // list +="class='red_color'";
            }
            // list+=" data-id=''  class='red_color quan_all_select'>全区服</li>";
            if(arr){
                for(var i = arr.length-1; i >= 0;i--){
                    list+="<li";
                    if(ser_id == arr[i].id){
                        // list +=" style='color:green'";
                        // list +="class='tttt'";
                    }
                    list += " data-id="+arr[i].id+">"+arr[i].serv_name+"</li>";
                }
            }
            list="<ul>"+list+"</ul>";
            $(".result_ul").html(list);
            $(".select_second_ul").show();
            $(".result_ul li").eq(0).addClass("red_color");
            $(".result_ul li").click(function () {
                $(this).addClass("red_color").siblings("li").removeClass("red_color");
                $(".fuwuqi_div").hide();
                ser_id=$(this).attr("data-id");
                id_all = id;
                // ser_id2 = ser_id;
                ser_id2= $(this).attr("data-id");
                text = $(this).text();
                if ($(this).text().length > 3) {
                    var text = $(this).text().substring(0, 3) + "...";
                }
                $(".server_select").html(text);
                yes_submit();
            });
            if(json.code==1){

            }else{

            }
        }
    })
});
function getData2() {
    pagesize = 10;
    var price_order = price_order2;
    var pid_all = ""; //这是渠道id
    var ser_id = "";//这是服务器id
    var page = 1;
    var loww = $(".choose_input_s").val();
    var high = $(".choose_input_s2").val();
    var platform2 = platform_;
    var type2 = type_;
    var game_id = $("input[name='game_id']").val();
    var type = $("input[name='type']").val();
    var platform = $("input[name='platform']").val();
    var game_name = $(".top_input").val();
    var text =$(".all_area").text();
    $(".select_fuwuqi").html(text);
    var name;
    $.ajax({
        url: "/realProduct",
        type: "POST",
        data: {
            type:type,
            platform:platform,
            ch_id:pid_all,
            ser_id:ser_id,
            title:game_name,
            price_order:price_order,
            price_pre:loww,
            price_aft:high,
            page:1,
            pagesize:10,
            game_id:game_id
        },
        dataType: "text",
        async:false,
        success: function (res) {
            var json=$.parseJSON(base64decode(res.substr(1)));
            var arr3 = json.data;
            var html2='';
            var html3='';
            if(json.channels){
                var channel_list = json.channels;
                for(var j = 0;j < channel_list.length;j++){
                    html3 += '<p class="p p_select ppp_span channel-name ';
                    if(pid_all == channel_list[j].id){
                        html3 += 'color_p';
                    }
                    html3 += '" id="ch_id'+channel_list[j].id
                        +'"  data-id="'+channel_list[j].id
                        +'"> <span class="p_span ppp_span_s" >'+channel_list[j].channel_name
                        +'</span> </p>';
                }
                $(".left_div_p").html(html3);
            }
            if(json.serv_type){
                // $(this).addClass("color_p");
                $(".ppp_span").removeClass("color_p");
                $(".search_input_ss").hide();
                $(".all_area").show().addClass("color_p")
                var li_ = "<li class='all_area'  onclick='getData2()'>"+"全区服"+"</li>";
                $(".result_ul").css("margin-top","6px").html(li_);
                $('.select_fuwuqi').html('服务器');
            }
            if(arr3.length == 0){
                $('.look_more1').hide();
                $('.look_more').html('没有找到相对应商品');
                // $('.current_no_data_bottom').hide()
            }else{
                if(arr3.length == 10) {
                    $(".look_more").show();
                    $('.look_more1').hide();
                    flag = true;
                }else if(arr3.length < 10){
                    $('.look_more1').show();
                    $('.look_more').hide();
                    $('.current_no_data_bottom').hide();
                    flag = false;
                }
                id_all = '';
                ser_id2 = '';
                for(var i = 0; i < arr3.length; i++){
                    var id = arr3[i].id;
                    var img = arr3[i].game_icon;
                    html2 +=' <div class="list_item">' +
                        '<a class="game_list_item" href="/productDetail/' + id +'">' +
                        '<div class="search_game_logo">'+
                        '<img src="//cdn.66173.cn/'+ img + '" alt="">'+
                        ' </div>'+
                        '<div class="search_game_right">'+
                        '<div class="search_game_right_div">' +
                        '<div class="search_game_right_div_s">';
                    if (arr3[i].type == 4) {
                        html2 += '<span class="search_bg_title">账号</span>'+
                            '<span class="title_text">'+arr3[i].title+'</span>';

                    } else if (arr3[i].type == 5) {
                        html2 += '<span class="search_bg_title2">游戏币</span>'+
                            '<span class="title_text">'+
                            '<span class="game_mount">'+arr3[i].num+"魔石"+'</span>'+"&nbsp;(1元="+
                            '<span class="singal_price">'+arr3[i].proportion+'</span>'+"魔石)"+
                            '</span>'

                    } else if (arr3[i].type == 6) {
                        html2 += '<span class="search_bg_title3">道具</span>'+
                            '<span class="title_text">'+arr3[i].title+'</span>';
                    }
                    if (arr3[i].serv_id == 0) {
                        name = '全区全服'
                    }else {
                        name = arr3[i].sname
                    }
                    // html2 += '<span class="title_text">'+arr3[i].title+'</span>'+
                    html2 += ' </div>'+
                        '<div class="search_game_right_div_z">' +
                        '<span>' +arr3[i].game_name+'&nbsp;</span>'+'|'+'<span>&nbsp;' +arr3[i].channel_name+'&nbsp;</span>' +'|'+'<span>&nbsp;' +name+'</span>'+
                        '</div>'+
                        '<div class="search_game_right_div_x">'+
                        '￥'+ '<span class="search_money_price">'+arr3[i].price+'</span>'+
                        '</div>'+
                        '</div>'+
                        '</div>'+
                        '</a>'+
                        '<div class="space"></div>'+
                        '</div>';
                }
                $(".game_list_div").html(html2);
            }
        }
    })
}
//重置按钮
function yes_submit2() {
    $(".select_div").hide();
    $(".choose_input_s").val("");
    $(".choose_input_s2").val("");
    $(".li_price_order").eq(0).addClass("bgbg_bg").siblings().removeClass("bgbg_bg");
    var page = 1;
    console.log(price_order2);
    var price_order ="";
    var pid_all = id_all; //这是渠道id
    var serv_id =  ser_id2;//这是服务器id
    var loww = "";
    var high = "";
    var type = $("input[name='type']").val();
    var platform = $("input[name='platform']").val();
    var game_id = $("input[name='game_id']").val();
    var game_name = $(".top_input").val();
    $.ajax({
        url: "/realProduct",
        type: "POST",
        data: {
            type:type,
            platform:platform,
            ch_id:pid_all,//渠道id
            serv_id:serv_id,
            title:game_name,
            price_order:price_order,
            price_pre:loww,
            price_aft:high,
            page:page,
            pagesize:10,
            game_id:game_id
        },
        dataType: "text",
        success: function (res) {
            $(".game_list_div").html("");
            var json=$.parseJSON(base64decode(res.substr(1)));
            var arr3 = json.data;
            var html2='';
            var name;
            var html3='';
            if(json.channels){
                var channel_list = json.channels;
                for(var j = 0;j < channel_list.length;j++){
                    html3 += '<p class="p p_select ppp_span channel-name ';
                    if(id_all == channel_list[j].id){
                        html3 += 'color_p';
                    }
                    html3 += '" id="ch_id'+channel_list[j].id
                        +'"  data-id="'+channel_list[j].id
                        +'"> <span class="p_span ppp_span_s" >'+channel_list[j].channel_name
                        +'</span> </p>';
                }
                $(".left_div_p").html(html3);
            }
            if(json.serv_type){
                $(this).addClass("color_p");
                $(".ppp_span").removeClass("color_p");
                $(".search_input_ss").hide();
                $(".all_area").show().addClass("color_p")
                var li_ = "<li class='all_area'  onclick='getData2()'>"+"全区服"+"</li>";
                $(".result_ul").css("margin-top","6px").html(li_);
                $('.select_fuwuqi').html('服务器');
            }
            if(json.code==1){
                if(!arr3){
                    $(".game_list_div").html("<div class='current_nodata'>没有找到相对应商品</div>");
                    $(".look_more").hide();
                    // $("look_more").hide();
                }else{
                    for(var i = 0; i < arr3.length; i++){
                        var id = arr3[i].id;
                        var img = arr3[i].game_icon;
                        html2 +=' <div class="list_item">' +
                            '<a class="game_list_item" href="/productDetail/' + id +'">' +
                            '<div class="search_game_logo">'+
                            '<img src="//cdn.66173.cn/'+ img + '" alt="">'+
                            ' </div>'+
                            '<div class="search_game_right">'+
                            '<div class="search_game_right_div">' +
                            '<div class="search_game_right_div_s">';
                        if (arr3[i].type == 4) {
                            html2 += '<span class="search_bg_title">账号</span>'+
                                '<span class="title_text">'+arr3[i].title+'</span>';

                        } else if (arr3[i].type == 5) {
                            html2 += '<span class="search_bg_title2">游戏币</span>'+
                                '<span class="title_text">'+
                                '<span class="game_mount">'+arr3[i].num+"魔石"+'</span>'+"&nbsp;(1元="+
                                '<span class="singal_price">'+arr3[i].proportion+'</span>'+"魔石)"+
                                '</span>'
                        } else if (arr3[i].type == 6) {
                            html2 += '<span class="search_bg_title3">道具</span>'+
                                '<span class="title_text">'+arr3[i].title+'</span>';
                        }
                        if (arr3[i].serv_id == 0) {
                            name = '全区全服'
                        }else {
                            name = arr3[i].sname
                        }
                        // html2 += '<span class="title_text">'+arr3[i].title+'</span>'+
                        html2 += '</div>'+
                            '<div class="search_game_right_div_z">' +
                            '<span>' +arr3[i].game_name+'&nbsp;</span>'+'|'+'<span>&nbsp;' +arr3[i].channel_name+'&nbsp;</span>' +'|'+'<span>&nbsp;' +name+'</span>'+
                            '</div>'+
                            '<div class="search_game_right_div_x">'+
                            '￥'+ '<span class="search_money_price">'+arr3[i].price+'</span>'+
                            '</div>'+
                            '</div>'+
                            '</div>'+
                            '</a>'+
                            '<div class="space"></div>'+
                            '</div>';
                    }
                    $(".game_list_div").html(html2);
                    if(arr3.length <10){
                        $(".look_more").html('暂无数据~');
                        flag= false;
                    }else{
                        $(".look_more").show();
                        flag= true;
                    }
                }
            }else if(json.code == 0){
                $(".game_list_div").html("<div class='current_nodata'>没有找到相对应商品</div>");
                $(".look_more").hide();
                // $(".look_more").html('暂无数据');
            }
        }
    })
}
//点击筛选的确定或者顶部搜索按钮请求数据=======
function yes_submit() {
    $(".select_div").hide();
    var page = 1;
    var price_order =price_order2;
    var pid_all = id_all; //这是渠道id
    var serv_id =  ser_id2;//这是服务器id
    var loww = $(".choose_input_s").val();
    var high = $(".choose_input_s2").val();
    var type = $("input[name='type']").val();
    var platform = $("input[name='platform']").val();
    var game_id = $("input[name='game_id']").val();
    var game_name = $(".top_input").val();
    $.ajax({
        url: "/realProduct",
        type: "POST",
        data: {
            type:type,
            platform:platform,
            ch_id:pid_all,//渠道id
            serv_id:serv_id,
            title:game_name,
            price_order:price_order,
            price_pre:loww,
            price_aft:high,
            page:page,
            pagesize:10,
            game_id:game_id
        },
        dataType: "text",
        success: function (res) {
            $(".game_list_div").html("");
            var json=$.parseJSON(base64decode(res.substr(1)));
            var arr3 = json.data;
            var html2='';
            var name;
            var html3='';
            id_all = json.ch_id;
            ser_id2 = json.serv_id;
            if(json.channels){
                var channel_list = json.channels;
                for(var j = 0;j < channel_list.length;j++){
                    html3 += '<p class="p p_select ppp_span channel-name ';
                    if(id_all == channel_list[j].id){
                        html3 += 'color_p';
                    }
                    html3 += '" id="ch_id'+channel_list[j].id
                            +'"  data-id="'+channel_list[j].id
                            +'"> <span class="p_span ppp_span_s" >'+channel_list[j].channel_name
                        +'</span> </p>';
                }
                $(".left_div_p").html(html3);
            }
            if(json.serv_type){
                $(this).addClass("color_p");
                $(".ppp_span").removeClass("color_p");
                $(".search_input_ss").hide();
                $(".all_area").show().addClass("color_p")
                var li_ = "<li class='all_area'  onclick='getData2()'>"+"全区服"+"</li>";
                $(".result_ul").css("margin-top","6px").html(li_);
                $('.select_fuwuqi').html('服务器');
            }
            if(json.code==1){
                if(!arr3){
                    $(".game_list_div").html("<div class='current_nodata'>没有找到相对应商品</div>");
                    $(".look_more1").hide();
                }else{
                    for(var i = 0; i < arr3.length; i++){
                        var id = arr3[i].id;
                        var img = arr3[i].game_icon;
                        html2 +=' <div class="list_item">' +
                            '<a class="game_list_item" href="/productDetail/' + id +'">' +
                            '<div class="search_game_logo">'+
                            '<img src="//cdn.66173.cn/'+ img + '" alt="">'+
                            ' </div>'+
                            '<div class="search_game_right">'+
                            '<div class="search_game_right_div">' +
                            '<div class="search_game_right_div_s">';
                        if (arr3[i].type == 4) {
                            html2 += '<span class="search_bg_title">账号</span>'+
                                '<span class="title_text">'+arr3[i].title+'</span>';

                        } else if (arr3[i].type == 5) {
                            html2 += '<span class="search_bg_title2">游戏币</span>'+
                                '<span class="title_text">'+
                                '<span class="game_mount">'+arr3[i].num+"魔石"+'</span>'+"&nbsp;(1元="+
                                '<span class="singal_price">'+arr3[i].proportion+'</span>'+"魔石)"+
                                '</span>'
                        } else if (arr3[i].type == 6) {
                            html2 += '<span class="search_bg_title3">道具</span>'+
                                '<span class="title_text">'+arr3[i].title+'</span>';
                        }
                        if (arr3[i].serv_id == 0) {
                            name = '全区全服'
                        }else {
                            name = arr3[i].sname
                        }
                        // html2 += '<span class="title_text">'+arr3[i].title+'</span>'+
                        html2 += '</div>'+
                            '<div class="search_game_right_div_z">' +
                            '<span>' +arr3[i].game_name+'&nbsp;</span>'+'|'+'<span>&nbsp;' +arr3[i].channel_name+'&nbsp;</span>' +'|'+'<span>&nbsp;' +name+'</span>'+
                            '</div>'+
                            '<div class="search_game_right_div_x">'+
                            '￥'+ '<span class="search_money_price">'+arr3[i].price+'</span>'+
                            '</div>'+
                            '</div>'+
                            '</div>'+
                            '</a>'+
                            '<div class="space"></div>'+
                            '</div>';
                    }
                    $(".game_list_div").html(html2);
                    if(arr3.length <10){
                        $(".look_more").html('暂无数据~');
                        flag= false;
                    }else{
                        $(".look_more").show();
                        flag= true;
                    }
                }
            }else if(json.code == 0){
                $(".game_list_div").html("<div class='current_nodata'>没有找到相对应商品</div>");
                // $(".look_more").html('暂无数据');
                $(".look_more").hide();
            }
        }
    })
}
//点击查看更多获取数据
$(" .li_price_order").click(function () {
    $(this).addClass("bgbg_bg").siblings().removeClass("bgbg_bg");
});
<!--封装好的获取数据函数=================================-->
var platform4;
var platform_;
var type4;
var type_;
platform4 = $("input[name='platform']").val();
type4 = $("input[name='type']").val();
$(".slect111 li").click(function () {
    var plat = $(this).attr("data-id");
    $("input[name='platform']").val(plat);
    yes_submit();
});
$(".slect222 li").click(function () {
    var plat2 = $(this).attr("data-id");
    $("input[name='type']").val(plat2);
    yes_submit();
});
var flag= true;
var page1=1;
function getData() {
    pagesize = 10;
    var price_order = price_order2;
    var pid_all = id_all; //这是渠道id
    var ser_id = ser_id2;//这是服务器id
    var page = page1;
    var loww = $(".choose_input_s").val();
    var high = $(".choose_input_s2").val();
    var platform = $("input[name='platform']").val();
    // var type = type4;
    var game_id = $("input[name='game_id']").val();
    var type = $("input[name='type']").val();
    var game_name = $(".top_input").val();
    var name;
    // console.log(page)
    $.ajax({
        url: "/realProduct",
        type: "POST",
        data: {
            type:type,
            platform:platform,
            ch_id:pid_all,//渠道id
            serv_id:ser_id,   //服务器id
            title:game_name,
            price_order:price_order,
            price_pre:loww,
            price_aft:high,
            page:page,
            pagesize:10,
            game_id:game_id
        },
        dataType: "text",
        async:false,
        success: function (res) {
            var json=$.parseJSON(base64decode(res.substr(1)));
            var arr3 = json.data;
            var html2='';
            var html3='';
            if(json.channels){
                var channel_list = json.channels;
                for(var j = 0;j < channel_list.length;j++){
                    html3 += '<p class="p p_select ppp_span channel-name ';
                    if(id_all == channel_list[j].id){
                        html3 += 'color_p';
                    }
                    html3 += '" id="ch_id'+channel_list[j].id
                        +'"  data-id="'+channel_list[j].id
                        +'"> <span class="p_span ppp_span_s" >'+channel_list[j].channel_name
                        +'</span> </p>';
                }
                $(".left_div_p").html(html3);
            }
            if(json.serv_type){
                $(this).addClass("color_p");
                $(".ppp_span").removeClass("color_p");
                $(".search_input_ss").hide();
                $(".all_area").show().addClass("color_p");
                var li_ = "<li class='all_area'  onclick='getData2()'>"+"全区服"+"</li>";
                $(".result_ul").css("margin-top","6px").html(li_);
                $('.select_fuwuqi').html('服务器');
            }
            if(arr3.length == 0){
                $(".look_more").html('没有找到相对应商品');
                //$(".look_more1").show();
            }else{
                console.log('eee'+arr3.length);
                if(arr3.length == 10) {
                    page1 = page1+1;
                    // $(".look_more").show();
                    $(".look_more").html('查看更多>>');
                    flag = true;
                }else if(arr3.length < 10){
                    page1 = 1;
                    //$(".look_more1").show();
                    $(".look_more").html('暂无数据~');
                    // $(".look_more").attr('disabled',true);
                    flag = false;
                }
                for(var i = 0; i < arr3.length; i++){
                    var id = arr3[i].id;
                    var img = arr3[i].game_icon;
                    html2 +=' <div class="list_item">' +
                        '<a class="game_list_item" href="/productDetail/' + id +'">' +
                        '<div class="search_game_logo">'+
                        '<img src="//cdn.66173.cn/'+ img + '" alt="">'+
                        ' </div>'+
                        '<div class="search_game_right">'+
                        '<div class="search_game_right_div">' +
                        '<div class="search_game_right_div_s">';
                    if (arr3[i].type == 4) {
                        html2 += '<span class="search_bg_title">账号</span>'+
                            '<span class="title_text">'+arr3[i].title+'</span>';

                    } else if (arr3[i].type == 5) {
                        html2 += '<span class="search_bg_title2">游戏币</span>'+
                            '<span class="title_text">'+
                            '<span class="game_mount">'+arr3[i].num+"魔石"+'</span>'+"&nbsp;(1元="+
                            '<span class="singal_price">'+arr3[i].proportion+'</span>'+"魔石)"+
                            '</span>'

                    } else if (arr3[i].type == 6) {
                        html2 += '<span class="search_bg_title3">道具</span>'+
                            '<span class="title_text">'+arr3[i].title+'</span>';
                    }
                    if (arr3[i].serv_id == 0) {
                        name = '全区全服'
                    }else {
                        name = arr3[i].sname
                    }
                    // html2 += '<span class="title_text">'+arr3[i].title+'</span>'+
                    html2 += ' </div>'+
                        '<div class="search_game_right_div_z">' +
                        '<span>' +arr3[i].game_name+'&nbsp;</span>'+'|'+'<span>&nbsp;' +arr3[i].channel_name+'&nbsp;</span>' +'|'+'<span>&nbsp;' +name+'</span>'+
                        '</div>'+
                        '<div class="search_game_right_div_x">'+
                        '￥'+ '<span class="search_money_price">'+arr3[i].price+'</span>'+
                        '</div>'+
                        '</div>'+
                        '</div>'+
                        '</a>'+
                        '<div class="space"></div>'+
                        '</div>';
                }
                $(".game_list_div").append(html2);
            }
        }
    })
}
function  getMore(){
    if(flag){
        ++page1;
        getData(page1);
    }else{
        page1 = 1;
        $('.look_more1').show();
        $('.look_more').html('暂无数据~');
        // $(".look_more").html("没有更多数据6了~");
        // $(".look_more").attr('disabled',true);
    }
}
$(".top_input").bind("input propertychange",function(event){
    yes_submit();
});