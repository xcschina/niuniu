$(".top_left").click(function () {
    history.back()
})
//    加减计数器
$(document).ready(function () {
    $(".add").click(function() {
        var t = $(this).parent().find('input[class*=numnum]');
        if(t.val()==""||undefined||null){
            t.val(1);
        }
        t.val(parseInt(t.val()) + 1)
        setTotal();
    })
    $(".reduce").click(function() {
        var t = $(this).parent().find('input[class*=numnum]');
        if(t.val()==""||undefined||null){
            t.val(1);
        }
        t.val(parseInt(t.val()) - 1)
        if(parseInt(t.val()) < 1) {
            t.val(1);
        }
        setTotal();
    })
    $(".numnum").keyup(function(){
        var t = $(this).parent().find('input[class*=numnum]');
        if(parseInt(t.val())==""||undefined||null || isNaN(t.val())) {
            t.val(1);
        }
        setTotal();
    })
    function setTotal() {
        var s = 0;
        var t = $(".numnum").val();
        var p = $(".price").text();
        s += parseInt(t) * parseFloat(p);
        $(".color").html(s.toFixed(2));
    }
})
//单选框的值var a = $("input[name='danxuan']:checked").val();
$(".pay_btn").click(function () {
    var val=$('input:radio[name="danxuan"]:checked').val();
    console.log(val)
    if(val==null){
        alert("请点击同意协议书")
    }else{
        $(".pay_btn").css("background","red");
        console.log(1111)
        //    支付开始
    }
})