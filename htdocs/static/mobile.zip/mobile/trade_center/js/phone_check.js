$(".top_left").click(function () {
    history.back()
})
//注意不要定义在$(function(){})里
var countdown=60;
function sendmsg(){
    if(countdown==0){
        $(".yanzhengma").html("获取验证码");
        $(".yanzhengma").attr("disabled",false);
        countdown=60;
        return false;
    }
    else{
        $(".yanzhengma").html(countdown+"s");
        $(".yanzhengma").attr("disabled",true);
        countdown--;
    }
    setTimeout(function(){
        sendmsg();
    },1000);
}
$(".dd").bind("input propertychange",function(event){
    console.log($(".dd").val());
    $(".dd").blur(function(){
        if($(".input_form").val()!=""&&$(".input_form2").val()!=""){
            $(".save_form").css("background","#d14747")
        }
    });
});
$(".dd2").bind("input propertychange",function(event){
    if($(".input_form").val()!=""&&$(".input_form2").val()!=""){
        $(".save_form").css("background","#d14747");
    }
});
//获取手机验证码
function getCode() {
    // 判断手机号码
    if ($.trim($('.input_form').val()).length == 0) {
        alert("请输入手机号");
        $('.input_form').focus();
    }
    else if(isphone2($.trim($('.input_form').val())) == false){
        alert("非法的手机号")
    }else{
        sendmsg();
        //   开始进行ajax请求得到验证码
    }
}

function isphone2(inputString)      // 验证手机号
{
    var partten = /^1[3,5,8]\d{9}$/;
    var fl=false;
    if(partten.test(inputString))
    {
        return true;
    }
    else
    {
        return false;
    }
}
$(".save_form").click(function () {
    if($.trim($(".input_form").val())==""||$.trim($(".input_form2").val())==""){
        alert("验证码或者手机号不能为空")
    }else{
        //    检测验证码是否正确进行ajax请求
    }
})