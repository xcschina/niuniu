$(document).ready(function () {
    var  h=document.body.clientHeight;
    $(".alert_div").css("top",h/2.5);
    $(".alert_div2").css("top",h/2.5);
    var  len=$(".num .collection_list_item").length;
    $(".num_shixiao").html(len)
});
$(".yes").click(function () {

});
$(".no").click(function () {
    $(".alert_div").hide();
    $(".alert_div2").hide();
    $(".mengcen").hide()
});
$(".footer_delet").click(function () {
    $(".alert_div").show();
    $(".mengcen").show()
});
$(".qingkong").click(function () {
    $(".alert_div2").show();
    $(".mengcen").show()
});
$(".top_right").click(function () {
    if ($(".check_icon").is(":hidden")){
        $(".check_icon").show();
        $(".footer_delet").show();
        $(".top_right").html("取消编辑");
        $(".check_item").css("margin-left","4%")
    }else {
        $(".check_icon").hide();
        $(".footer_delet").hide();
        $(".top_right").html("编辑");
        $(".check_item").css("margin-left","10%")
    }
    if($(".allChecked_all").is(":hidden")){
        $(".allChecked_all").show();
        $(".allChecked_all").css("height","35px")
    }else{
        $(".allChecked_all").hide();
        $(".allChecked_all").css("height","0")
    }
});
$(".check_icon .check_img").each(function () {
    $(this).click(function () {
        if($(this).is(":hidden")){
            $(this).show();
            $(this).siblings().hide()
        }else {
            $(this).siblings().show();
            $(this).hide();
        }
    })
});
$(".check_icon .check_img2").each(function () {
    $(this).click(function () {
        if($(this).is(":hidden")){
            $(this).show();
            $(this).siblings().hide()
        }else {
            $(this).siblings().show();
            $(this).hide();
        }
    })
});
$(".allChecked_all").click(function () {
    if($(".check_img_11").is(":hidden")){
        $(".check_img_11").show();
        $(".check_img_112").hide();
    }else{
        $(".check_img_112").show();
        $(".check_img_11").hide();
    }
    if( $(".check_icon .check_img2").is(":hidden")){
        $(".check_icon .check_img2").show();
        $(".check_icon .check_img").hide();
    }else {
        $(".check_icon .check_img").show();
        $(".check_icon .check_img2").hide();
    }
});
$(".top_left").click(function () {
    history.back()
});