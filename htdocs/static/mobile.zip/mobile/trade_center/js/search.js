$(".top_left").click(function () {
    history.back()
})
$(".input_s").focus();
$(".price_choose_btn .price_item").click(function () {
    // $(this).addClass("bgbg_bg").siblings().removeClass("bgbg_bg")
    var val=$(this).children(".low_price").html();
    var val2=$(this).children(".high_price").html();
    $(".choose_input_s").val(val);
    $(".choose_input_s2").val(val2);
})
   var index=1
    $(" .p22").click(function () {
        $(this).addClass("bgbg_bg").siblings().removeClass("bgbg_bg");
        index=$(this).index()-1;
        console.log(index)
    })
//点击筛选的确定按钮请求数据
function yes_submit() {
    $(" .p22").click(function () {
        $(this).addClass("bgbg_bg").siblings().removeClass("bgbg_bg");
        index=$(this).index()-1;
    })
    console.log(index);
    var loww=$(".choose_input_s").val();
    var high=$(".choose_input_s2").val();
    console.log(loww+high)
    // 此处开始进行ajax请求
}

// <!--点击更多获取对应的十条数据-->
var flag;   // flag为true的时候可以点击请求，否则说明数据没有那么多
var num;    //  数据请求时的第几页，默认从0开始
$(function() {
    num = 0;// 页面初始化的时候请求数据，默认num为0
    getData(num);
})
function getData(num) { //请求数据的函数，参数num为请求第几页，动态传入
    flag = false; // 当触发了请求函数时必须将flag设为false以阻止连续被触发
    $.ajax({
        url: "",
        type: "GET",
        data: {
            num: num
        },
        dataType: "JSON",
        success: function (res) {
            if(res.data.length == 10) {  // 假设后台一次返回数据10条
                // 如果返回的值数量等于10条的时候证明还有其他数据
                flag = true;// 那么可以吧flag设为true，
            }else if(res.data.length<= 10){
                alert("没有更多数据了")
                flag =false;
            }
            console.log(res.data);
        }
    })
}
//点击获取更多的函数
function  getMore(){
    if(flag) {    // flag为true时，可以调用请求数据的函数，请求更多的数据
        ++num;  //  num自增1
        getData(num);
    }else{
        alert("没有更多数据了")
    }
    console.log(num)
}
