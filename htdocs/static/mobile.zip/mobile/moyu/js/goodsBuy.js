$(function () {
    // 发布
    var orderBuyBtn = $('.order-buy-btn'),
        pagehash = $('[name=pagehash]').val(),
        flag = false,
        userSex = 1,
        userJob = '默认',
        agreement = 1,
        payMode = 1;
    orderBuyBtn.on('click', function (e) {
        e.preventDefault();
        var userPhone = strReplace($('.userPhone').val()),
            userQQ = strReplace($('.userQQ').val()),
            ruleName = strReplace($('.ruleName').val()),
            serverName = strReplace($('.serverName').val()),
            puyNum = strReplace($('.puy-num').val()),
            goodsId = $('[name=id]').val(),
            goodsType = $('[name=type]').val(),
            price = $('[name=price]').val(),
            priceMoney = $('[name=price_money]').val();
        if (!userPhone) {
            Alert('请输入手机号码');
            return;
        } else if (!(/^[1][3,4,5,7,8][0-9]{9}$/.test(userPhone))) {
            Alert('请输入正确的手机号');
            return;
        } else if (!userQQ) {
            Alert('请输入QQ号');
            return;
        } else if (!(/^[1-9][0-9]{4,10}$/.test(userQQ))) {
            Alert('请输入正确的QQ号');
            return;
        } else if (!ruleName) {
            Alert('请输入角色名称');
            return;
        } else if (!serverName) {
            Alert('请输入服务器名称');
            return;
        } else if (!$('.selected').hasClass('on')) {
            Alert('请选择支付方式');
            return;
        }
        if (flag) return;
        flag = true;
        orderBuyBtn.text('支付中...');
        $.ajax({
            url: '/trading_center.php?act=confirm_pay',
            type: 'post',
            data: {
                pagehash: pagehash,
                type: goodsType,
                agreement: agreement,
                mobile: userPhone,
                qq: userQQ,
                id: goodsId,
                num: puyNum,
                pay_mode: payMode,
                price: price,
                serv_name: serverName,
                role_name: ruleName,
                job: userJob,
                sex: userSex,
                pay_money: priceMoney
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                flag = false;
                if (data.code == 1) {
                    Alert(data.msg, function () {
                        window.location.href = data.url;
                    });
                } else {
                    Alert(data.msg);
                    orderBuyBtn.text('确认购买');
                }
            }
        });

    });
    $('.recharge-plat').on('click', '.selected', function () {
        var $this = $(this);
        if ($this.hasClass('on')) {
            $this.removeClass('on');
        } else {
            $this.addClass('on');
        }
    });
    //购买计算
    function goodsBuyCount() {
        var butInput = $('.puy-num'),
            payMoney = $('#pay-money'),
            goodsPrice = $('[name=price]').val(),
            goodsStock = parseInt($('[name=stock]').val()),
            reduceBtn = $('.reduce'),
            addBtn = $('.plus');
        butInput.keyup(function () {
            var curVal = parseInt($(this).val());
            $(this).val(curVal);
            curVal = 0 || (curVal = 1);
            curVal > goodsStock && butInput.val(goodsStock);;
            payMoney.html('￥' + curVal * goodsPrice);
        });
        butInput.blur(function () {
            var curVal = parseInt($(this).val());
            if (curVal > goodsStock) {
                $(this).val(goodsStock)
            } else if (!curVal || curVal == 0 || curVal < 1) {
                $(this).val(1);
            }
            payMoney.html('￥' + $('.puy-num').val() * goodsPrice);

        });
        reduceBtn.on('click', function () {
            var butInputVal = parseInt(butInput.val());
            if (butInputVal <= 1) return;
            butInputVal -= 1;
            butInput.val(butInputVal);
            payMoney.html('￥' + butInputVal * goodsPrice);
        });
        addBtn.on('click', function () {
            var butInputVal = parseInt(butInput.val());
            if (butInputVal >= goodsStock) {
                Alert('购买数量不能超过' + goodsStock);
                return;
            };
            butInputVal += 1;
            butInput.val(butInputVal);
            payMoney.html('￥' + butInputVal * goodsPrice);
        });
    }
    goodsBuyCount();
    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1.5,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1000)
            }
        });
    }
    /* 字符串过滤 */
    function strReplace(str) {

        // str = $.trim(str);
        str = str.replace(/<\/?[^>]*>/g, '');
        str = str.replace(/\s+/g, '');
        str = str.replace(/(&nbsp;|&lt;|&gt;|&)/ig, '');
        return str;
    };

})