window.onload = function () {
    var goodsList = $('.goods-list ul'),
        loading = $('.ui-loading'),
        status = $('[name=status]').val(),
        goodsType = status;
    $('.swiper-slide').removeClass('on').eq(status).addClass('on');
    new Swiper('.goods-swiper-tab', {
        slidesPerView: 'auto'
    });
    $('.goods-swiper-tab').on('click', '.swiper-slide', function () {
        var $this = $(this);
        goodsType = $this.data('type');
        if ($this.text() == '全部') goodsType = '';
        if ($this.hasClass('on')) return;
        $this.addClass('on').siblings().removeClass('on');
        $('.ui-nores').hide();
        getOrderList();
    });

    //获取订单列表
    function getOrderList() {
        goodsList.empty();
        loading.css('display', '-webkit-box');
        $.ajax({
            url: '/trading_center.php?act=get_sell_order_data',
            type: 'POST',
            data: {
                status: goodsType,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                loading.hide();
                if (data.code == 1) {
                    goodsList.append(goodsRoderTpl(data.data));
                } else {
                    $('.ui-nores').show();
                    console.log(data.msg);
                }
            }
        });
    }
    //订单模板
    function goodsRoderTpl(data) {
        var html = '',
            li;
        for (var i = 0; i < data.length; i++) {
            li = data[i];
            html += '<li data-id="' + li.id + '">';
            html += '<div class="time">';
            html += '<span>订单号：' + li.order_id + '</span>';
            if (li.status == 0) {
                html += '<span class="cff8">待付款</span>';
            } else if (li.status == 1) {
                html += '<span class="cff8">待发货</span>';
            } else if (li.status == 2) {
                html += '<span class="ca1a">已发货</span>';
            } else if (li.status == 3) {
                html += '<span class="ca1a">已完成</span>';
            } else if (li.status == 4) {
                html += '<span class="ca1a">已退款</span>';
            } else {
                html += '<span class="ca1a">已关闭</span>';
            }
            html += '</div>';
            html += '<a href="/orderDetail/' + li.id + '" class="content">';
            html += '<div class="tit"><strong>魔石</strong><p>[担保]' + li.num + '魔石（1元=' + li.proportion + '魔石）</p></div>';
            if (li.serv_id > 0) {
                html += '<div class="info">' + li.game_name + '>' + li.channel_name + '>' + li.serv_name + '</div>';
            } else {
                html += '<div class="info">' + li.game_name + '>' + li.channel_name + '>全区全服</div>';
            }
            html += '<div class="sum">x' + li.amount + '</div>';
            html += '</a>';
            html += '<div class="bottom">';
            html += '<div class="total">总价：<em>￥' + li.pay_money + '</em></div>';
            html += '<div class="btns">';
            if (li.status == 1) {
                html += '<a class="send-btn cff8" href="/moyu_product.php?act=deliver_product_view&id=' + li.id + '">发货</a><a class="guest-btn c4fa" href="">联系客服</a>';
            } else if (li.status == 3) {
                html += '<a class="view-btn cff8" href="/user_certification.php?act=my_income">查看收入</a>';
            }
            html += '</div>';
            html += '</div>';
            html += '</li>';
        }
        return html;
    }

    //联系客服
    $('.goods-list').on('click', '.guest-btn,.refund-btn', function (e) {
        e.preventDefault();
        var u = navigator.userAgent;
        if (/Safari/.test(u) && !/Chrome/.test(u)) {
            alert('请添加客服QQ：270772735');
        } else {
            window.location.href = 'http://wpa.qq.com/msgrd?v=3&uin=270772735&site=qq&menu=yes';
        }

    });
    getOrderList();

    function Alert(str) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2
        });
    }
    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1000)
            }
        });
    }
}