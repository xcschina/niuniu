$(function () {
    $('.mod-tab').on('click', 'span', function () {
        var $this = $(this),
            $index = $this.index();
        $this.addClass('on').siblings().removeClass('on');
        $('.mod-tabcon').hide().eq($index).show();
    })
})