$(function () {
    var browser = {
        versions: function () {
            var u = navigator.userAgent;
            return {
                webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
                mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
                ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
                android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或者uc浏览器
                webApp: u.indexOf('Safari') == -1, //是否web应该程序，没有头部与底部
                weixin: u.indexOf('MicroMessenger') > -1, //是否微信 （2015-01-22新增）
                qq: u.match(/\sQQ/i) == " QQ" //是否qq
            };
        }()
    };

    var shareDiv = $('.share-guide'),
        collectBtn = $('.collect-btn'),
        collectUrl;
    $('.mod-tab').on('click', 'span', function () {
        var $this = $(this),
            $index = $this.index();
        $this.addClass('on').siblings().removeClass('on');
        $('.mod-tabcon').hide().eq($index).show();
    });
    //收藏
    collectBtn.on('click', function (e) {
        e.preventDefault();
        var $this = $(this),
            goodsId = $this.data('id');
        $this.hasClass('on') ? collectUrl = '/moyu_product.php?act=cancle_product_collect' : collectUrl = '/moyu_product.php?act=update_product_collect';
        var loadLayer = layer.open({
            type: 2,
            shadeClose: false
        });
        $.ajax({
            url: collectUrl,
            type: 'get',
            data: {
                id: goodsId
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                layer.close(loadLayer);
                if (data.code == 1) {
                    data.msg == '收藏成功' ? collectBtn.addClass('on') : collectBtn.removeClass('on');
                    Alert(data.msg);
                } else {
                    Alert(data.msg);
                }
            }

        })
    });
    //分享
    $('.share-btn').on('click', function (e) {
        e.preventDefault();
        if (browser.versions.weixin) {
            shareDiv.addClass('topshow').fadeIn();
        } else {
            shareDiv.addClass('bottomshow').fadeIn();
        }
    });
    shareDiv.on('click', function (e) {
        $(this).fadeOut();
    });
    if ($('.swiper-slide').length > 1) {
        new Swiper('.publish-banner-swiper', {
            pagination: '.swiper-pagination',
            autoplay: 3e3,
            autoplayDisableOnInteraction: !1
        })
    }

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                if (callBack) callBack();
            }
        });
    }
})