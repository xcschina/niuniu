window.onload = function () {
    var shutHtml = '<div class="shut-list">' +
        '<div class="shut-item on" data-type="1">不想买了</div>' +
        '<div class="shut-item" data-type="2">信息填错</div>' +
        '<div class="shut-item" data-type="3">卖家缺货</div>' +
        '<div class="shut-item" data-type="4">其它</div>' +
        '</div>';
    var goodsList = $('.goods-list ul'),
        loading = $('.ui-loading'),
        status = parseInt($('[name=status]').val()) + 1,
        orderType = 1,
        goodsType = '';
    if (!status) status = 0;
    $('.goods-tab li').removeClass('on').eq(status).addClass('on');
    $('.goods-tab').on('click', 'li', function () {
        var $this = $(this);
        goodsType = $this.data('id');
        if ($this.text() == '全部') goodsType = '';
        if ($this.hasClass('on')) return;
        $this.addClass('on').siblings().removeClass('on');
        $('.ui-nores').hide();
        getOrderList();
    });

    //获取订单列表
    function getOrderList() {
        goodsList.empty();
        loading.css('display', '-webkit-box');
        $.ajax({
            url: '/trading_center.php?act=get_my_order_list',
            type: 'POST',
            data: {
                status: goodsType,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                loading.hide();
                if (data.code == 1) {
                    goodsList.append(goodsRoderTpl(data.data));
                } else {
                    $('.ui-nores').show();
                    console.log(data.msg);
                }
            }
        });
    }
    //订单模板
    function goodsRoderTpl(data) {
        var html = '',
            li;
        for (var i = 0; i < data.length; i++) {
            li = data[i];
            html += '<li data-id="' + li.id + '">';
            html += '<div class="time">';
            html += '<span>订单号：' + li.order_id + '</span>';
            if (li.status == 0) {
                html += '<span class="cff8">待付款</span>';
            } else if (li.status == 1) {
                html += '<span class="cff8">待发货</span>';
            } else if (li.status == 2) {
                html += '<span>已发货</span>';
            } else if (li.status == 3) {
                html += '<span class="cff8">已完成</span>';
            } else if (li.status == 4) {
                html += '<span>已退款</span>';
            } else if (li.status == 5) {
                html += '<span>已关闭</span>';
            }
            html += '</div>';
            html += '<a href="/orderDetail/' + li.id + '" class="content">';
            html += '<div class="tit"><strong>魔石</strong><p>[担保]' + li.num + '魔石（1元=' + li.proportion + '魔石）</p></div>';
            if (li.serv_id > 0) {
                html += '<div class="info">' + li.game_name + '>' + li.channel_name + '>' + li.serv_name + '</div>';
            } else {
                html += '<div class="info">' + li.game_name + '>' + li.channel_name + '>全区全服</div>';
            }
            html += '<div class="sum">x' + li.amount + '</div>';
            html += '</a>';
            html += '<div class="bottom">';
            html += '<div class="total">总价：<em>￥' + li.pay_money + '</em></div>';
            html += '<div class="btns">';
            if (li.status == 0) {
                html += '<a href="/continuePay/' + li.id + '" class="payment-btn cff8">继续支付</a><a class="shut-btn c9a9" data-index="' + i + '"  data-id="' + li.id + '">关闭交易</a>';
            } else if (li.status == 1) {
                html += '<a class="guest-btn cff8">联系客服</a>';
            } else if (li.status == 2) {
                html += '<a class="harvest-btn cff8" data-index="' + i + '" data-id="' + li.id + '">确认收货</a><a class="refund-btn c9a9">申请退款</a>';
            }
            html += '</div>';
            html += '</div>';
            html += '</li>';
        }
        return html;
    }
    //确认收获
    $('.goods-list').on('click', '.harvest-btn', function (e) {
        e.preventDefault();
        var $this = $(this),
            $index = $this.data('index'),
            orderId = $this.data('id');
        layer.open({
            className: 'layui-confirm',
            content: '<div class="msg">是否收货该商品？</div>',
            btn: ['确认', '取消'],
            shadeClose: false,
            yes: function () {
                layer.closeAll();
                var loadLayer = layer.open({
                    type: 2,
                    shadeClose: false
                });
                $.ajax({
                    url: '/trading_center.php?act=confirm_trade',
                    type: 'POST',
                    data: {
                        id: orderId,
                    },
                    dataType: 'text',
                    success: function (res) {
                        var data = JSON.parse(base64decode(res.substr(1)));
                        layer.closeAll();
                        if (data.code == 1) {
                            Alert(data.msg, function () {
                                $this.parent().remove();
                                $('.time').eq($index).find('span:last').text('已完成');
                            });
                        } else {
                            console.log(data.msg);
                        }
                    }
                })
            }
        });
    });
    // 关闭交易
    $('.goods-list').on('click', '.shut-btn', function (e) {
        e.preventDefault();
        var $this = $(this),
            $index = $this.data('index'),
            orderId = $this.data('id');
        layer.open({
            title: ['关闭交易', 'background-color: #fff;'],
            className: 'layui-confirm',
            content: shutHtml,
            btn: ['确认', '取消'],
            shadeClose: false,
            success: function (elem) {
                // 关闭交易选项
                $('.shut-item').on('click', function () {
                    $(this).addClass('on').siblings().removeClass('on');
                    orderType = $(this).data('type');
                });
            },
            yes: function () {
                layer.closeAll();
                var loadLayer = layer.open({
                    type: 2,
                    shadeClose: false
                });

                $.ajax({
                    url: '/trading_center.php?act=close_trade',
                    type: 'POST',
                    data: {
                        type: orderType,
                        id: orderId,
                    },
                    dataType: 'text',
                    success: function (res) {
                        var data = JSON.parse(base64decode(res.substr(1)));
                        layer.closeAll();
                        if (data.code == 1) {
                            Alert(data.msg, function () {
                                $this.parent().remove();
                                $('.time').eq($index).find('span:last').html('<span>已关闭</span>');
                            });
                        } else {
                            console.log(data.msg);
                        }
                    }
                })
            }
        });
    });

    //联系客服
    $('.goods-list').on('click', '.guest-btn,.refund-btn', function (e) {
        e.preventDefault();
        var u = navigator.userAgent;
        if (/Safari/.test(u) && !/Chrome/.test(u)) {
            alert('请添加客服QQ：270772735');
        } else {
            window.location.href = 'http://wpa.qq.com/msgrd?v=3&uin=270772735&site=qq&menu=yes';
        }

    });
    getOrderList();

    function Alert(str) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2
        });
    }

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1000)
            }
        });
    }
}