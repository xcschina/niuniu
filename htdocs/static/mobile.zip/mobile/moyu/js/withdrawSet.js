window.onload = function () {
    var setBtn = $('.withdraw-set-btn'),
        sendCode = $('#j-send-code'),
        userPhone = $('[name=mobile]').val(),
        pagehash = $('[name=pagehash]').val(),
        timer,
        count = 60,
        fpdFlag = false;
    setBtn.on('click', function (e) {
        e.preventDefault();
        formCheck();
    })
    sendCode.on('click', function (e) {
        var $this = $(this),
            payAccount = $('.payAccount').val().trim(),
            againPayAccount = $('.againPayAccount').val().trim(),
            userName = $('.userName').val().trim(),
            clickFlag = $this.attr('data-flag');
        if (!(/^(?:\w+\.?)*\w+@(?:\w+\.)+\w+|^[1][3,4,5,7,8][0-9]{9}$/.test(payAccount))) {
            Alert('请输入正确的支付宝账户');
            return;
        } else if (!(/^(?:\w+\.?)*\w+@(?:\w+\.)+\w+|^[1][3,4,5,7,8][0-9]{9}$/.test(againPayAccount))) {
            Alert('请再次输入正确的支付宝账户');
            return;
        } else if (payAccount !== againPayAccount) {
            Alert('二次支付宝账号不一致请重新输入');
            return;
        } else if (!(/^[\u4E00-\u9FA5A-Za-z]{2,20}$/.test(userName))) {
            Alert('请输入正确的姓名');
            return;
        } else {
            if (clickFlag == 1) return;
            $this.attr('data-flag', '1');
            downCount();
            $.ajax({
                url: '/user_certification.php?act=send_sms',
                type: 'POST',
                data: {
                    mobile: userPhone,
                    pagehash: pagehash,
                },
                dataType: 'text',
                success: function (res) {
                    var data = JSON.parse(base64decode(res.substr(1)));
                    loginFlag = false;
                    if (data.res == 1) {
                        Alert(data.msg);
                        codeValue = data.code;
                        console.log(codeValue);
                    } else {
                        Alert(data.msg);
                    }
                }

            })
        }
    })

    function downCount() {
        count--;
        sendCode.css('color', '#898989').html(count + '秒后再获取');
        if (count == 0) {
            downCountRest();
            return;
        }
        timer = setTimeout(function () {
            downCount();
        }, 1000);
    }

    function downCountRest() {
        clearTimeout(timer);
        sendCode.css('color', '#898989').html('重新再发送');
        count = 60;
        sendCode.attr('data-flag', '0');
    }

    function formCheck() {
        var payAccount = $('.payAccount').val().trim(),
            againPayAccount = $('.againPayAccount').val().trim(),
            userName = $('.userName').val().trim(),
            userCode = $('.userCode').val().trim();
        if (!(/^(?:\w+\.?)*\w+@(?:\w+\.)+\w+|^[1][3,4,5,7,8][0-9]{9}$/.test(payAccount))) {
            Alert('请输入正确的支付宝账户');
            return;
        } else if (!(/^(?:\w+\.?)*\w+@(?:\w+\.)+\w+|^[1][3,4,5,7,8][0-9]{9}$/.test(againPayAccount))) {
            Alert('请输入正确的支付宝账户');
            return;
        } else if (payAccount !== againPayAccount) {
            Alert('二次支付宝账号不一致请重新输入');
            return;
        } else if (!(/^[\u4E00-\u9FA5A-Za-z]{2,20}$/.test(userName))) {
            Alert('请输入正确的姓名');
            return;
        } else if (!userCode) {
            Alert('请输入验证码');
            return;
        }
        if (fpdFlag) return;
        fpdFlag = true;
        setBtn.text('提交中...');
        $.ajax({
            url: '/user_certification.php?act=set_pay_account',
            type: 'POST',
            data: {
                pay_account: payAccount,
                confirm_pay_account: againPayAccount,
                pay_name: userName,
                sms_code: userCode,
                mobile: userPhone,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    Alert(data.msg, function () {
                        window.location.href = data.url;
                    })
                } else {
                    Alert(data.msg);
                }
                setBtn.text('确认设置');
                fpdFlag = false;
            }

        })
    }

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                if (callBack) callBack();
            }
        });
    }
}