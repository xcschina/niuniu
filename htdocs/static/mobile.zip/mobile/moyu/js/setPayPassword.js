window.onload = function () {
    var setBtn = $('.set-password-btn'),
        sendCode = $('#j-send-code'),
        userPhone = $('[name=mobile]').val(),
        pagehash = $('[name=pagehash]').val(),
        codeValue,
        timer,
        count = 60,
        setFlag = false;
    setBtn.on('click', function (e) {
        e.preventDefault();
        setCheck();
    })
    sendCode.on('click', function (e) {
        var $this = $(this),
            userPassword = $('.userPassword').val().trim(),
            userAgainPassword = $('.userCPassword').val().trim(),
            clickFlag = $this.attr('data-flag');
        if (!(/^[a-zA-Z0-9]{6,18}$/.test(userPassword))) {
            Alert('密码为字母和数字,长度6-18个字符');
            return;
        } else if (!(/^[a-zA-Z0-9]{6,18}$/.test(userAgainPassword))) {
            Alert('密码为字母和数字,长度6-18个字符');
            return;
        } else if (userPassword !== userAgainPassword) {
            Alert('二次密码不一致请重新输入');
            return;
        } else {
            if (clickFlag == 1) return;
            $this.attr('data-flag', '1');
            downCount();
            $.ajax({
                url: '/user_certification.php?act=send_sms',
                type: 'POST',
                data: {
                    mobile: userPhone,
                    pagehash: pagehash,
                },
                dataType: 'text',
                success: function (res) {
                    var data = JSON.parse(base64decode(res.substr(1)));
                    if (data.code == 1) {
                        Alert(data.msg);
                        codeValue = data.code;
                        console.log(codeValue);
                    } else {
                        Alert(data.msg, function () {
                            downCountRest();
                        });
                    }
                    loginFlag = false;
                }

            })
        }
    })

    function downCount() {
        count--;
        sendCode.css('color', '#898989').html(count + '秒后再获取');
        if (count == 0) {
            downCountRest();
            return;
        }
        timer = setTimeout(function () {
            downCount();
        }, 1000);
    }

    function downCountRest() {
        clearTimeout(timer);
        sendCode.css('color', '#898989').html('重新再发送');
        count = 60;
        sendCode.attr('data-flag', '0');
    }

    function setCheck() {
        var userPassword = $('.userPassword').val().trim(),
            userAgainPassword = $('.userCPassword').val().trim(),
            userCode = $('.userCode').val().trim();
        if (!(/^[a-zA-Z0-9]{6,18}$/.test(userPassword))) {
            Alert('密码为字母和数字,长度6-18个字符');
            return;
        } else if (!(/^[a-zA-Z0-9]{6,18}$/.test(userAgainPassword))) {
            Alert('密码为字母和数字,长度6-18个字符');
            return;
        } else if (userPassword !== userAgainPassword) {
            Alert('二次密码不一致请重新输入');
            return;
        } else if (!userCode) {
            Alert('请输入验证码');
            return;
        }
        if (setFlag) return;
        setFlag = true;
        setBtn.text('设置中...');
        $.ajax({
            url: '/user_certification.php?act=set_pay_passward',
            type: 'POST',
            data: {
                pay_passward: userPassword,
                confirm_pay_passward: userAgainPassword,
                sms_code: userCode,
                mobile: userPhone,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    Alert(data.msg, function () {
                        window.location.href = data.url;
                    })
                } else {
                    Alert(data.msg);
                }
                setFlag = false;
                setBtn.text('确认设置');

            }

        })
    }

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                if (callBack) callBack();
            }
        });
    }
}