window.onload = function () {
    var flag = false,
        withdrawBtn = $('.withdraw-btn'),
        pagehash = $('[name=pagehash]').val(),
        moneyInput = $('.withdraw-money input'),
        balance = parseInt($('[name=balance]').val());
    withdrawBtn.on('click', function (e) {
        e.preventDefault();
        var myMoney = parseInt(moneyInput.val());
        if (!myMoney) {
            Alert('请输入正确充值金额')
            return;
        } else if (myMoney <= 0) {
            Alert('充值金额必须大于0');
            moneyInput.val('');
            return;
        }
        if (flag) return;
        flag = true;
        withdrawBtn.text('提现中...');
        $.ajax({
            url: '/user_certification.php?act=put_up_withdraw',
            type: 'POST',
            data: {
                money: myMoney,
                pagehash: pagehash,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                flag = false;
                if (data.code == 1) {
                    Alert(data.msg, function () {
                        window.location.href = data.url;
                    });
                } else if (data.code == 2) {
                    window.location.href = data.url;
                } else {
                    Alert(data.msg);
                    withdrawBtn.text('确认提现');
                }
            }
        });
    });

    function withdrawCount(myMoney) {
        var charge = myMoney * 0.02,
            actual = myMoney - charge,
            chargeVal = charge.toString().replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3', ''),
            actualVal = actual.toString().replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3', '');
        $('#charge-money').html('￥' + chargeVal);
        $('#actual-money').html('￥' + actualVal);
    }
    moneyInput.keyup(function () {
        checkMoney(this);
        parseInt($(this).val()) >= balance && $(this).val(balance);
        withdrawCount($(this).val());
    });

    $('.recharge-plat').on('click', '.selected', function () {
        var $this = $(this);
        if ($this.hasClass('on')) {
            $this.removeClass('on');
        } else {
            $this.addClass('on');
        }
    });


    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1.5,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1500)
            }
        });
    }

    function checkMoney(obj) {
        if (/^\d+\.?\d{0,2}$/.test(obj.value)) {
            obj.value = obj.value;
        } else {
            obj.value = obj.value.substring(0, obj.value.length - 1);
        }
    }

}