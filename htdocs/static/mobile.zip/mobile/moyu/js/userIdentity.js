window.onload = function () {
    var certificateBtn = $('.certificate-btn'),
        btnFlag = false;
    certificateBtn.on('click', function (e) {
        e.preventDefault();
        var userName = $('.userName').val().trim(),
            userCard = $('.userCard').val().trim();
        if (!(/^[\u4E00-\u9FA5A-Za-z]{2,20}$/.test(userName))) {
            Alert('请输入正确的姓名');
            return;
        } else if (!(/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(userCard))) {
            Alert('请输入正确的身份证号');
            return;
        }
        if (btnFlag) return;
        btnFlag = true;
        certificateBtn.text('认证中...');
        $.ajax({
            url: '/user_certification.php?act=user_certification',
            type: 'POST',
            data: {
                real_name: userName,
                id_card: userCard,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    Alert('认证成功', function () {
                        window.location.href = data.url;
                    })
                } else {
                    Alert(data.msg);
                }
                loginBtn.text('提交认证');
                btnFlag = false;
            }

        })
    })

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                if (callBack) callBack();
            }
        });
    }
}