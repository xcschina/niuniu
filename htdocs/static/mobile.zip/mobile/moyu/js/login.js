window.onload = function () {
    var loginBtn = $('.login-btn'),
        pagehash = $('[name=pagehash]').val(),
        loginFlag = false;
    loginBtn.on('click', function (e) {
        e.preventDefault();
        loginCheck();
    })

    function loginCheck() {
        var userPhone = $('.userPhone').val().trim(),
            userPassword = $('.userPassword').val().trim();
        if (!userPhone) {
            Alert('请输入手机号码');
            return;
        } else if (!(/^[1][3,4,5,7,8][0-9]{9}$/.test(userPhone))) {
            Alert('请输入正确的手机号');
            return;
        } else if (!(/^[a-zA-Z0-9]{6,18}$/.test(userPassword))) {
            Alert('密码为字母和数字,长度6-18个字符');
            return;
        }
        if (loginFlag) return;
        loginFlag = true;
        loginBtn.text('登录中...');
        $.ajax({
            url: '/login.php?act=do_login',
            type: 'POST',
            data: {
                mobile: userPhone,
                password: userPassword,
                pagehash: pagehash,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                loginFlag = false;
                if (data.code == 1) {
                    Alert('登录成功', function () {
                        window.location.href = data.url;
                    })
                } else {
                    Alert(data.msg);
                }
                loginBtn.text('登录'); 
            }

        })
    }

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1.5,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1500)
            }
        });
    }
}