window.onload = function () {
    var regBtn = $('.register-btn'),
        sendCode = $('#j-send-code'),
        pagehash = $('[name=pagehash]').val(),
        timer,
        count = 60,
        regFlag = false;

    regBtn.on('click', function (e) {
        e.preventDefault();
        registerCheck();
    })
    sendCode.on('click', function (e) {
        var $this = $(this),
            userPhone = $('.userPhone').val().trim(),
            clickFlag = $this.attr('data-flag');
        if (!userPhone) {
            Alert('请输入您的手机号');
            return;
        } else if (!(/^[1][3,4,5,7,8][0-9]{9}$/.test(userPhone))) {
            Alert('请输入正确的手机号');
            return;
        } else {
            if (clickFlag == 1) return;
            $this.attr('data-flag', '1');
            downCount();
            $.ajax({
                url: '/login.php?act=register_sms_m',
                type: 'POST',
                data: {
                    mobile: userPhone,
                    pagehash: pagehash,
                },
                dataType: 'text',
                success: function (res) {
                    var data = JSON.parse(base64decode(res.substr(1)));
                    if (data.code == 1) {
                        Alert(data.msg);
                        codeValue = data.ver_code;
                        console.log(codeValue);
                    } else {
                        Alert(data.msg, function () {
                            downCountRest();
                        });
                    }
                    $this.attr('data-flag', '0');
                }

            })
        }
    });

    function downCountRest() {
        clearTimeout(timer);
        sendCode.css('color', '#898989').html('重新再发送');
        count = 60;
        sendCode.attr('data-flag', '0');
    }

    function downCount() {
        count--;
        sendCode.css('color', '#898989').html(count + '秒后再获取');
        if (count == 0) {
            clearTimeout(timer);
            sendCode.css('color', '#898989').html('重新再发送');
            count = 60;
            sendCode.attr('data-flag', '0');
            return;
        }
        timer = setTimeout(function () {
            downCount();
        }, 1000);
    }

    function registerCheck() {
        var userPhone = $('.userPhone').val().trim(),
            userCode = $('.userCode').val().trim(),
            userPassword = $('.userPassword').val().trim(),
            userAgainPassword = $('.userCPassword').val().trim();
        if (!userPhone) {
            Alert('请输入手机号码');
            return;
        } else if (!(/^[1][3,4,5,7,8][0-9]{9}$/.test(userPhone))) {
            Alert('请输入正确的手机号');
            return;
        } else if (!userCode) {
            Alert('请输入验证码');
            return;
        } else if (!(/^[a-zA-Z0-9]{6,18}$/.test(userPassword))) {
            Alert('密码为字母和数字,长度6-18个字符');
            return;
        } else if (!(/^[a-zA-Z0-9]{6,18}$/.test(userAgainPassword))) {
            Alert('密码为字母和数字,长度6-18个字符');
            return;
        } else if (userPassword !== userAgainPassword) {
            Alert('二次密码不一致请重新输入');
            return;
        }
        if (regFlag) return;
        regFlag = true;
        regBtn.text('注册中...');
        $.ajax({
            type: 'post',
            url: '/login.php?act=do_register',
            data: {
                mobile: userPhone,
                sms_code: userCode,
                pagehash: pagehash,
                password: userPassword,
                cpassword: userAgainPassword
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                regFlag = false;
                if (data.code == 1) {
                    Alert('注册成功', function () {
                        window.location.href = data.url;
                    })
                } else {
                    Alert(data.msg);
                }
                regBtn.text('立即注册');
            }
        })
    }

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1.5,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1500)
            }
        });
    }
}