window.onload = function () {
    var $goodsItem = $('.goods-check-item'),
        goodsLose = $('.goods-list-lose'),
        goodsCollect = $('.goods-list-editor'),
        checkAll = $('.goods-check-all'),
        pagehash = $('[name=pagehash]').val(),
        goodsId = [],
        goodsStr = '',
        loading = $('.ui-loading'),
        editBtn = $('.collect-edit-btn'),
        userId = $('[name=user_id]').val();
    checkAll.on('click', function () {
        var $this = $(this);
        goodsId = [];
        singleId = [];
        if ($this.hasClass('on')) {
            $this.removeClass('on');
            $('.goods-check-item').removeClass('on');
        } else {
            $this.addClass('on');
            $('.goods-check-item').addClass('on');
            goodsCollect.find('.goods-check-item').each(function () {
                goodsId.push($(this).data('id'));
            })
            goodsStr = goodsId.join(',')
            console.log(goodsId);
        }
    });

    editBtn.on('click', function (e) {
        e.preventDefault();
        var $this = $(this);
        if ($this.text() == '编辑') {
            $this.text('取消');
            $('.m-goods-pancel').css('display', '-webkit-box');
            goodsCollect.find('.goods-check-item').css('display', '-webkit-box');
        } else {
            $this.text('编辑');
            $('.m-goods-pancel').hide();
            goodsCollect.find('.goods-check-item').hide();
        }

    });

    goodsCollect.on('click', '.goods-check-item', function (e) {
        e.stopPropagation();
        e.preventDefault();
        var $this = $(this),
            curId = $this.data('id');
        if ($this.hasClass('on')) {
            $this.removeClass('on');
            for (var i = 0; i < goodsId.length; i++) {
                if (goodsId[i] == curId) {
                    goodsId.splice(i, 1);
                }
            }
        } else {
            $this.addClass('on');
            goodsId.push($(this).data('id'));
        }
        goodsStr = goodsId.join(',');
        console.log(goodsId);

    });

    $('.goods-delete-btn').on('click', function () {
        if (!goodsCollect.find('.goods-check-item').hasClass('on')) {
            Alert('请选中要删除的商品');
        } else if (checkAll.hasClass('on')) {
            Confirm('是否删除所有商品？', function () {
                deleteCollectGoods();
            });
        } else {
            Confirm('是否删选中的商品？', function () {
                deleteCollectGoods();
            });
        }
    });
    // 获取收藏接口
    function goodsCollectList() {
        $.ajax({
            url: '/moyu_product.php?act=get_user_collect_list',
            type: 'POST',
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    var list = data.data;
                    if (list.length > 0) {
                        $('.goods-list-editor ul').append(collectlistTpl(list));
                        $('.collect-edit-btn').show();
                    }
                    collectLoseList();
                } else {
                    console.log(data.msg);
                }
            }

        })
    }
    // 收藏失效接口
    function collectLoseList() {
        $.ajax({
            url: '/moyu_product.php?act=get_user_invalid_collect_list',
            type: 'POST',
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    var list = data.data;
                    if (list.length > 0) {
                        $('.goods-list-lose').show();
                        $('.goods-list-lose ul').append(loseListTpl(list));
                    } else {
                        goodsLose.find('li').length == 0 && goodsCollect.find('li').length == 0 && $('.ui-nores').show() && $('.collect-edit-btn').hide();
                    }
                } else {
                    console.log(data.msg);
                }
            }
        })
    }
    // 收藏模板
    function collectlistTpl(list) {
        var html = '',
            li;
        for (var i = 0; i < list.length; i++) {
            li = list[i];
            html += '<li>';
            html += '<a href="/productDetail/' + li.product_id + '">';
            html += '<div class="goods-check-item" data-id="' + li.id + '"></div>';
            html += '<div class="content">';
            html += '<div class="tit">';
            html += '<strong>魔石</strong>';
            if (li.user_id != 1) {
                html += '<p>' + li.num + '魔石（1元=' + li.proportion + '魔石）</p>';
            } else {
                html += '<p>[担保]' + li.num + '魔石（1元=' + li.proportion + '魔石）</p>';
            }
            html += '</div>';
            html += '<div class="info">';
            if (li.serv_name) {
                html += '<p>' + li.channel_name + ' | ' + li.serv_name + '|' + li.game_name + '</p>';
            } else if (li.serv_id == 0) {
                html += '<p>' + li.channel_name + ' | 全区全服 | ' + li.game_name + '</p>';
            }
            if (li.user_certification == 1) {
                html += '<i class="is-card"></i>';
            }
            if (li.user_id != 1) {
                html += '<i class="is-dang"></i>';
            }
            html += '</div>';
            html += '<div class="price">￥' + li.price + '</div>';
            html += '</div>';
            html += '</a>';
            html += '</li>';
        }
        return html;
    }
    // 收藏失效模板
    function loseListTpl(list) {
        var html = '',
            li;
        for (var i = 0; i < list.length; i++) {
            li = list[i];
            html += '<li>';
            html += '<a href="/productDetail/' + li.product_id + '">';
            html += '<div class="goods-check-item" data-id="' + li.id + '"></div>';
            html += '<div class="content">';
            html += '<div class="tit">';
            html += '<strong>魔石</strong>';
            if (li.user_id != 1) {
                html += '<p>' + li.num + '魔石（1元=' + li.proportion + '魔石）</p>';
            } else {
                html += '<p>[担保]' + li.num + '魔石（1元=' + li.proportion + '魔石）</p>';
            }
            html += '</div>';
            html += '<div class="info">';
            if (li.serv_name) {
                html += '<p>' + li.channel_name + ' | ' + li.serv_name + '|' + li.game_name + '</p>';
            } else if (li.serv_id == 0) {
                html += '<p>' + li.channel_name + ' | 全区全服 | ' + li.game_name + '</p>';
            }
            if (li.user_certification == 1) {
                html += '<i class="is-card"></i>';
            }
            if (li.user_id != 1) {
                html += '<i class="is-dang"></i>';
            }
            html += '</div>';
            html += '<div class="price">￥' + li.price + '</div>';
            html += '</div>';
            html += '</a>';
            html += '</li>';
        }
        return html;
    }

    goodsCollectList();
    //删除收藏商品
    function deleteCollectGoods() {
        layer.closeAll();
        var loadLayer = layer.open({
            type: 2,
            shadeClose: false,
            content: '正在删除'
        });
        console.log(goodsId);
        $.ajax({
            url: '/trading_center.php?act=del_collect',
            type: 'POST',
            data: {
                pagehash: pagehash,
                user_id: userId,
                goods_list: goodsStr
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    goodsCollect.find('.goods-check-item.on').parent().parent().remove();
                    layer.close(loadLayer);
                    Alert(data.msg);
                    goodsId = [];
                    goodsCollect.find('li').length == 0 && goodsCollect.remove() && $('.collect-edit-btn').remove();
                    goodsLose.find('li').length == 0 && goodsCollect.find('li').length == 0 && $('.ui-nores').show() && $('.collect-edit-btn').hide();
                } else {
                    Alert(data.msg);
                }
            }

        })
    }

    //清空失效商品
    $('.empty-goods-btn').on('click', function () {
        Confirm('是否清空失效商品？', function () {
            layer.closeAll();
            var loadLayer = layer.open({
                type: 2,
                shadeClose: false,
                content: '正在清空'
            });
            $.ajax({
                url: '/trading_center.php?act=clear_invalid',
                type: 'POST',
                data: {
                    pagehash: pagehash,
                    user_id: userId
                },
                dataType: 'text',
                success: function (res) {
                    var data = JSON.parse(base64decode(res.substr(1)));
                    if (data.code == 1) {
                        layer.close(loadLayer);
                        Alert(data.msg);
                        goodsLose.remove();
                        goodsLose.length == 0 && goodsCollect.length == 0 && $('.ui-nores').show() && $('.collect-edit-btn').hide();
                    } else {
                        Alert(data.msg);
                    }
                }

            })
        });
    });

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                if (callBack) callBack();
            }
        });
    }

    function Confirm(html, callBack) {
        layer.open({
            className: 'layui-confirm',
            content: '<p class="msg">' + html + '<p>',
            btn: ['确认', '取消'],
            shadeClose: false,
            yes: function () {
                callBack();
            }
        });
    }
}