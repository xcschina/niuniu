window.onload = function () {
    var goodsList = $('.goods-list ul'),
        loading = $('.ui-loading'),
        status = $('[name=is_pub]').val(),
        goodsType = '';
    if (status == '') {
        status = 0;
        goodsType = ''
    } else if (status == 1) {
        status = 2;
        goodsType = 1;
    } else if (status == 5) {
        status = 1;
        goodsType = 5;
    }
    $('.goods-tab li').removeClass('on').eq(status).addClass('on');
    $('.goods-tab').on('click', 'li', function () {
        var $this = $(this);
        goodsType = $this.data('type');
        if ($this.text() == '全部') goodsType = '';
        if ($this.hasClass('on')) return;
        $this.addClass('on').siblings().removeClass('on');
        $('.ui-nores').hide();
        getOrderList();
    });

    //获取订单列表
    function getOrderList() {
        goodsList.empty();
        loading.css('display', '-webkit-box');
        $.ajax({
            url: '/trading_center.php?act=get_sell_product_data',
            type: 'POST',
            data: {
                status: goodsType,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                loading.hide();
                if (data.code == 1) {
                    console.log(data.data);
                    goodsList.append(goodsRoderTpl(data.data));
                } else {
                    $('.ui-nores').show();
                    console.log(data.msg);
                }
            }
        });
    }
    //订单模板
    function goodsRoderTpl(data) {
        var html = '',
            li;
        for (var i = 0; i < data.length; i++) {
            li = data[i];
            html += '<li data-id="' + li.id + '">';
            html += '<div class="time">';
            if (li.is_pub == 5) {
                html += '<span>提交审核时间：' + li.add_time + '</span>';
            } else if (li.is_pub == 1) {
                html += '<span>上架时间：' + li.audit_time + '</span>';
                html += '<span>下架时间：' + li.end_time + '</span>';
            } else if (li.is_pub == 0) {
                html += '<span>下架时间：' + li.end_time + '</span>';
                html += '<span class="ca1a">已下架</span>';
            } else if (li.is_pub == 6) {
                html += '<span>提交审核时间：' + li.add_time + '</span>';
                html += '<span class="ca1a">已取消发布</span>';
            } else if (li.is_pub == 3) {
                html += '<span>提交审核时间：' + li.add_time + '</span>';
                html += '<span class="ca1a">审核未通过</span>';
            }
            html += '</div>';
            html += '<a href="/trading_center.php?act=sell_product_detail&id=' + li.id + '" class="content">';
            html += '<div class="tit"><strong>魔石</strong><p>[担保]' + li.num + '魔石（1元=' + li.proportion + '魔石）</p></div>';
            if (li.serv_id > 0) {
                html += '<div class="info">' + li.game_name + '>' + li.channel_name + '>' + li.serv_name + '</div>';
            } else {
                html += '<div class="info">' + li.game_name + '>' + li.channel_name + '>全区全服</div>';
            }
            html += '<div class="count">';
            html += '<span>售价：<em>￥' + li.price + '</em></span>';
            html += '<span>库存：<em>' + li.stock + '</em></span>';
            html += '</div>';
            html += '</a>';
            html += '<div class="bottom">';
            html += '<div class="number">';
            html += '<span class="collect-num">' + li.collect_num + '</span>';
            html += '<span class="view-num">' + li.see_num + '</span>';
            html += '</div>';
            html += '<div class="btns">';
            if (li.is_pub == 5) {
                html += '<a href="" class="cancel-btn cff8" data-time="' + li.add_time + '" data-index="' + i + '" data-id="' + li.id + '" data-pub="' + li.is_pub + '">取消发布</a>';
            } else if (li.is_pub == 3 || li.is_pub == 6 || li.is_pub == 0) {
                html += '<a href="/moyu_product.php?act=edit_product_view&id=' + li.id + '" class="cff8">修改信息</a>';
                html += '<a class="delete-btn c9a9" data-index="' + i + '" data-id="' + li.id + '" data-pub="' + li.is_pub + '">删除</a>';
            } else if (li.is_pub == 1) {
                html += '<a class="unload-btn c4fa" data-time="' + li.add_time + '" data-index="' + i + '" data-id="' + li.id + '" data-pub="' + li.is_pub + '">下架</a>';
            }
            html += '</div>';
            html += '</div>';
            html += '</li>';
        }
        return html;
    }
    //商品编辑
    $('.goods-list').on('click', '.cancel-btn,.delete-btn,.unload-btn', function (e) {
        e.preventDefault();
        var $this = $(this),
            $index = $this.data('index'),
            $text = $this.text(),
            orderPub = $this.data('pub'),
            addTime = $this.data('time'),
            orderId = $this.data('id');
        layer.open({
            className: 'layui-confirm',
            content: '<div class="msg">是否要' + $text + '？</div>',
            btn: ['确认', '取消'],
            shadeClose: false,
            yes: function () {
                layer.closeAll();
                var loadLayer = layer.open({
                    type: 2,
                    shadeClose: false
                });
                $.ajax({
                    url: '/moyu_product.php?act=update_products_status',
                    type: 'POST',
                    data: {
                        id: orderId,
                        is_pub: orderPub,
                    },
                    dataType: 'text',
                    success: function (res) {
                        var data = JSON.parse(base64decode(res.substr(1)));
                        layer.closeAll();
                        if (data.code == 1) {
                            Alert(data.msg, function () {
                                if (orderPub == 6 || orderPub == 0 || orderPub == 3) {
                                    $('.goods-list li').each(function () {
                                        if ($(this).data('id') == orderId) {
                                            $(this).remove();
                                        }
                                    });
                                } else if (orderPub == 5) {
                                    $('.goods-list li').each(function () {
                                        if ($(this).data('id') == orderId) {
                                            $(this).find('.btns').html('<a class="cff8" href="moyu_product.php?act=edit_product_view&id=' + orderId + '">修改信息</a><a class="delete-btn c9a9" data-index="' + $index + '" data-id="' + orderId + '" data-pub="6">删除</a>');
                                            $(this).find('.time').html('<span>提交审核时间：' + addTime + '</span><span class="ca1a">已取消发布</span>');
                                        }
                                    });
                                } else if (orderPub == 1) {
                                    $('.goods-list li').each(function () {
                                        if ($(this).data('id') == orderId) {
                                            $(this).find('.btns').html('<a class="cff8" href="moyu_product.php?act=edit_product_view&id=' + orderId + '">修改信息</a><a class="delete-btn c9a9" data-index="' + $index + '" data-id="' + orderId + '" data-pub="0">删除</a>');
                                            $(this).find('.time').html('<span>提交审核时间：' + addTime + '</span><span class="ca1a">已下架</span>');
                                        }
                                    });
                                }
                                if ($('.goods-list li').length == 0) $('.ui-nores').show();
                                console.log($('.goods-list li').length);
                            });
                        } else {
                            Alert(data.msg);
                        }
                    }
                })
            }
        });
    });

    //联系客服
    $('.goods-list').on('click', '.guest-btn,.refund-btn', function (e) {
        e.preventDefault();
        var u = navigator.userAgent;
        if (/Safari/.test(u) && !/Chrome/.test(u)) {
            alert('请添加客服QQ：270772735');
        } else {
            window.location.href = 'http://wpa.qq.com/msgrd?v=3&uin=270772735&site=qq&menu=yes';
        }

    });

    getOrderList();

    function Alert(str) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2
        });
    }

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1000)
            }
        });
    }
}