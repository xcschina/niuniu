$(function () {
    new Swiper('.swiper-container-banner', {
        pagination: '.swiper-pagination',
        autoplay: 3e3,
        autoplayDisableOnInteraction: !1
    })

})