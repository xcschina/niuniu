window.onload = function () {
    var searchMod = $('.mod-search'),
        goodsList = $('.m-goods-list ul'),
        loading = $('.ui-loading'),
        gameId = $('[name=game_id]').val(),
        $mask = $('.mask'),
        priceLow = $('.choose_input_s'),
        priceHigh = $('.choose_input_s2 '),
        flag = false,
        goodsObj = {
            type: '',
            platform: '',
            serv_id: '',
            game_name: '',
            game_id: gameId,
            title: '',
            ch_id: '',
            price_order: '',
            price_pre: '',
            price_aft: ''
        };
    //搜索
    searchMod.on('click', 'a', function (e) {
        e.preventDefault();
        goodsObj.title = searchMod.find('input').val().trim();
        $mask.trigger('click');
        if (!goodsObj.title) {
            Alert('请输入游戏名称和商品标题');
            return;
        }
        $('.ui-nores').hide();
        getGoodsList();
    });
    // 选择机型
    $('.goods-filter-device').on('click', 'li', function () {
        var $this = $(this);
        if ($this.hasClass('on')) return;
        $('.goods-filter-tab li:nth-child(1)').removeClass('on').addClass('selected');
        $('.goods-filter-tab li:nth-child(1) span').text($this.text());
        $this.addClass('on').siblings().removeClass('on');
        goodsObj.platform = $this.data('type');
        $('.ui-nores').hide();
        $mask.trigger('click');
        getGoodsList();

    });
    //排序
    $('.goods-filter-sort').on('click', 'li', function () {
        var $this = $(this);
        if ($this.hasClass('on')) return;
        $this.addClass('on').siblings().removeClass('on');
        goodsObj.price_order = $this.data('name');
    });
    // 选择服务器
    $('.goods-zone-left').on('click', 'li', function () {
        var $this = $(this);
        if ($this.hasClass('on')) return;
        goodsObj.ch_id = $this.data('id');
        $this.addClass('on').siblings().removeClass('on');
        $.ajax({
            url: '/moyu_product.php?act=get_game_servs_list',
            type: 'POST',
            data: {
                id: $this.data('id'),
                game_id: goodsObj.game_id,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    var areaData = data.data,
                        zoneHtml = '',
                        li;
                    for (var i = 0; i < areaData.length; i++) {
                        li = areaData[i];
                        zoneHtml += '<li data-severid=' + li.id + '>' + li.serv_name + '</li>';
                    }
                    $('.goods-search-list').empty().append(zoneHtml);
                } else {
                    console.log(data.msg);
                }
            }
        })

    });
    $('.goods-search-list').on('click', 'li', function () {
        var $this = $(this);
        if ($this.hasClass('on')) return;
        $('.goods-filter-tab li:nth-child(2)').removeClass('on').addClass('selected');
        $('.goods-filter-tab li:nth-child(2) span').text($this.text());
        $this.addClass('on').siblings().removeClass('on');
        goodsObj.serv_id = $this.data('severid');
        $('.ui-nores').hide();
        $mask.trigger('click');
        getGoodsList();
    });
    $('.price_item').on('click', function () {
        var $this = $(this),
            $index = $this.index();
        $this.addClass('on').siblings().removeClass('on');
        switch ($index) {
            case 0:
                priceLow.val('0');
                priceHigh.val('30');
                break;
            case 1:
                priceLow.val('30');
                priceHigh.val('100');
                break;
            case 2:
                priceLow.val('100');
                priceHigh.val('200');
                break;
            case 3:
                priceLow.val('200');
                priceHigh.val('500');
                break;
            case 4:
                priceLow.val('500');
                priceHigh.val('1000');
                break;
            case 5:
                priceLow.val('2000');
                priceHigh.val('最高价格');
                break;
        }
    });
    //重置
    $('.price-bottom').on('click', '.reset-btn', function () {
        priceLow.val('');
        priceHigh.val('');
        $('.goods-filter-sort li').removeClass('on');
        $('.goods-filter-tab li:nth-child(3)').removeClass('selected');
        $('.price_item').removeClass('on');
        $mask.trigger('click');
    });
    //确认
    $('.price-bottom').on('click', '.submit-btn', function () {
        $('.goods-filter-tab li:nth-child(3)').removeClass('on').addClass('selected');
        goodsObj.price_pre = priceLow.val();
        goodsObj.price_aft = priceHigh.val() == '最高价格' ? '' : priceHigh.val();
        $('.ui-nores').hide();
        $mask.trigger('click');
        getGoodsList();
    });
    // tab
    $('.goods-filter-tab').on('click', 'li', function () {
        var $this = $(this),
            $index = $this.index();
        if ($this.hasClass('on')) {
            $mask.trigger('click');
        } else {
            $this.addClass('on').siblings().removeClass('on');
            $('.goods-filter-wrap').hide().eq($index).show();

        }
    });

    //关闭
    $mask.fadeIn().on('click', function () {
        $('.goods-filter-wrap').hide();
        $('.goods-filter-tab li').removeClass('on');
    });

    //获取商品列表
    function getGoodsList() {
        if (flag) return;
        flag = true;
        goodsList.empty();
        loading.css('display', '-webkit-box');
        $.ajax({
            url: '/moyu_product.php?act=get_real_product',
            type: 'POST',
            data: {
                type: 5,
                platform: goodsObj.platform,
                serv_id: goodsObj.serv_id,
                game_name: goodsObj.game_name,
                game_id: goodsObj.game_id,
                title: goodsObj.title,
                ch_id: goodsObj.ch_id,
                price_pre: goodsObj.price_pre,
                price_aft: goodsObj.price_aft,
                price_order: goodsObj.price_order
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                flag = false;
                loading.hide();
                if (data.code == 1) {
                    console.log(data);
                    goodsList.append(searchListTpl(data.data));
                } else {
                    $('.ui-nores').show();
                    console.log(data.msg);
                }
            }
        })
    }

    function searchListTpl(data) {
        var html = '',
            li;
        for (var i = 0; i < data.length; i++) {
            li = data[i];
            html += '<li>';
            html += '<a  href="/productDetail/' + li.id + '">';
            if (li.user_id != 1) {
                html += '<div class="tit"><strong>魔石</strong><p>[担保]' + li.num + '魔石（1元=' + li.proportion + '魔石）</p></div>';
            } else {
                html += '<div class="tit"><strong>魔石</strong><p>' + li.num + '魔石（1元=' + li.proportion + '魔石）</p></div>';
            }
            html += '<div class="info">';
            html += '<p>' + li.channel_name + ' | ' + li.sname + ' | ' + li.game_name + '</p>';
            if (li.user_certification == 1) {
                html += '<i class="is-card"></i>';
            }
            if (li.user_id != 1) {
                html += '<i class="is-dang"></i>';
            }
            html += '</div>';
            html += '<div class="price">￥' + li.price + '</div>';
            html += '</a>';
            html += '</li>';
        }
        return html;
    }
    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                if (callBack) callBack();
            }
        });
    }
}