window.onload = function () {
    var searchMod = $('.mod-search'),
        flag = false;
    searchMod.on('click', 'a', function (e) {
        e.preventDefault();
        var searchVal = searchMod.find('input').val().trim();

        if (!searchVal) {
            Alert('请输入查找内容');
            return;
        }
        if (flag) return;
        flag = true;
        layer.closeAll();
        var loadLayer = layer.open({
            type: 2,
            shadeClose: false,
        });
        $.ajax({
            url: '/trade_guide.php?act=get_article_data',
            type: 'POST',
            data: {
                title: searchVal,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                layer.close(loadLayer);
                if (data.code == 1) {
                    console.log(data);
                    $('.ui-nores').hide();
                    searchListTpl(data.data);
                } else {
                    $('.guide-search-list').empty();
                    $('.ui-nores').show();
                    console.log(data.msg);
                }
                flag = false;
            }
        })
    });

    function searchListTpl(data) {
        var html = '',
            li;
        for (var i = 0; i < data.length; i++) {
            li = data[i];
            html += '<p>';
            html += '<a href="trade_guide.php?act=get_article_info&amp;id=' + li.id + '">' + li.title + '</a>';
            html += '</p>';
        }
        return $('.guide-search-list').empty().append(html);
    }
    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                if (callBack) callBack();
            }
        });
    }
}