$(function () {
    var formdata,
        submitBtn = $('.screenshot-btn'),
        pagehash = $('[name=pagehash]').val(),
        goodsId = $('[name=id]').val(),
        flag = false;
    //提交审核 
    submitBtn.on('click', function (e) {
        e.preventDefault();
        var files1 = $('#fileImage0')[0].files[0],
            files2 = $('#fileImage1')[0].files[0],
            files3 = $('#fileImage2')[0].files[0];
        if (!files1) {
            Alert('请上传交易前截图');
            return;
        } else if (!files2) {
            Alert('请上传交易中截图');
            return;
        } else if (!files3) {
            Alert('请上传交易后截图');
            return;
        }
        if (flag) return;
        flag = true;
        formdata.append('pagehash', pagehash);
        formdata.append('id', goodsId);
        formdata.append('myImage1', files1);
        formdata.append('myImage2', files2);
        formdata.append('myImage3', files3);
        submitBtn.text('提交中...');
        $.ajax({
            url: '/trading_center.php?act=seller_delivery',
            type: 'post',
            data: formdata,
            processData: false,
            contentType: false,
            cache: false,
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    Alert(data.msg, function () {
                        window.location.href = data.url;
                    });
                } else {
                    submitBtn.text('提交审核');
                    Alert(data.msg);
                }
                flag = false;
            }
        });

    });
    //重新上传
    $(document).on('click', '.upload-close-btn', function () {
        var $index = $(this).data('index');
        $('.upload-view' + $index).remove();
        $('.upload-fileImage').eq($index).show();
        $('#fileImage' + $index).val('');
    })

    function submitForm() {
        var imgView = $('.upload-img');
        //上传图片
        $('.upload-img-btn').on('click', function (e) {
            e.preventDefault();
            $('#fileImage').click();
        });
    }
    $('.fileImage').change(function () {
        var files = this.files[0],
            $index = $(this).data('index');
        formdata = new FormData();
        if (!/image\/\w+/.test(files.type)) {
            return false;
        }
        var reader = new FileReader();
        reader.readAsDataURL(files);
        reader.onload = function (e) {
            var img = new Image();
            var res = this.result;
            img.onload = function () {
                imgWidth = this.width;
                imgHeight = this.height;
                $('.upload-form').eq($index).prepend(uploadHtml(res, $index));
                $('.upload-fileImage').eq($index).hide();
            }
            img.src = res;
        };
    });

    function uploadHtml(imgUrl, index) {
        var html = '';
        html += '<div class="upload-view upload-view' + index + '">';
        html += '<div class="upload-img" style="background-image:url(' + imgUrl + ')">';
        html += '<i class="upload-close-btn" data-index=' + index + '></i>';
        html += '</div>';
        html += '</div>';
        return html;
    }

    function checkImgType(value) {
        var filepath = value;
        var ext = filepath.substring(filepath.lastIndexOf(".") + 1, filepath.length).toUpperCase();
        var limit = 'GIF,JPG,JPEG,PNG';
        if (limit.indexOf(ext) == -1) {
            alert('图片格式出错，支持jpg, jpeg, png, gif');
            return false;
        } else {
            return true;
        }
    }

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1000)
            }
        });
    }
    submitForm();
})