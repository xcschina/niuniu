
window.onload = function () {
    var searchMod = $('.mod-search'),
        loading = $('.ui-loading'),
        servList = $('.mod-horizontal-list'),
        gameId = $('[name=game_id]').val(),
        chId = $('[name=ch_id]').val(),
        servName = '',
        flag = false;
    //搜索
    searchMod.on('click', 'a', function (e) {
        e.preventDefault();
        servName = searchMod.find('input').val().trim();
        if (!servName) {
            getServList();
            return;
        }
        if (flag) return;
        flag = true;
        servList.empty();
        $('.ui-nores').hide();
        loading.css('display', '-webkit-box');
        $.ajax({
            url: '/moyu_product.php?act=get_serv_name',
            type: 'POST',
            data: {
                id: chId,
                serv_name: servName,
                game_id: gameId,
            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                flag = false;
                loading.hide();
                if (data.code == 1) {
                    var areaData = data.data,
                        zoneHtml = '',
                        li;
                    console.log(data.data);
                    for (var i = 0; i < areaData.length; i++) {
                        li = areaData[i];
                        zoneHtml += '<li><a href="moyu_product.php?act=add_product_view&ch_id=' + chId + '&game_id=' + gameId + '&serv_id=' + li.id + '"">' + li.serv_name + '</a></li>';
                    }
                    servList.append(zoneHtml);
                } else {
                    $('.ui-nores').show();
                    console.log(data.msg);
                }
            }
        });
    });

    //获取服务器
    function getServList() {
        if (flag) return;
        flag = true;
        servList.empty();
        $('.ui-nores').hide();
        loading.css('display', '-webkit-box');
        $.ajax({
            url: '/moyu_product.php?act=get_game_servs_list',
            type: 'POST',
            data: {
                id: chId,
                serv_name: servName,
                game_id: gameId,

            },
            dataType: 'text',
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                flag = false;
                loading.hide();
                if (data.code == 1) {
                    var areaData = data.data,
                        zoneHtml = '',
                        li;
                    console.log(data.data);
                    for (var i = 0; i < areaData.length; i++) {
                        li = areaData[i];
                        zoneHtml += '<li><a href="moyu_product.php?act=add_product_view&ch_id=' + chId + '&game_id=' + gameId + '&serv_id=' + li.id + '"">' + li.serv_name + '</a></li>';
                    }
                    servList.append(zoneHtml);
                } else {
                    $('.ui-nores').show();
                    console.log(data.msg);
                }
            }
        });
    }
    getServList();

    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                if (callBack) callBack();
            }
        });
    }
}