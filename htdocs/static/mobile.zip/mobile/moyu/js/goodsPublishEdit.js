$(function () {
    // 修改
    var formdata,
        publishBtn = $('.goods-publish-btn'),
        pagehash = $('[name=pagehash]').val(),
        orderId = $('[name=order_id]').val(),
        conutPrice = $('#j-goods-price'),
        goodsNum = parseInt($('.goods-num').val()),
        goodsPrice = parseInt($('.goods-price').val()),
        old_img = '',
        addImgs = [],
        flag = false;
    publishBtn.on('click', function (e) {
        e.preventDefault();
        var goodsNum = strReplace($('.goods-num').val()),
            goodsPrice = strReplace($('.goods-price').val()),
            goodsStock = strReplace($('.goods-stock').val()),
            userQQ = strReplace($('.userQQ').val()),
            userPhone = strReplace($('.userPhone').val());
        if ($('.upload-item').length < 2) {
            Alert('请上传图片');
            return;
        } else if (!goodsNum) {
            Alert('请输入魔石');
            return;
        } else if (!goodsPrice) {
            Alert('请输入价格');
            return;
        } else if (!goodsStock) {
            Alert('请输入库存');
            return;
        } else if (!userQQ) {
            Alert('请输入QQ号');
            return;
        } else if (!(/^[1-9]\d{4,9}$/.test(userQQ))) {
            Alert('请输入正确的QQ号');
            return;
        } else if (!userPhone) {
            Alert('请输入手机号码');
            return;
        } else if (!(/^[1][3,4,5,7,8][0-9]{9}$/.test(userPhone))) {
            Alert('请输入手机号');
            return;
        }
        if (flag) return;
        flag = true;
        formdata.append('old_img', old_img);
        formdata.append('goodsNum', goodsNum);
        formdata.append('goodsprice', goodsPrice);
        formdata.append('goodsStock', goodsStock);
        formdata.append('userQQ', userQQ);
        formdata.append('userPhone', userPhone);
        formdata.append('pagehash', pagehash);
        formdata.append('order_id', orderId);
        publishBtn.text('修改中...');
        $.ajax({
            url: '/moyu_product.php?act=edit_products',
            type: 'post',
            data: formdata,
            processData: false,
            contentType: false,
            cache: false,
            success: function (res) {
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    Alert(data.msg, function () {
                        window.location.href = data.url;
                    });
                } else {
                    Alert(data.msg);
                    publishBtn.text('确认修改');
                }
                flag = false;
            }
        });

    });

    function addUploadImg() {
        $('.upload-close-btn').each(function () {
            var imgUrl = $(this).data('imgurl');
            if (imgUrl) addImgs.push($(this).data('imgurl'));
        });
        old_img = addImgs.join(',');
    }
    $(document).on('click', '.upload-close-btn', function () {
        $(this).parent().parent().remove();
    });
    $('.goods-num').keyup(function () {
        goodsNum = parseInt(strReplace(this.value));
        priceConut();

    });
    $('.goods-price').keyup(function () {
        goodsPrice = parseInt(strReplace(this.value));
        priceConut();
    });
    //商品单价
    function priceConut() {
        if (goodsNum && goodsPrice) {
            conutPrice.text(Math.round(goodsNum / goodsPrice));
        } else if (goodsNum == 0 || goodsPrice == 0) {
            conutPrice.text('?');
        }
    }

    function publishForm() {
        var imgView = $('.upload-img');
        //上传图片
        $('.upload-img-btn').on('click', function (e) {
            e.preventDefault();
            $('#fileImage').click();
        });
    }
    $('#fileImage').change(function () {
        var _this = this;
        var files = this.files;
        if (files.length + addImgs.length > 5) {
            Alert('最多只能上传5张图片');
            return;
        }
        formdata = new FormData();
        for (var i = 0; i < files.length; i++) {
            (function () {
                var temp = i;
                if (!_this.value || !checkImgType(_this.value)) return;
                formdata.append('myImage' + i, files[i]);
                var reader = new FileReader();
                reader.readAsDataURL(files[i]);
                reader.onload = function (e) {
                    compress(this.result, temp);
                };
            })()
        }
    });

    function compress(res, index) {
        var img = new Image();
        img.onload = function () {
            $('.upload-choose').prepend(uploadHtml(res));
        }
        img.src = res;
    }

    function uploadHtml(imgUrl) {
        var html = '';
        html += '<div class="upload-item">';
        html += '<div class="upload-img" style="background-image:url(' + imgUrl + ')">';
        html += '<i class="upload-close-btn"></i>';
        html += '</div>';
        html += '</div>';
        return html;
    }

    function checkImgType(value) {
        var filepath = value;
        var ext = filepath.substring(filepath.lastIndexOf(".") + 1, filepath.length).toUpperCase();
        var limit = 'GIF,JPG,JPEG,PNG';
        if (limit.indexOf(ext) == -1) {
            alert('图片格式出错，支持jpg, jpeg, png, gif');
            return false;
        } else {
            return true;
        }
    }

    function getObjectURL(file) {
        var url = null;
        if (window.createObjectURL != undefined) {
            url = window.createObjectURL(file)
        } else if (window.URL != undefined) {
            url = window.URL.createObjectURL(file)
        } else if (window.webkitURL != undefined) {
            url = window.webkitURL.createObjectURL(file)
        }
        return url;
    }
    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1000)
            }
        });
    }
    /* 字符串过滤 */
    function strReplace(str) {

        // str = $.trim(str);
        str = str.replace(/<\/?[^>]*>/g, '');
        str = str.replace(/\s+/g, '');
        str = str.replace(/(&nbsp;|&lt;|&gt;|&)/ig, '');
        return str;
    };

    publishForm();
    addUploadImg();
})