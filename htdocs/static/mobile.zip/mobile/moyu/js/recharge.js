window.onload = function () {
    var flag = false,
        rechargeBtn = $('.recharge-btn'),
        pagehash = $('[name=pagehash]').val(),
        payType = 1;
    rechargeBtn.on('click', function (e) {
        e.preventDefault();
        var myMoney = $('#j-my-money').val();
        if (!myMoney) {
            Alert('请输入正确充值金额')
            return;
        } else if (parseInt(myMoney) <= 0) {
            Alert('充值金额必须大于0');
            $('#j-my-money').val('');
            return;
        } else if (!$('.selected').hasClass('on')) {
            Alert('请选择支付方式');
            return;
        }
        if (flag) return;
        flag = true;
        rechargeBtn.text('充值中...');
        $.ajax({
            url: '/trading_center.php?act=user_recharge',
            type: 'POST',
            data: {
                money: myMoney,
                pay_mode: payType,
                pagehash: pagehash,
            },
            dataType: 'text',
            success: function (res) {
                flag = false;
                var data = JSON.parse(base64decode(res.substr(1)));

                if (data.code == 1) {
                    Alert(data.msg, function () {
                        window.location.href = data.url;
                    });
                } else if (data.code == 2) {
                    window.location.href = data.url;
                } else {
                    Alert(data.msg);
                    publishBtn.text('确认');
                }
            }
        });
    });

    $('#j-my-money').keyup(function () {
        checkMoney(this);
        //$(this).val(Num(this));
    });

    $('.recharge-plat').on('click', '.selected', function () {
        var $this = $(this);
        if ($this.hasClass('on')) {
            $this.removeClass('on');
        } else {
            $this.addClass('on');
        }
    });


    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 1.5,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1500)
            }
        });
    }

    function checkMoney(obj) {
        if (/^\d+\.?\d{0,2}$/.test(obj.value)) {
            obj.value = obj.value;
        } else {
            obj.value = obj.value.substring(0, obj.value.length - 1);
        }
    }

}