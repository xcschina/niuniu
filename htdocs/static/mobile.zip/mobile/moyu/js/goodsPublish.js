$(function () {
    // 发布
    var formdata,
        publishBtn = $('.goods-publish-btn'),
        pagehash = $('[name=pagehash]').val(),
        conutPrice = $('#j-goods-price'),
        goodsNum,
        goodsPrice,
        imgSrc = [],
        imgFile = [],
        imgName = [],
        flag = false;
    publishBtn.on('click', function (e) {
        e.preventDefault();
        var goodsNum = strReplace($('.goods-num').val()),
            goodsPrice = strReplace($('.goods-price').val()),
            goodsStock = strReplace($('.goods-stock').val()),
            userQQ = strReplace($('.userQQ').val()),
            userPhone = strReplace($('.userPhone').val());
        if ($('.upload-item').length < 2) {
            Alert('请上传图片');
            return;
        } else if (!goodsNum) {
            Alert('请输入魔石');
            return;
        } else if (!goodsPrice) {
            Alert('请输入价格');
            return;
        } else if (!goodsStock) {
            Alert('请输入库存');
            return;
        } else if (!userQQ) {
            Alert('请输入QQ号');
            return;
        } else if (!(/^[1-9]\d{4,9}$/.test(userQQ))) {
            Alert('请输入正确的QQ号');
            return;
        } else if (!userPhone) {
            Alert('请输入手机号码');
            return;
        } else if (!(/^[1][3,4,5,7,8][0-9]{9}$/.test(userPhone))) {
            Alert('请输入手机号');
            return;
        } else if (parseInt($('.goods-num').val()) > 100000000) {
            Alert('魔石数量不能大于100000000');
            return;
        } else if (parseInt($('.goods-stock').val()) > 99999) {
            Alert('商品库存不能大于99999');
            return;
        }
        if (flag) return;
        flag = true;
        formdata.append('goodsNum', goodsNum);
        formdata.append('goodsprice', goodsPrice);
        formdata.append('goodsStock', goodsStock);
        formdata.append('userQQ', userQQ);
        formdata.append('userPhone', userPhone);
        formdata.append('game_id', $('[name=game_id]').val());
        formdata.append('ch_id', $('[name=ch_id]').val());
        formdata.append('serv_id', $('[name=serv_id]').val());
        formdata.append('pagehash', pagehash);
        publishBtn.text('发布中...');
        // alert('11111');
        $.ajax({
            url: '/moyu_product.php?act=publish_product',
            type: 'post',
            contentType: false,
            processData: false,
            data: formdata,
            success: function (res) {
                alert(res);
                var data = JSON.parse(base64decode(res.substr(1)));
                if (data.code == 1) {
                    Alert(data.msg, function () {
                        window.location.href = data.url;
                    });
                } else {
                    Alert(data.msg);
                    publishBtn.text('确认中');
                }
                flag = false;
            }
        });

    });
    $('.goods-upload').on('click', '.upload-close-btn', function () {
        var index = $(this).data('index');
        removeImg(index);
    });
    $('.goods-num').keyup(function () {
        goodsNum = parseInt(strReplace(this.value));
        priceConut();

    });
    $('.goods-num').blur(function () {
        var curVal = parseInt($(this).val());
        if (!curVal || curVal == 0 || curVal < 1) {
            $(this).val(1) && (curVal = 1);
        }
        $(this).val(curVal);
        goodsNum = parseInt($(this).val());
        priceConut();

    });
    $('.goods-price').blur(function () {
        var curVal = parseInt($(this).val());
        if (!curVal || curVal == 0 || curVal < 1) {
            $(this).val(1) && (curVal = 1);
        }
        $(this).val(curVal);
        goodsPrice = parseInt($(this).val());
        priceConut();

    });
    $('.goods-price').keyup(function () {
        goodsPrice = parseInt(strReplace(this.value));
        priceConut();
    });
    //商品单价
    function priceConut() {
        if (goodsNum && goodsPrice) {
            conutPrice.text(Math.round(goodsNum / goodsPrice));
        } else if (goodsNum == 0 || goodsPrice == 0 || !goodsNum || !goodsPrice) {
            conutPrice.text('?');
        }
    }

    function publishForm() {
        var imgView = $('.upload-img');
        //上传图片
        $('.upload-img-btn').on('click', function (e) {
            e.preventDefault();
            $('#fileImage').click();
        });
    }
    $(document).on('change', '#fileImage', function () {
        var fileList = this.files;
        if (fileList.length + imgSrc.length > 5) {
            Alert('最多只能上传5张图片');
            return;
        }
        formdata = new FormData();
        for (var i = 0; i < fileList.length; i++) {
            if (!this.value || !checkImgType(this.value)) return;
            var imgSrcI = getObjectURL(fileList[i]);
            imgName.push(fileList[i].name);
            imgSrc.push(imgSrcI);
            imgFile.push(fileList[i]);
        }
        uploadHtml();
    });



    function uploadHtml() {
        $('.upload-choose').html('');
        var html = '';
        for (var i = 0; i < imgSrc.length; i++) {
            html += '<div class="upload-item">';
            html += '<div class="upload-img" style="background-image:url(' + imgSrc[i] + ')">';
            html += '<i class="upload-close-btn" data-index="' + i + '"></i>';
            html += '</div>';
            html += '</div>';
            formdata.append('myImage' + i, imgFile[i]);
        }
        html += '<div class="upload-item">';
        html += '<div class="upload-fileImage">';
        html += '<input id="fileImage" type="file" multiple="" accept="image/jpeg,image/png,image/gif" name="img">';
        html += '<a href="" class="upload-img-btn"></a>';
        html += '</div>';
        $('.upload-choose').html(html);
    }

    //删除
    function removeImg(index) {
        imgSrc.splice(index, 1);
        imgFile.splice(index, 1);
        imgName.splice(index, 1);
        uploadHtml();
    }

    function checkImgType(value) {
        var filepath = value;
        var ext = filepath.substring(filepath.lastIndexOf(".") + 1, filepath.length).toUpperCase();
        var limit = 'GIF,JPG,JPEG,PNG';
        if (limit.indexOf(ext) == -1) {
            alert('图片格式出错，支持jpg, jpeg, png, gif');
            return false;
        } else {
            return true;
        }
    }

    function getObjectURL(file) {
        var url = null;
        if (window.createObjectURL != undefined) {
            url = window.createObjectURL(file)
        } else if (window.URL != undefined) {
            url = window.URL.createObjectURL(file)
        } else if (window.webkitURL != undefined) {
            url = window.webkitURL.createObjectURL(file)
        }
        return url;
    }
    //Alert
    function Alert(str, callBack) {
        layer.open({
            className: 'layui-act-msg',
            shade: false,
            type: 1,
            content: str,
            time: 2,
            success: function (elem) {
                setTimeout(function () {
                    if (callBack) callBack();
                }, 1000)
            }
        });
    }
    /* 字符串过滤 */
    function strReplace(str) {

        // str = $.trim(str);
        str = str.replace(/<\/?[^>]*>/g, '');
        str = str.replace(/\s+/g, '');
        str = str.replace(/(&nbsp;|&lt;|&gt;|&)/ig, '');
        return str;
    };


    publishForm();
})