function _qs(name) {
    return document.querySelector(name);
}

function _qsa(name) {
    return document.querySelectorAll(name);
}

var _w = document.documentElement.clientWidth,
    _h = document.documentElement.clientHeight;

_qs('#w_face').style.height = (_h / (_w / 375) - 70 - 60) / 100 + 'rem';


var menu = {
    menuBox: _qs('#menuBox'),
    b_menuBox: _qs('#b_menuBox'),
    b_menu: _qs('#b_menu'),
    sw: 1,
    show: function() {
        var self = this;
        self.menuBox.classList.remove('show');
        self.menuBox.classList.remove('hide');
        setTimeout(function() {
            self.menuBox.classList.add('show');
            self.b_menuBox.setAttribute('data-open', 1);
            self.b_menu.classList.add('open');
            var li = this.menuBox.querySelectorAll('li');
            var i = 0,
                ii = li.length;
            var go = function(i) {
                self.sw = 1;
                if (i < ii) {
                    self.sw = 0;
                    setTimeout(function() {
                        li[i].classList.add('action');
                        go(++i);
                    }, 80);
                }
            };
            go(i);
        }, 10);
    },
    hide: function() {
        var self = this;
        self.sw = 0;
        self.menuBox.classList.add('hide');
        self.b_menuBox.setAttribute('data-open', 0);
        self.b_menu.classList.remove('open');
        setTimeout(function() {
            var li = self.menuBox.querySelectorAll('li');
            var i = 0,
                ii = li.length;
            for (; i < ii; i++) {
                li[i].classList.remove('action');
            }
            self.sw = 1;
        }, 300);
    },
    ev: function() {
        var self = this;
        self.b_menuBox.addEventListener('tap', function(e) {
            if (self.sw) {
                if (this.getAttribute('data-open') == '0') {
                    self.show();
                } else {
                    self.hide();
                }
            }
            e.preventDefault();
        });
    }
};

var banner = {
    init: function() {
        var imgSlide = new mo.Slide({
            target: $('#w_banner li'),
            direction: 'x',
            circle: true,
            controller: true,
            autoPlay: true,
            stay: 3000
        });
    }
};

var news = {
    init: function() {
        var tab = new mo.Tab({
            target: $('#w_news .con .item'),
            controller: $('#w_news .tab li')
        });
    }
};

var raiders = {
    init: function() {
        var tab = new mo.Tab({
            target: $('#w_raiders .con .item'),
            controller: $('#w_raiders .tab li')
        });
    }
};

var features = { //��Ϸ��ɫ
    list: _qs('#features_list'),
    controller_li: _qsa('#features_controller li'),
    pre: _qs('#features_pre'),
    next: _qs('#features_next'),
    cur: 0,
    sw: 1,
    move: function(n) {
        var self = this;
        if (n >= 0 && n <= 4) {
            this.sw = 0;
            this.list.style.webkitTransform = 'translate(' + (((-225 - 10) * n + 75) / 100) + 'rem,0)';
            setTimeout(function() {
                if (n >= 0 && n <= 4) {
                    var conList = self.list.querySelectorAll('li');
                    var i = 0,
                        ii = conList.length;
                    for (; i < ii; i++) {
                        conList[i].classList.remove('current');
                    }
                    conList[n].classList.add('current');
                    i = 0;
                    ii = self.controller_li.length;
                    for (; i < ii; i++) {
                        self.controller_li[i].classList.remove('current');
                    }
                    self.controller_li[n].classList.add('current');
                    self.cur = n;
                }
                if (n <= 0) {
                    self.pre.classList.add('hide');
                } else if (n >= 4) {
                    self.next.classList.add('hide');
                } else {
                    self.pre.classList.remove('hide');
                    self.next.classList.remove('hide');
                }
                self.sw = 1;
            }, 400);
        }
    },
    ev: function() {
        var self = this;
        new mo.Gesture(self.pre,{preventDefault:false}).addGesture('tap', function(e) {
            if (self.sw) {
                self.move(self.cur - 1);
            }
            e.preventDefault();
        });
        new mo.Gesture(self.next,{preventDefault:false}).addGesture('tap', function(e) {
            if (self.sw) {
                self.move(self.cur + 1);
            }
            e.preventDefault();
        });
        var gest = new mo.Gesture(self.list,{preventDefault:false}).addGesture('swiperight swipeleft', function(e) {
            switch (e.type) {
                case 'swiperight':
                    self.move(self.cur - 1);
                    break;
                case 'swipeleft':
                    self.move(self.cur + 1);
                    break;
            }
        });
    }
};
function init() {
    // setTimeout(function() {
    //     _qs('#b_menu').classList.add('ready');
    // }, 500);
    menu.ev();
    banner.init();
    news.init();
    raiders.init();
    features.ev();
    // face.ev();
}
init();
