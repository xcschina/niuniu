/**
 * Created by ong on 15/7/24.
 */
$(document).ready(function(){
    var keyup_timer;
    $("#search a.cancel").click(function(){cancel_search();});
    $("input.search-input").click(function(){$("#search").show();$("#keyword").focus();});
    // 获取焦点的时候激活提示框
    $("#keyword").on("focus", function () {
        keyword_search($("#keyword").val().trim());
    });

    // 每次输入的事件
    $("#keyword").on("input", function () {
        clearTimeout(keyup_timer);
        var keyword = $.trim($("#keyword").val());
        // 延时请求
        keyup_timer = setTimeout(function () {
            keyword_search(keyword);
        }, 300);
    });

    keyword_search = function (keyword, callback) {
        games = $.ajax({url:"index.php?act=keyword&keyword="+encodeURIComponent(keyword),async:false});
        games= jQuery.parseJSON(games.responseText);//转换为json对象
        $("#search-box").html("");
        $.each(games,function(idx,item){
            if(idx>9){
                return false;
            }
            cls = 'default';
            if(keyword!=""){
                cls='result';
                $("#search-box").append('<a href="\/game'+item.id+'" class="'+cls+'"><span>'+item.game_name+'</span><\/a>');
            }else{
                if(idx>5){
                    return false;
                }
                $("#search-box").append('<a href="\/game'+item.id+'" class="'+cls+'">'+item.game_name+'<\/a>');
            }
        });
    };
});

function cancel_search(){
    $("#search").hide();
    return false;
}