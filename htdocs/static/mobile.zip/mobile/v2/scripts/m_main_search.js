
// 搜索时事件绑定
var searchMain_timer;
var default_hot_search_con = "";
var search_page = 1;
var screenHeight = window.screen.height;
$(document).ready(function() {
	$(".main-search .main-search-bar input").focus();
})
// 输入框值变化
// 注意首页也是用的main-search-bar，要区分是首页的还是搜索栏的input话，
// 要多加css去定位，即$(".main-search .main-search-bar input")
$(".main-search .main-search-bar input").on("input", function(e) {
	var val = e.target.value;
	if(val == "") {
		$(".main-search-bar .clear-search").hide();
	}
	else {
		$(".main-search-bar .clear-search").show();
	}
	goSearchMain(val);
})
// 焦点放在输入框
$(".main-search .main-search-bar input").on("focus", function(e) {
	var val = e.target.value;
	searchGameMain(val);

})
// 点击搜索按钮
$(".main-search .main-search-bar .go-search").on("click", function(){
	var val = $(".main-search .main-search-bar input").val();
	searchGameMain(val);
})

// 清除搜索框内的文字
$(".main-search-bar .clear-search").on("click", function(e) {
	$(".main-search-bar input").val("");
	$(e.target).hide();
	$(".main-search-result .has-result")
	$(".main-search-con .get-status").hide();
	searchGameMain("")
})

// 加载更多
$(window).on("scroll",function() {

	if($(".main-search-result .has-result").is(':visible') && screenHeight + document.body.scrollTop >= document.body.scrollHeight) {
		var val = $(".main-search-bar input").val();
		goSearchMain(val, true);
		// console.log(search_page + "has-result html"+$(".has-result").is(':visible')+"screenHeight scrollTop"+(screenHeight + document.body.scrollTop)+"scrollHeight"+document.body.scrollHeight)
	}
})
// 输入搜索延时
function goSearchMain(keyword, more) {
	clearTimeout(searchMain_timer);
	searchMain_timer = setTimeout(function() {
		searchGameMain(keyword, more);
	}, 400);
}
// 搜索游戏
function searchGameMain(keyword, more) {
	keyword = keyword.trim();
	 var con = '';
    more ? null : search_page = 1;
	 var reqPage = keyword !== "" && more ? search_page + 1 : 1
        $.ajax({
            url: 'index.php?act=keyword',
            data: {
            		keyword: keyword,
        			page: reqPage
            },
            dataType: "json",
            type: "get"
        }).success(function (res) {
        	// 有关键词
        	if(keyword !== "") {
        		if(res.games == "") {
        			// 有关键词且加载更多时请求无结果
        			if(more) {
        				$(".main-search-con .get-status").html("没有了~").show();
        			}
        			// 有关键词且普通搜索请求无结果
        			else {
        				$(".main-search-tip").html('未找到包含<span class="red key">"'+ keyword + '"</span>的游戏').show();
        				$(".main-search-con .get-status").hide();
        				defaultHotSearch("", default_hot_search_con);
        			}
        		}
        		// 搜索有结果
	            else {
        			var str = res.games;
        			if((res.num - 10 * (reqPage-1)) <= 0){
        				con = "";
					}else{
	                	for (var i = 0; i < str.length; i++) {
                        var android = "";
                        var iOS = "";
                        var dis = "none";
	                	if(str[i].android == 1){
	                		android = "安卓";
	                		dis = "inline-block";
						}
						if(str[i].iOS == 1){
                            iOS = "iOS";
						}
						if(str[i].char_min_rate === "10.0"){
                            str[i].char_min_rate = "10";
						}
						if(str[i].refill_min_rate === "10.0" ){
                            str[i].refill_min_rate = "10" ;
						}
	                	con += '<li class="result-item m-border-bottom-grey"><a href="/game' + str[i].id + '">'
								+'<img src="http://cdn.66173.cn/' + str[i].game_icon + '" class="game-img"/>'
								+'<div class="center"><div class="title text-overflow">' + str[i].game_name + '</div><div class="grey desc text-overflow">' + str[i].game_intr + '</div>'
								+'<div class="grey pack text-overflow">安装包大小：<span>'+ str[i].game_size + '</span></div>'
								+'<div class="classify"><span style="display:' + dis + '" class="classify-item classify-android" >' + android + '</span><span class="classify-item classify-ios">'+ iOS +'</span></div>'
								+'</div>'
								+'<div class="tag-collection-right">'
								+'<a href="/game' + str[i].id + '/character" class="discount-icon fc-icon"><span class="charge-type">首充</span><span class="charge-discount">' + str[i].char_min_rate + '折起</span></a>'
								+'<a href="/game' + str[i].id + '/renew" class="discount-icon rec-icon"><span class="charge-type">续充</span><span class="charge-discount">' + str[i].refill_min_rate + '折起</span></a>'
								+'</div></a>'
								+'</li>'
	                	}
                    }
	                if(more) {
	                	search_page++;
	                	$(".main-search-result .has-result").append(con).show().siblings().hide();
	                }
	                else {
                        $(".main-search-result .has-result").html(con).show().siblings().hide();
	                }
	                $(".main-search-tip").html('以下是为您搜索到包含<span class="red key">"'+ keyword + '"</span>的<span class="red num ">' + res.num + '</span>款游戏').show();
	                // 搜索结果下加载更多或没有了
		            if(str.length < 10) {
		                $(".main-search-con .get-status").html("没有了~").show();
		            }
		           	else {
                        if((res.num - 10 * (reqPage-1)) <= 0){
                            $(".main-search-con .get-status").html("没有了~").show();
                        }else {
                            $(".main-search-con .get-status").html("上拉加载更多").show();
                        }
		            }
	            }
	        }
	        else {
	        	$(".main-search-result .has-result").hide();
	        	$(".main-search-tip").hide();
	        	$(".main-search-con .get-status").hide();
	        	defaultHotSearch(res, default_hot_search_con);
	        }
        })


}
// 热门搜索部分，没有搜索词或者搜索词无结果时有此
function defaultHotSearch(res, con) {
	if(!con){
		if (res == "") {
	        $(".main-search-result .default-result").hide();
	    } else {
			var str = res.games;
	    	default_hot_search_con += '<div class="hot-title">热门搜索</div><div class="list">'
	        for (var i = 0; i < 6; i++) {
	        	if(str[i]) {
	            	default_hot_search_con += '<a class="text-overflow default-item color' + (i+1) + '" href="/game' + str[i].id + '">' + str[i].game_name + '</a>';
	            }
	        }
	        default_hot_search_con += '</div>';
	    }
	}
	$(".main-search-result .default-result").html(default_hot_search_con).show().siblings().hide();
}