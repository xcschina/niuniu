// 搜索时事件绑定
var search_timer;
// 输入框值变化
$(".m-station .search-input1").on("input", function(e) {
    var val = e.target.value;
    goSearch(val)
})
// 焦点放在输入框
$(".m-station .search-input1").on("focus", function(e) {
    var val = e.target.value;
    goSearch(val);
    searchBlockToggle();

})
// 点击搜索按钮
$(".search-block .icon-block").on("click", function(){
    var val = $(".search-input1").val();
    goSearch(val);
    searchBlockToggle();
})
// 点击取消搜索
$(".cancel-search-block").on("click", function(e) {
    $(".login-in-link, .login-on-link").show();
    $(".below-search-cont").show();
    $(".search-input1").val("");
    $(".game-search-result .has-result, .game-search-result .no-result, .game-search-result .default-result").hide();
    $(e.target).hide();
})
function searchBlockToggle() {
    $(".below-search-cont").hide();
    $(".cancel-search-block").show().css("display","inline-block");
    $(".login-in-link, .login-on-link").hide();
}
// 输入搜索延时
function goSearch(keyword) {
    clearTimeout(search_timer);
    search_timer = setTimeout(function() {
        searchGame(keyword);
    }, 400);
}
// 搜索游戏
function searchGame(keyword) {
     var con = '';
    $.ajax({
        url: 'index.php?act=keyword',
        data: {
            keyword: keyword
        },
        dataType: "json",
        type: "get"
    }).success(function (res) {
        if(keyword.trim() !== "") {
            if (res == "") {
                $(".game-search-result .no-result").show().siblings().hide();
            } else {
                for (var i = 0; i < res.length; i++) {
                    con += "<a class='result-item' href='/game" + res[i].id + "'>" + res[i].game_name + "</a>";
                }
                $(".game-search-result .has-result").html(con).show().siblings().hide();
            }
        }
        else {
            $(".game-search-result .has-result, .game-search-result .no-result").hide();
            if (res == "") {
                $(".game-search-result .default-result").hide();
            } else {
                for (var i = 0; i < 6; i++) {
                    if(res[i]) {
                        con += "<a class='text-overflow default-item' href='/game" + res[i].id + "'>" + res[i].game_name + "</a>";
                    }
                }
                $(".game-search-result .default-result").html(con).show().siblings().hide();
            }
        }
    })
    
    
}