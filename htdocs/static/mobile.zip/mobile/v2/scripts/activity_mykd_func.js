/** 
    尺寸控制
**/
function popSize() {
    // 大弹窗高度
    $(".pop-bg-large").css("height", $(".pop-bg-large").width()*0.84);
    // 小弹窗高度
    $(".pop-bg-small").css("height", $(".pop-bg-small").width()*0.72);
    // document.body.clientHeight
    var minH = Math.min($(".mask").height(),window.screen.availHeight,window.screen.height);
    $(".pop-bg").css("top", (minH-$(".pop-bg:visible").height())/2 + 'px');
    // $(".pop-bg").css("top", ($(".mask").height()-$(".pop-bg:visible").height())/2 + 'px');
    $(".share-collect-zone").css("height", $(".share-collect-zone").width()*0.559);
    $(".share-collect-zone").css("top", (minH-$(".share-collect-zone").height())/2 + 'px');
    $(".my-gifts-list .center").css("height",$(".my-gifts-list .gift-img-bg").height() + 'px');
}
function initHTMLSize() {
    var wWidth = document.documentElement.clientWidth || document.body.clientWidth;
    var size = wWidth / 7.5;
    document.getElementsByTagName('html')[0].style.fontSize = (size > 55 ? 55 : size) + 'px';
}
$(document).ready(function () {
    initHTMLSize();
});
$(window).resize(function() {
    initHTMLSize();
});

/** 
    其他函数
**/
function isMobileIOS() {
    var isIOS =(/iPhone|iPod|iPad/i).test(navigator.userAgent);
    return isIOS ? true : false;
}
// 判断是否在QQ内置浏览器中打开
function isQQChatBrowser(){
  return (/QQ\/([\d\.]+)/i).test(window.navigator.userAgent);
}
// 判断是否在微信内置浏览器中打开
function isWeixinBrowser(){
  return (/MicroMessenger/i).test(window.navigator.userAgent);
}
// 判断是否可走app自带分享
function shareSelf() {
    var ua = navigator.userAgent;
    var isWX = ua.match(/MicroMessenger\/([\d\.]+)/), isQQ = ua.match(/QQ\/([\d\.]+)/), isQZ = ua.indexOf("Qzone/") !== -1;
    if(isWX || isQQ || isQZ) {
        return true;
    }
}
// 获取链接参数
function getParameterByName(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = url ? regex.exec(url) : regex.exec(location.href);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
// 设置链接参数
function setParameterByName(param, value) {
    //设置url中参数值
    function setParam(param, value) {
        var query = location.search.substring(1);
        var p = new RegExp("(^|)" + param + "=([^&]*)(|$)");
        if (p.test(query)) {
            //query = query.replace(p,"$1="+value);
            var firstParam = query.split(param)[0];
            var secondParam = query.split(param)[1];
            if (secondParam.indexOf("&") > -1) {
                var lastPraam = secondParam.split("&")[1];
                return '?' + firstParam + '&' + param + '=' + value + '&' + lastPraam;
            } else {
                if (firstParam) {
                    return '?' + firstParam + param + '=' + value;
                } else {
                    return '?' + param + '=' + value;
                }
            }
        } else {
            if (query == '') {
                return '?' + param + '=' + value;
            } else {
                return '?' + query + '&' + param + '=' + value;
            }
        }
    }
    //调用
    var url = window.location.href;//获取当前url
    var searchUrl = setParam(param, value);
    if (url.indexOf("?") > 0) {
        url = url.split("?")[0];
    }
    return (url + searchUrl);
};
// 分享链接
function shareLinksInit(share_title, share_desc, share_link, share_summary, share_img) {
        var shareTitle = encodeURIComponent(share_title);
        var shareDesc = encodeURIComponent(share_desc);
        var shareUrl = encodeURIComponent(share_link);
        var shareSummary = encodeURIComponent(share_summary);
        var qqShareLink = "http://connect.qq.com/widget/shareqq/index.html?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pics=" + share_img;
        var qqZoneShareLink = "https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pics=" + share_img;
        var sinaBlogShareLink = "http://service.weibo.com/share/share.php?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pic=" + share_img;
        return {
            qqShareLink: qqShareLink,
            qqZoneShareLink: qqZoneShareLink,
            sinaBlogShareLink: sinaBlogShareLink
        }
    }
// 分享链接渲染
function shareConInit(share_title, share_desc, share_link, share_summary, share_img) {
    var shareLinks = shareLinksInit(share_title, share_desc, share_link, share_summary, share_img);
    var shareCon = '<span class="share-link-block"><a class="share-link-item" href="' + shareLinks.sinaBlogShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block sina-share"><a class="share-link-item" href="' + shareLinks.qqZoneShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block qq-zone-share"><a class="share-link-item" href="' + shareLinks.qqShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block"><span class="share-link-item link-copy-btn" data-clipboard-text="' + window.location.href + '"></span></span>';
    $(".share-choose-zone").html(shareCon);
    var clipboardInvite = new Clipboard(".link-copy-btn"); //链接复制功能
    clipboardInvite.on('success', function(e) {
        briefTipControl("链接已复制");
        e.clearSelection();
    })
}


function sharePopControl() {
    $(".share-collect-zone").show().siblings().hide();
    $(".mask").show();
    popSize();
}
// 弹窗控制
function popControl(popParentClass, popClass, popTitle) {
    $(popParentClass).show().siblings().hide();
    $(popClass).show().siblings().hide();
    $(".pop-bg .pop-title").html(popTitle);
    $(".mask").show();
    popSize();
    // alert("mask"+$(".mask").height()+"pop-bg top"+$(".pop-bg-small").offset().top + "pop-small-height"+$(".pop-bg-small").height()+"window.screen.availHeight"+window.screen.availHeight+"screen height"+window.screen.height);
}
// 简单提示控制
function briefTipControl(text, delay) {
    $(".brief-tip-pop .con").html(text);
    $(".brief-tip-pop").fadeIn(500).delay(delay ? delay : 1000).fadeOut(500);
}
// 按钮定时加class控制
function btnTimeOutControl(ele, cls, timeoutClient, timeout) {
    clearTimeout(timeoutClient);
    timeoutClient = setTimeout(function() {
        $(ele).addClass(cls);
    }, timeout || 2000);
}
// 抽奖
// 在异步请求期间旋转转盘，持续10s，转5圈
// 如果这段时间内请求成功返回，会取消旋转，如果超时，回调会执行，提示网络超时
function fRotateDuringReq() {
    showRotateTip = true;
    $(".lottery-pointer").rotate({
        angle: 0,
        duration: 10000,
        animateTo: 1800,
        callback: function () {
            showRotateTip ? briefTipControl("网络似乎不给力哦") : null;
        }
    });
}

function fStartLottery(angle, type, data) {
    $(".lottery-pointer").rotate({
        angle: 0,
        duration: 5000,
        animateTo:1440 + angle, // 1440表示4圈,减去奖品位置角度以定位到奖品
        callback: function () {
            $(".has-prize-pop .msg-title").html(data.msgTitle || "");
            popControl(".pop-bg-small", ".has-prize-pop", "恭喜您");
        }
    });
};
// 没抽奖机会或没抽中
function lotteryQualityControl(desc) {
    $(".no-prize-pop .msg-title").html(desc);
    popControl(".pop-bg-small", ".no-prize-pop", "温馨提示");
}