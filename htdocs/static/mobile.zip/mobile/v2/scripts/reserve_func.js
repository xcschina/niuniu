// 获取链接参数
function getParameterByName(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = url ? regex.exec(url) : regex.exec(location.href);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
// 设置链接参数
function setParameterByName(param, value) {
    //设置url中参数值
    function setParam(param, value) {
        var query = location.search.substring(1);
        var p = new RegExp("(^|)" + param + "=([^&]*)(|$)");
        if (p.test(query)) {
            //query = query.replace(p,"$1="+value);
            var firstParam = query.split(param)[0];
            var secondParam = query.split(param)[1];
            if (secondParam.indexOf("&") > -1) {
                var lastPraam = secondParam.split("&")[1];
                return '?' + firstParam + '&' + param + '=' + value + '&' + lastPraam;
            } else {
                if (firstParam) {
                    return '?' + firstParam + param + '=' + value;
                } else {
                    return '?' + param + '=' + value;
                }
            }
        } else {
            if (query == '') {
                return '?' + param + '=' + value;
            } else {
                return '?' + query + '&' + param + '=' + value;
            }
        }
    }
    //调用
    var url = window.location.href;//获取当前url
    var searchUrl = setParam(param, value);
    if (url.indexOf("?") > 0) {
        url = url.split("?")[0];
    }
    return (url + searchUrl);
};
// 分享链接
function shareConInit() {
    var shareLinks = shareLinksInit();
    var link = setParameterByName("code",$("#rec_code").val()||"");
    var shareCon = '<span class="share-link-block"><a class="share-link-item" href="' + shareLinks.sinaBlogShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block sina-share"><a class="share-link-item" href="' + shareLinks.qqZoneShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block qq-zone-share"><a class="share-link-item" href="' + shareLinks.qqShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block"><span class="share-link-item link-copy-btn" data-clipboard-text="' + link + '"></span></span>';
    $(".share-choose-zone").html(shareCon);
    var clipboardInvite = new Clipboard(".link-copy-btn"); //链接复制功能
    clipboardInvite.on('success', function(e) {
        briefTipControl("链接: " + e.text + " 已复制");
        e.clearSelection();
    })
}
// 预约进度条处理
function preorderProcess(preorderNum) {
    for(var i = 0;i < pros.length-1;i++) {
        if(preorderNum >= pros[i]) {
            compIndex = i;
        }
    }
    percent = preorderNum >= pros[pros.length-1] ? 1 : (preorderNum - pros[compIndex])/(pros[compIndex+1]-pros[compIndex]);
    for(var i = compDots.length-1;i > 0;i--) {
        if(percent < compDots[i] && percent > compDots[i-1]) {
            percent = compDots[i];
        }
    }
    $(".preorder-zone").removeClass("cur-step0 cur-step1 cur-step2 cur-step3").addClass("cur-step"+compIndex);
    $(".process-bar .step"+compIndex).css("width",percent*100+'%');
    for(var i = compIndex - 1;i >= 0;i--) {
        $(".process-bar .step"+i).css("width",'100%');
    }
}

// 抽奖
// 在异步请求期间旋转转盘，持续10s，转5圈
// 如果这段时间内请求成功返回，会取消旋转，如果超时，回调会执行，提示网络超时
function fRotateDuringReq() {
    $(".lottery-pointer").rotate({
        angle: 0,
        duration: 10000,
        animateTo: 1800,
        callback: function () {
            briefTipControl('网络似乎不给力哦')
        }
    });
}
/**
 * 开始抽奖
 * @param awards 预设的抽奖结果
 * @param angle 抽奖结果图片所对应的角度
 * @param text 抽奖结果提示文案
 */
function fStartLottery(angle, type, data) {
    $('.lottery-pointer').stopRotate();  // 停止之前的旋转
    $(".lottery-pointer").rotate({
        angle: 0,
        duration: 5000,
        animateTo:1440 + angle, // 1440表示4圈,减去奖品位置角度以定位到奖品
        callback: function () {
            console.log(angle+ type+ "dd"+data);
            if(type == "no") {
                $(".no-prize-pop .msg").html("很遗憾未抽中奖品，赶紧分享赢抽奖机会吧~");
                popControl(".pop-bg-small", ".no-prize-pop", "提示")
            }
            else {
                $(".has-prize-pop .msg-title").html(data.msgTitle || "aa");
                $(".has-prize-pop .msg-con").html(data.msgCon || "aa");
                popControl(".pop-bg-small", ".has-prize-pop", "提示")
            }
        }
    });
};
function sharePopControl() {
    $(".share-collect-zone").show().siblings().hide();
    $(".preorder-activity .mask").show();
    popSize();
}
// 弹窗控制
function popControl(popParentClass, popClass, popTitle) {
    $(popParentClass).show().siblings().hide();
    $(popClass).show().siblings().hide();
    $(".pop-bg .pop-title").html(popTitle);
    $(".preorder-activity .mask").show();
    setTimeout(function() {
        popSize();
    }, 0);
}
// 简单提示控制
function briefTipControl(text) {
    $(".brief-tip-pop .con").html(text);
    $(".brief-tip-pop").fadeIn(500).delay(1000).fadeOut(500);
}
// 按钮定时加class控制
function btnTimeOutControl(ele, cls, timeoutClient, timeout) {
    clearTimeout(timeoutClient);
    timeoutClient = setTimeout(function() {
        $(ele).addClass(cls);
    }, timeout || 2000);
}
// 表单校验
function checkInput(data) {
    var checkRes = {
        res: {},
        pass: true
    }
    for(var key in data) {
        if($(key+':visible').length > 0) {
            var val = $(key + ':visible').val().trim();
            if (key == ".tel-input" && !regContact.test(val)) {
                briefTipControl("请填写正确的手机号");
                checkRes.pass = false;
                return checkRes;
            }
            if (key == ".captcha-input" && !regCaptchaPart.test(val)) {
                briefTipControl("请填写正确的验证码");
                checkRes.pass = false;
                return checkRes;
            }
            //if(key == ".invite-code-input" && val && !regInvite.test(val)) {
            //    briefTipControl("请填写正确的邀请码或不填");
            //    checkRes.pass = false;
            //    return checkRes;
            //}
            checkRes["res"][data[key]] = val;
        }
    }
    return checkRes;
}

// 没有抽奖机会
function lotteryQualityControl(desc) {
    $(".no-prize-pop .msg").html(desc);
    popControl(".pop-bg-small", ".no-prize-pop", "提示");
}