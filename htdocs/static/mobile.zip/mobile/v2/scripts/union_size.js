function popSize() {
	// 大弹窗高度
	$(".pop-bg-large").css("height", $(".pop-bg-large").width()*0.874);
	// 小弹窗高度
	$(".pop-bg-small").css("height", $(".pop-bg-small").width()*0.756);
	// document.body.clientHeight
	var minH = Math.min($(".mask").height(),window.screen.availHeight,window.screen.height);
	$(".pop-bg").css("top", (minH-$(".pop-bg:visible").height())/2 + 'px');
	// $(".pop-bg").css("top", ($(".mask").height()-$(".pop-bg:visible").height())/2 + 'px');
	// 关闭弹窗按钮高度
	var closeWidth = $(".pop-bg .close-pop:visible").width();
	$(".pop-bg .close-pop").css("height", closeWidth);
	// 弹窗标题高度和行高与关闭弹窗按钮相同
	$(".pop-bg .pop-title").css({
		"height": closeWidth,
		"line-height": closeWidth + 'px'
	});
	$(".share-collect-zone").css("height", $(".share-collect-zone").width()*0.559);
	$(".share-collect-zone").css("top", (minH-$(".share-collect-zone").height())/2 + 'px');
	$(".my-gifts-list .center").css("height",$(".my-gifts-list .gift-img-bg").height() + 'px');
}
function pageBgSize() {
	$(".sec1").css("height",$(".sec1").width()*1.44);
	$(".sec2").css("height",$(".sec2").width()*0.787);
	// 预约情况背景图高度设为宽度的一定比
	$(".preorder-zone").css("height", $(".preorder-zone").width()*0.68);
	$(".union-flag-img").css("height", $(".union-flag-img").width());
	
}
function initHTMLSize() {
	var wWidth = document.documentElement.clientWidth || document.body.clientWidth;
	var size = wWidth / 7.5;
	document.getElementsByTagName('html')[0].style.fontSize = (size > 55 ? 55 : size) + 'px';
}
$(document).ready(function () {
	initHTMLSize();
	pageBgSize();
});
$(window).resize(function() {
	// initHTMLSize();
	// resize这里要先pageBgSize()再initHTMLSize()才不至于有的动态设置高宽不执行
	pageBgSize();
	initHTMLSize();
});
