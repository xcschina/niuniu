/** 
    尺寸控制
**/
function popSize() {
    var minH = Math.min($(".mask").height(),window.screen.availHeight,window.screen.height);
    $(".share-collect-zone").css("height", $(".share-collect-zone").width()*0.559);
    $(".share-collect-zone").css("top", (minH-$(".share-collect-zone").height())/2 + 'px');
}
function pageBgSize() {
    $(".video-zone").css("height", $(".video-zone").width()*0.5625);
    $(".sec1").css("margin-top", $(".top-fix img").height());
    $(".link-download-game").css("top", "-" + 0.7 * $(".link-download-game img").height() + 'px');
    popSize();
    
}
function initHTMLSize() {
    var wWidth = document.documentElement.clientWidth || document.body.clientWidth;
    var size = wWidth / 7.5;
    document.getElementsByTagName('html')[0].style.fontSize = (size > 55 ? 55 : size) + 'px';
}
$(document).ready(function () {
    initHTMLSize();
    pageBgSize();
});
$(window).resize(function() {
    // initHTMLSize();
    // resize这里要先pageBgSize()再initHTMLSize()才不至于有的动态设置高宽不执行
    pageBgSize();
    initHTMLSize();
});

/** 
    其他函数
**/
function isMobileIOS() {
    var isIOS =(/iPhone|iPod|iPad/i).test(navigator.userAgent);
    return isIOS ? true : false;
}
// 判断是否在微信内置浏览器中打开
function isWeixinBrowser(){
  return (/MicroMessenger/i).test(window.navigator.userAgent);
}
// 判断是否可走app自带分享
function shareSelf() {
    var ua = navigator.userAgent;
    var isWX = ua.match(/MicroMessenger\/([\d\.]+)/), isQQ = ua.match(/QQ\/([\d\.]+)/), isQZ = ua.indexOf("Qzone/") !== -1;
    if(isWX || isQQ || isQZ) {
        return true;
    }
}
// 获取链接参数
function getParameterByName(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = url ? regex.exec(url) : regex.exec(location.href);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
// 设置链接参数
function setParameterByName(param, value) {
    //设置url中参数值
    function setParam(param, value) {
        var query = location.search.substring(1);
        var p = new RegExp("(^|)" + param + "=([^&]*)(|$)");
        if (p.test(query)) {
            //query = query.replace(p,"$1="+value);
            var firstParam = query.split(param)[0];
            var secondParam = query.split(param)[1];
            if (secondParam.indexOf("&") > -1) {
                var lastPraam = secondParam.split("&")[1];
                return '?' + firstParam + '&' + param + '=' + value + '&' + lastPraam;
            } else {
                if (firstParam) {
                    return '?' + firstParam + param + '=' + value;
                } else {
                    return '?' + param + '=' + value;
                }
            }
        } else {
            if (query == '') {
                return '?' + param + '=' + value;
            } else {
                return '?' + query + '&' + param + '=' + value;
            }
        }
    }
    //调用
    var url = window.location.href;//获取当前url
    var searchUrl = setParam(param, value);
    if (url.indexOf("?") > 0) {
        url = url.split("?")[0];
    }
    return (url + searchUrl);
};
// 截图滑动控制
function slideControl(cur) {
    $('.img-zone img[data-index="'+cur+'"]').addClass("active").siblings().removeClass("active");
    $('.dot-zone li[data-index="'+cur+'"]').addClass("active").siblings().removeClass("active");
}
// 分享链接
function shareLinksInit(share_title, share_desc, share_link, share_summary, share_img) {
        var shareTitle = encodeURIComponent(share_title);
        var shareDesc = encodeURIComponent(share_desc);
        var shareUrl = encodeURIComponent(share_link);
        var shareSummary = encodeURIComponent(share_summary);
        var qqShareLink = "http://connect.qq.com/widget/shareqq/index.html?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pics=" + share_img;
        var qqZoneShareLink = "https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pics=" + share_img;
        var sinaBlogShareLink = "http://service.weibo.com/share/share.php?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pic=" + share_img;
        return {
            qqShareLink: qqShareLink,
            qqZoneShareLink: qqZoneShareLink,
            sinaBlogShareLink: sinaBlogShareLink
        }
    }
// 分享链接渲染
function shareConInit(share_title, share_desc, share_link, share_summary, share_img) {
    var shareLinks = shareLinksInit(share_title, share_desc, share_link, share_summary, share_img);
    var shareCon = '<span class="share-link-block"><a class="share-link-item" href="' + shareLinks.sinaBlogShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block sina-share"><a class="share-link-item" href="' + shareLinks.qqZoneShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block qq-zone-share"><a class="share-link-item" href="' + shareLinks.qqShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block"><span class="share-link-item link-copy-btn" data-clipboard-text="' + share_link + '"></span></span>';
    $(".share-choose-zone").html(shareCon);
    var clipboardInvite = new Clipboard(".link-copy-btn"); //链接复制功能
    clipboardInvite.on('success', function(e) {
        briefTipControl("链接: " + e.text + " 已复制");
        e.clearSelection();
    })
}


function sharePopControl() {
    $(".share-collect-zone").show().siblings().hide();
    $(".mask").show();
    popSize();
}
// 弹窗控制
function popControl(popParentClass, popClass, popTitle) {
    $(popParentClass).show().siblings().hide();
    $(popClass).show().siblings().hide();
    $(".pop-bg .pop-title").html(popTitle);
    $(".mask").show();
    popSize();
    // alert("mask"+$(".mask").height()+"pop-bg top"+$(".pop-bg-small").offset().top + "pop-small-height"+$(".pop-bg-small").height()+"window.screen.availHeight"+window.screen.availHeight+"screen height"+window.screen.height);
}
// 简单提示控制
function briefTipControl(text) {
    $(".brief-tip-pop .con").html(text);
    $(".brief-tip-pop").fadeIn(500).delay(1000).fadeOut(500);
}
// 按钮定时加class控制
function btnTimeOutControl(ele, cls, timeoutClient, timeout) {
    clearTimeout(timeoutClient);
    timeoutClient = setTimeout(function() {
        $(ele).addClass(cls);
    }, timeout || 2000);
}
// 表单校验
function checkInput(data) {
    var checkRes = {
        res: {},
        pass: true
    }
    for(var key in data) {
        if($(key+':visible').length > 0) {
            var val = $(key+':visible').val().trim();
            if(key == ".tel-input" && !regContact.test(val)) {
                briefTipControl("请填写正确的手机号");
                checkRes.pass = false;
                return checkRes;
            }
            if(key == ".captcha-input" && !regCaptchaPart.test(val)) {
                briefTipControl("请填写正确的验证码");
                checkRes.pass = false;
                return checkRes;
            }
            // if(key == ".invite-code-input" && val && !regInvite.test(val)) {
            //     briefTipControl("请填写正确的邀请码或不填");
            //     checkRes.pass = false;
            //     return checkRes;
            // }
            checkRes["res"][data[key]] = val;
        }
    }
    return checkRes;
}

//loading加载
function loadingToggle(ifShow) {
    if(ifShow) {
        $(".loading-mask").show();
    } else {
        $(".loading-mask").hide();
    }

}
var commonM = {
    LOGLEVEL: {
        INFO: 0,
        WARNING: 1,
        ERROR: 2
    },
    ajax: function (a, b) {
        if(b) {
            b.abort();
        }
        var sendData = {}, c = this, ua1Str = "";
        if (!c.isPureObject(a)) {
            return false;
        }
        sendData.url = a.url;
        sendData.type = (a.type || "get");
        sendData.data = a.data;
        sendData.dataType = (a.dataType || "json");
        return $.ajax(sendData)
            .success(function (res) {
                if (typeof res == "string") {
                    res = JSON.parse(c.base64.decode(res.substr(1)));
                }
                a.success && a.success(res)
            }).error(function (res2) {
                if (res2.statusText == 'abort') {
                    return false;
                }
                if (typeof res2 == "string") {
                    res2 = JSON.parse(c.base64.decode(res2.substr(1)));
                }
                if (!a.error) {
                    briefTipControl("请求出错：" + res2.status + "," + res2.statusText)
                } else {
                    a.error(res2);
                }
            });
    },
    base64: {
        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
        decode: function (a) {
            var b, c, d, e, f, g, h, i = this,
                j = "",
                k = 0;
            for (a = a.replace(/[^A-Za-z0-9\+\/\=]/g, ""); k < a.length;) e = i._keyStr.indexOf(a.charAt(k++)), f = i._keyStr.indexOf(a.charAt(k++)), g = i._keyStr.indexOf(a.charAt(k++)), h = i._keyStr.indexOf(a.charAt(k++)), b = e << 2 | f >> 4, c = (15 & f) << 4 | g >> 2, d = (3 & g) << 6 | h, j += String.fromCharCode(b), 64 != g && (j += String.fromCharCode(c)), 64 != h && (j += String.fromCharCode(d));
            return j = i._utf8_decode(j)
        },
        // private method for UTF-8 encoding
        _utf8_decode: function (a) {
            for (var b = "", c = 0, d = c1 = c2 = 0; c < a.length;) d = a.charCodeAt(c), 128 > d ? (b += String.fromCharCode(d), c++) : d > 191 && 224 > d ? (c2 = a.charCodeAt(c + 1), b += String.fromCharCode((31 & d) << 6 | 63 & c2), c += 2) : (c2 = a.charCodeAt(c + 1), c3 = a.charCodeAt(c + 2), b += String.fromCharCode((15 & d) << 12 | (63 & c2) << 6 | 63 & c3), c += 3);
            return b
        },
        encode: function (input) {
            var c = this, output = "", chr1, chr2, chr3, enc1, enc2, enc3, enc4, i = 0, input = c._utf8_encode(input);
            while (i < input.length) {
                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);
                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;
                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }
                output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
            }

            return output;
        },
        // private method for UTF-8 encoding
        _utf8_encode: function (string) {
            string = string.replace(/\r\n/g, "\n"), utftext = "";
            for (var n = 0; n < string.length; n++) {
                var c = string.charCodeAt(n);
                if (c < 128) {
                    utftext += String.fromCharCode(c);
                }
                else if ((c > 127) && (c < 2048)) {
                    utftext += String.fromCharCode((c >> 6) | 192);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
                else {
                    utftext += String.fromCharCode((c >> 12) | 224);
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
            }
            return utftext;
        }

    },
    isPureObject: function(a) {
        return a && typeof a == "object" ? true : false;
    }
};