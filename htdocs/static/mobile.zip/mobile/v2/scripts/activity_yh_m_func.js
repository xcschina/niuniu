/** 
    尺寸控制
**/
function popSize() {
    // 大弹窗高度
    $(".pop-bg-large").css("height", $(".pop-bg-large").width()*0.926);
    // 小弹窗高度
    $(".pop-bg-small").css("height", $(".pop-bg-small").width()*0.756);
    // document.body.clientHeight
    var minH = Math.min($(".mask").height(),window.screen.availHeight,window.screen.height);
    $(".pop-bg").css("top", (minH-$(".pop-bg:visible").height())/2 + 'px');
    // $(".pop-bg").css("top", ($(".mask").height()-$(".pop-bg:visible").height())/2 + 'px');
    // 关闭弹窗按钮高度
    var closeWidth = $(".pop-bg .close-pop:visible").width();
    $(".pop-bg .close-pop").css("height", closeWidth);
}
function pageBgSize() {
    popSize();
    
}
function initHTMLSize() {
    var wWidth = document.documentElement.clientWidth || document.body.clientWidth;
    var size = wWidth / 7.5;
    document.getElementsByTagName('html')[0].style.fontSize = (size > 55 ? 55 : size) + 'px';
}
$(document).ready(function () {
    initHTMLSize();
    pageBgSize();
});
$(window).resize(function() {
    // initHTMLSize();
    // resize这里要先pageBgSize()再initHTMLSize()才不至于有的动态设置高宽不执行
    pageBgSize();
    initHTMLSize();
});

/** 
    其他函数
**/
function isMobileIOS() {
    var isIOS =(/iPhone|iPod|iPad/i).test(navigator.userAgent);
    return isIOS ? true : false;
}
// 判断是否在微信内置浏览器中打开
function isWeixinBrowser(){
  return (/MicroMessenger/i).test(window.navigator.userAgent);
}
// 判断是否可走app自带分享
function shareSelf() {
    var ua = navigator.userAgent;
    var isWX = ua.match(/MicroMessenger\/([\d\.]+)/), isQQ = ua.match(/QQ\/([\d\.]+)/), isQZ = ua.indexOf("Qzone/") !== -1;
    if(isWX || isQQ || isQZ) {
        return true;
    }
}
// 获取链接参数
function getParameterByName(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = url ? regex.exec(url) : regex.exec(location.href);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
// 设置链接参数
function setParameterByName(param, value) {
    //设置url中参数值
    function setParam(param, value) {
        var query = location.search.substring(1);
        var p = new RegExp("(^|)" + param + "=([^&]*)(|$)");
        if (p.test(query)) {
            //query = query.replace(p,"$1="+value);
            var firstParam = query.split(param)[0];
            var secondParam = query.split(param)[1];
            if (secondParam.indexOf("&") > -1) {
                var lastPraam = secondParam.split("&")[1];
                return '?' + firstParam + '&' + param + '=' + value + '&' + lastPraam;
            } else {
                if (firstParam) {
                    return '?' + firstParam + param + '=' + value;
                } else {
                    return '?' + param + '=' + value;
                }
            }
        } else {
            if (query == '') {
                return '?' + param + '=' + value;
            } else {
                return '?' + query + '&' + param + '=' + value;
            }
        }
    }
    //调用
    var url = window.location.href;//获取当前url
    var searchUrl = setParam(param, value);
    if (url.indexOf("?") > 0) {
        url = url.split("?")[0];
    }
    return (url + searchUrl);
};
// 截图滑动控制
function slideControl(cur) {
    $('.img-zone img[data-index="'+cur+'"]').addClass("active").siblings().removeClass("active");
    $('.dot-zone li[data-index="'+cur+'"]').addClass("active").siblings().removeClass("active");
}

// 弹窗控制
function popControl(popParentClass, popClass, popTitle) {
    $(popParentClass).show().siblings().hide();
    $(popClass).show().siblings().hide();
    $(".mask").show();
    popSize();
    // alert("mask"+$(".mask").height()+"pop-bg top"+$(".pop-bg-small").offset().top + "pop-small-height"+$(".pop-bg-small").height()+"window.screen.availHeight"+window.screen.availHeight+"screen height"+window.screen.height);
}
// 简单提示控制
function briefTipControl(text) {
    $(".brief-tip-pop .con").html(text);
    $(".brief-tip-pop").fadeIn(500).delay(1000).fadeOut(500);
}
// 按钮定时加class控制
function btnTimeOutControl(ele, cls, timeoutClient, timeout) {
    clearTimeout(timeoutClient);
    timeoutClient = setTimeout(function() {
        $(ele).addClass(cls);
    }, timeout || 2000);
}
// 表单校验
function checkInput(data) {
    var checkRes = {
        res: {},
        pass: true
    }
    for(var key in data) {
        if($(key+':visible').length > 0) {
            var val = $(key+':visible').val().trim();
            if(key == ".tel-input" && !regContact.test(val)) {
                briefTipControl("请填写正确的手机号");
                checkRes.pass = false;
                return checkRes;
            }
            if(key == ".captcha-input" && !regCaptchaPart.test(val)) {
                briefTipControl("请填写正确的验证码");
                checkRes.pass = false;
                return checkRes;
            }
            // if(key == ".invite-code-input" && val && !regInvite.test(val)) {
            //     briefTipControl("请填写正确的邀请码或不填");
            //     checkRes.pass = false;
            //     return checkRes;
            // }
            checkRes["res"][data[key]] = val;
        }
    }
    return checkRes;
}
//loading加载
function loadingToggle(ifShow) {
    if(ifShow) {
        $(".loading-mask").show();
    } else {
        $(".loading-mask").hide();
    }

}
//设备/浏览器相关
function browserRel(userAgent){
    var u = userAgent||navigator.userAgent;
    var _this = {};
    var match = {
        // //内核
        Trident: u.indexOf('Trident')>0||u.indexOf('NET CLR')>0,
        Presto: u.indexOf('Presto')>0,
        WebKit: u.indexOf('AppleWebKit')>0,
        Gecko: u.indexOf('Gecko/')>0,
        //浏览器
        UC: u.indexOf('UC')>0||u.indexOf(' UCBrowser')>0,
        QQ: u.indexOf('QQBrowser')>0,
        QQin: u.indexOf(' QQ')>0 || u.indexOf('MQQBrowser QQ')>0 || u.indexOf('MQQBrowserQQ')>0,
        BaiDu: u.indexOf('Baidu')>0||u.indexOf('BIDUBrowser')>0,
        Maxthon: u.indexOf('Maxthon')>0,
        LBBROWSER: u.indexOf('LBBROWSER')>0,
        SouGou: u.indexOf('MetaSr')>0||u.indexOf('Sogou')>0,
        IE: u.indexOf('MSIE')>0||u.indexOf('Trident')>0,
        Firefox: u.indexOf('Firefox')>0||u.indexOf('FxiOS')>0,
        Opera: u.indexOf('Opera')>0||u.indexOf('OPR')>0,
        Safari: u.indexOf('Safari')>0,
        Chrome:u.indexOf('Chrome')>0||u.indexOf('CriOS')>0,
        Wechat:u.indexOf('MicroMessenger')>0,
        // 系统或平台
        Windows:u.indexOf('Windows')>0,
        Linux:u.indexOf('Linux')>0,
        Mac:u.indexOf('Macintosh')>0,
        Android:u.indexOf('Android')>0||u.indexOf('Adr')>0,
        WP:u.indexOf('IEMobile')>0,
        BlackBerry:u.indexOf('BlackBerry')>0||u.indexOf('RIM')>0||u.indexOf('BB')>0,
        MeeGo:u.indexOf('MeeGo')>0,
        Symbian:u.indexOf('Symbian')>0,
        iOS:u.indexOf('like Mac OS X')>0,
        iPhone: u.indexOf('iPh')>0,
        iPad:u.indexOf('iPad')>0,
        iPod:u.indexOf('iPod')>0,
        //设备
        Mobile:u.indexOf('Mobi')>0||u.indexOf('iPh')>0||u.indexOf('480')>0,
        Tablet:u.indexOf('Tablet')>0||u.indexOf('iPad')>0||u.indexOf('Nexus 7')>0
    };
    //修正
    if(match.Chrome){
        match.Chrome = !(match.Opera + match.BaiDu + match.Maxthon + match.SouGou + match.UC + match.QQ + match.LBBROWSER);
    }
    if(match.Safari){
        match.Safari = !(match.Chrome + match.Opera + match.BaiDu + match.Maxthon + match.SouGou + match.UC + match.QQ + match.LBBROWSER + match.Firefox);
    }
    if(match.Mobile){
        match.Mobile = !match.iPad;
    }
    //基本信息
    var hash = {
        engine:['WebKit','Trident','Gecko','Presto'],
        // Firefox要放在Safari之后，QQin要放在QQ后，因为前者在某方面会同时也满足后者特性
        browser:['Chrome','Safari','IE','Firefox','Opera','UC','QQ', 'QQin', 'BaiDu','Maxthon','SouGou','LBBROWSER','Wechat'],
        os:['Windows','Linux','Mac','Android','iOS','WP','BlackBerry','MeeGo','Symbian'],
        device:['Mobile','Tablet']
    };
    _this.device = 'PC';
    _this.language = (function(){
        var g = (navigator.browserLanguage || navigator.language).toLowerCase();
        return g=="c"?"zh-cn":g;
    })();
    for(var s in hash){
        for(var i=0;i< hash[s].length;i++){
            var value = hash[s][i];
            if(match[value]){
                _this[s] = value;
            }
        }
    }
    //版本信息
    var browserVersion = {
        'Chrome':function(){
            return u.replace(/^.*(Chrome|CriOS)\/([\d.]+).*$/,'$2');
        },
        'IE':function(){
            var v = u.replace(/^.*MSIE ([\d.]+).*$/,'$1');
            if(v==u){
                v = u.replace(/^.*rv:([\d.]+).*$/,'$1');
            }
            return v!=u?v:'';
        },
        'Firefox':function(){
            return u.replace(/^.*(Firefox|FxiOS)\/([\d.]+).*$/,'$2');
        },
        'Safari':function(){
            return u.replace(/^.*Version\/([\d.]+).*$/,'$1');
        },
        'Maxthon':function(){
            return u.replace(/^.*Maxthon\/([\d.]+).*$/,'$1');
        },
        'SouGou':function(){
            return u.replace(/^.*SogouMobileBrowser\/([\d.]+).*$/,'$1');
        },
        'QQ':function(){
            return u.replace(/^.*(QQBrowser|QQ)\/([\d.]+).*$/,'$2');
        },
        'QQin':function(){
            return u.replace(/^.*QQ\/([\d.]+).*$/,'$1');
        },
        'BaiDu':function(){
            return u.replace(/^.*(BIDUBrowser|baiduboxapp)[\s\/]([\d.]+).*$/,'$2');
        },
        'UC':function(){
            return u.replace(/^.*UCBrowser\/([\d.]+).*$/,'$1');
        },
        'Wechat':function(){
            return u.replace(/^.*MicroMessenger\/([\d.]+).*$/,'$1');
        }
    };
    _this.browserVersion = '';
    if(browserVersion[_this.browser]){
        _this.browserVersion = browserVersion[_this.browser]();
    }

    var osVersion = "";
    switch (_this.os) {
        case 'Mac':
            if(/Mac OS X ([\.\_\d]+)/.exec(u)) {
                osVersion = /Mac OS X ([\.\_\d]+)/.exec(u)[1];
            }
            break;

        case 'Android':
            if(/Android ([\.\_\d]+)/.exec(u)) {
                osVersion = /Android ([\.\_\d]+)/.exec(u)[1];
            }
            break;

        case 'iOS':
            if(/OS ([\.\_\d]+) like Mac OS X?/.exec(u)) {
                osVersion = /OS ([\.\_\d]+) like Mac OS X?/.exec(u)[1];
            }
            break;

    }
    _this.osVersion = osVersion.replace(/_/g,".");

    var deviceType = _this.os;
    switch (_this.os) {
        case 'Android':
            if(/;\s*([^;]+[^\s;])\s*;?\s*Build/.exec(u)) {
                deviceType = /;\s*([^;]+[^\s;])\s*;?\s*Build/.exec(u)[1];
            }
            break;
        case 'iOS':
            var a = ["iPhone", "iPad", "iPod"];
            for(i = 0; i < a.length; i++) {
                match[a[i]] && (deviceType = a[i]);
            }
            break;

    }
    _this.deviceType = deviceType;
    return _this;
}
//蒙层位置判断
function maskPos() {
    var a = browserRel && browserRel() || {}, pos = "";
    var browser = a.browser;
    var topRightArr = ['Chrome','Firefox','QQin', 'BaiDu','Wechat'],
        bottomRightArr = ['SouGou'],
        bottomCenterArr = ['Safari', 'UC','QQ'];
    if(topRightArr.indexOf(browser) > -1) {
        pos = "topRight";
    } else if(bottomRightArr.indexOf(browser) > -1) {
        pos = "bottomRight";
    } else if(bottomCenterArr.indexOf(browser) > -1){
        pos = "bottomCenter"
    }
    return {browser: browser, pos: pos};
}