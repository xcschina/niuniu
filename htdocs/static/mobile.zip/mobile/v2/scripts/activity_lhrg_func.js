/** 
    尺寸控制
**/
function popSize() {
    var minH = Math.min($(".mask").height(),window.screen.availHeight,window.screen.height);
    $(".share-collect-zone").css("height", $(".share-collect-zone").width()*0.559);
    $(".share-collect-zone").css("top", (minH-$(".share-collect-zone").height())/2 + 'px');
}
function pageBgSize() {
    var topFixHeight = $(".top-fix img").height();
    $(".video-zone").css("height", $(".video-zone").width()*0.5625);
    $(".sec1").css("margin-top", topFixHeight -1 );
    $(".top-fix-btn").css("top", (topFixHeight - $(".top-fix-btn").height())/2).show();
    $(".link-download-game").css("top", "-" + 0.7 * $(".link-download-game img").height() + 'px');
    popSize();
    
}
function initHTMLSize() {
    var wWidth = document.documentElement.clientWidth || document.body.clientWidth;
    var size = wWidth / 7.5;
    document.getElementsByTagName('html')[0].style.fontSize = (size > 55 ? 55 : size) + 'px';
}
$(document).ready(function () {
    initHTMLSize();
    pageBgSize();
});
$(window).resize(function() {
    // initHTMLSize();
    // resize这里要先pageBgSize()再initHTMLSize()才不至于有的动态设置高宽不执行
    pageBgSize();
    initHTMLSize();
});

/** 
    其他函数
**/
function isMobileIOS() {
    var isIOS =(/iPhone|iPod|iPad/i).test(navigator.userAgent);
    return isIOS ? true : false;
}
// 判断是否在微信内置浏览器中打开
function isWeixinBrowser(){
  return (/MicroMessenger/i).test(window.navigator.userAgent);
}
// 判断是否可走app自带分享
function shareSelf() {
    var ua = navigator.userAgent;
    var isWX = ua.match(/MicroMessenger\/([\d\.]+)/), isQQ = ua.match(/QQ\/([\d\.]+)/), isQZ = ua.indexOf("Qzone/") !== -1;
    if(isWX || isQQ || isQZ) {
        return true;
    }
}
// 获取链接参数
function getParameterByName(name, url) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
    var results = url ? regex.exec(url) : regex.exec(location.href);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}
// 设置链接参数
function setParameterByName(param, value) {
    //设置url中参数值
    function setParam(param, value) {
        var query = location.search.substring(1);
        var p = new RegExp("(^|)" + param + "=([^&]*)(|$)");
        if (p.test(query)) {
            //query = query.replace(p,"$1="+value);
            var firstParam = query.split(param)[0];
            var secondParam = query.split(param)[1];
            if (secondParam.indexOf("&") > -1) {
                var lastPraam = secondParam.split("&")[1];
                return '?' + firstParam + '&' + param + '=' + value + '&' + lastPraam;
            } else {
                if (firstParam) {
                    return '?' + firstParam + param + '=' + value;
                } else {
                    return '?' + param + '=' + value;
                }
            }
        } else {
            if (query == '') {
                return '?' + param + '=' + value;
            } else {
                return '?' + query + '&' + param + '=' + value;
            }
        }
    }
    //调用
    var url = window.location.href;//获取当前url
    var searchUrl = setParam(param, value);
    if (url.indexOf("?") > 0) {
        url = url.split("?")[0];
    }
    return (url + searchUrl);
};
// 截图滑动控制
function slideControl(cur) {
    $('.img-zone img[data-index="'+cur+'"]').addClass("active").siblings().removeClass("active");
    $('.dot-zone li[data-index="'+cur+'"]').addClass("active").siblings().removeClass("active");
}
// 分享链接
function shareLinksInit(share_title, share_desc, share_link, share_summary, share_img) {
        var shareTitle = encodeURIComponent(share_title);
        var shareDesc = encodeURIComponent(share_desc);
        var shareUrl = encodeURIComponent(share_link);
        var shareSummary = encodeURIComponent(share_summary);
        var qqShareLink = "http://connect.qq.com/widget/shareqq/index.html?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pics=" + share_img;
        var qqZoneShareLink = "https://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pics=" + share_img;
        var sinaBlogShareLink = "http://service.weibo.com/share/share.php?url=" + shareUrl + "&title=" + shareTitle + "&desc=" + shareDesc + "&summary=" + shareSummary + "&pic=" + share_img;
        return {
            qqShareLink: qqShareLink,
            qqZoneShareLink: qqZoneShareLink,
            sinaBlogShareLink: sinaBlogShareLink
        }
    }
// 分享链接渲染
function shareConInit(share_title, share_desc, share_link, share_summary, share_img) {
    var shareLinks = shareLinksInit(share_title, share_desc, share_link, share_summary, share_img);
    var shareCon = '<span class="share-link-block"><a class="share-link-item" href="' + shareLinks.sinaBlogShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block sina-share"><a class="share-link-item" href="' + shareLinks.qqZoneShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block qq-zone-share"><a class="share-link-item" href="' + shareLinks.qqShareLink + '" target="_blank"></a></span>'
        + '<span class="share-link-block"><span class="share-link-item link-copy-btn" data-clipboard-text="' + share_link + '"></span></span>';
    $(".share-choose-zone").html(shareCon);
    var clipboardInvite = new Clipboard(".link-copy-btn"); //链接复制功能
    clipboardInvite.on('success', function(e) {
        briefTipControl("链接: " + e.text + " 已复制");
        e.clearSelection();
    })
}


function sharePopControl() {
    $(".share-collect-zone").show().siblings().hide();
    $(".mask").show();
    popSize();
}
// 弹窗控制
function popControl(popParentClass, popClass, popTitle) {
    $(popParentClass).show().siblings().hide();
    $(popClass).show().siblings().hide();
    $(".pop-bg .pop-title").html(popTitle);
    $(".mask").show();
    popSize();
    // alert("mask"+$(".mask").height()+"pop-bg top"+$(".pop-bg-small").offset().top + "pop-small-height"+$(".pop-bg-small").height()+"window.screen.availHeight"+window.screen.availHeight+"screen height"+window.screen.height);
}
// 简单提示控制
function briefTipControl(text) {
    $(".brief-tip-pop .con").html(text);
    $(".brief-tip-pop").fadeIn(500).delay(1000).fadeOut(500);
}
// 按钮定时加class控制
function btnTimeOutControl(ele, cls, timeoutClient, timeout) {
    clearTimeout(timeoutClient);
    timeoutClient = setTimeout(function() {
        $(ele).addClass(cls);
    }, timeout || 2000);
}
// 表单校验
function checkInput(data) {
    var checkRes = {
        res: {},
        pass: true
    }
    for(var key in data) {
        if($(key+':visible').length > 0) {
            var val = $(key+':visible').val().trim();
            if(key == ".tel-input" && !regContact.test(val)) {
                briefTipControl("请填写正确的手机号");
                checkRes.pass = false;
                return checkRes;
            }
            if(key == ".captcha-input" && !regCaptchaPart.test(val)) {
                briefTipControl("请填写正确的验证码");
                checkRes.pass = false;
                return checkRes;
            }
            // if(key == ".invite-code-input" && val && !regInvite.test(val)) {
            //     briefTipControl("请填写正确的邀请码或不填");
            //     checkRes.pass = false;
            //     return checkRes;
            // }
            checkRes["res"][data[key]] = val;
        }
    }
    return checkRes;
}

//loading加载
function loadingToggle(ifShow) {
    if(ifShow) {
        $(".loading-mask").show();
    } else {
        $(".loading-mask").hide();
    }

}
var commonM = {
    LOGLEVEL: {
        INFO: 0,
        WARNING: 1,
        ERROR: 2
    },
    ajax: function (a, b) {
        if(b) {
            b.abort();
        }
        var sendData = {}, c = this, ua1Str = "";
        if (!c.isPureObject(a)) {
            return false;
        }
        sendData.url = a.url;
        sendData.type = (a.type || "get");
        sendData.data = a.data;
        sendData.dataType = (a.dataType || "json");
        return $.ajax(sendData)
            .success(function (res) {
                if (typeof res == "string") {
                    res = JSON.parse(c.base64.decode(res.substr(1)));
                }
                a.success && a.success(res)
            }).error(function (res2) {
                if (res2.statusText == 'abort') {
                    return false;
                }
                if (typeof res2 == "string") {
                    res2 = JSON.parse(c.base64.decode(res2.substr(1)));
                }
                if (!a.error) {
                    briefTipControl("请求出错：" + res2.status + "," + res2.statusText)
                } else {
                    a.error(res2);
                }
            });
    },
    base64: {
        _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
        decode: function (a) {
            var b, c, d, e, f, g, h, i = this,
                j = "",
                k = 0;
            for (a = a.replace(/[^A-Za-z0-9\+\/\=]/g, ""); k < a.length;) e = i._keyStr.indexOf(a.charAt(k++)), f = i._keyStr.indexOf(a.charAt(k++)), g = i._keyStr.indexOf(a.charAt(k++)), h = i._keyStr.indexOf(a.charAt(k++)), b = e << 2 | f >> 4, c = (15 & f) << 4 | g >> 2, d = (3 & g) << 6 | h, j += String.fromCharCode(b), 64 != g && (j += String.fromCharCode(c)), 64 != h && (j += String.fromCharCode(d));
            return j = i._utf8_decode(j)
        },
        // private method for UTF-8 encoding
        _utf8_decode: function (a) {
            for (var b = "", c = 0, d = c1 = c2 = 0; c < a.length;) d = a.charCodeAt(c), 128 > d ? (b += String.fromCharCode(d), c++) : d > 191 && 224 > d ? (c2 = a.charCodeAt(c + 1), b += String.fromCharCode((31 & d) << 6 | 63 & c2), c += 2) : (c2 = a.charCodeAt(c + 1), c3 = a.charCodeAt(c + 2), b += String.fromCharCode((15 & d) << 12 | (63 & c2) << 6 | 63 & c3), c += 3);
            return b
        },
        encode: function (input) {
            var c = this, output = "", chr1, chr2, chr3, enc1, enc2, enc3, enc4, i = 0, input = c._utf8_encode(input);
            while (i < input.length) {
                chr1 = input.charCodeAt(i++);
                chr2 = input.charCodeAt(i++);
                chr3 = input.charCodeAt(i++);
                enc1 = chr1 >> 2;
                enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
                enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
                enc4 = chr3 & 63;
                if (isNaN(chr2)) {
                    enc3 = enc4 = 64;
                } else if (isNaN(chr3)) {
                    enc4 = 64;
                }
                output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
            }

            return output;
        },
        // private method for UTF-8 encoding
        _utf8_encode: function (string) {
            string = string.replace(/\r\n/g, "\n"), utftext = "";
            for (var n = 0; n < string.length; n++) {
                var c = string.charCodeAt(n);
                if (c < 128) {
                    utftext += String.fromCharCode(c);
                }
                else if ((c > 127) && (c < 2048)) {
                    utftext += String.fromCharCode((c >> 6) | 192);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
                else {
                    utftext += String.fromCharCode((c >> 12) | 224);
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
            }
            return utftext;
        }

    },
    isPureObject: function(a) {
        return a && typeof a == "object" ? true : false;
    },
    browserRel: function(userAgent){
        var u = userAgent||navigator.userAgent;
        var _this = {};
        var match = {
            // //内核
            Trident: u.indexOf('Trident')>0||u.indexOf('NET CLR')>0,
            Presto: u.indexOf('Presto')>0,
            WebKit: u.indexOf('AppleWebKit')>0,
            Gecko: u.indexOf('Gecko/')>0,
            //浏览器
            UC: u.indexOf('UC')>0||u.indexOf(' UCBrowser')>0,
            QQ: u.indexOf('QQBrowser')>0,
            QQin: u.indexOf(' QQ')>0 || u.indexOf('MQQBrowser QQ')>0 || u.indexOf('MQQBrowserQQ')>0,
            BaiDu: u.indexOf('Baidu')>0||u.indexOf('BIDUBrowser')>0,
            Maxthon: u.indexOf('Maxthon')>0,
            LBBROWSER: u.indexOf('LBBROWSER')>0,
            SouGou: u.indexOf('MetaSr')>0||u.indexOf('Sogou')>0,
            IE: u.indexOf('MSIE')>0||u.indexOf('Trident')>0,
            Firefox: u.indexOf('Firefox')>0||u.indexOf('FxiOS')>0,
            Opera: u.indexOf('Opera')>0||u.indexOf('OPR')>0,
            Safari: u.indexOf('Safari')>0,
            Chrome:u.indexOf('Chrome')>0||u.indexOf('CriOS')>0,
            Wechat:u.indexOf('MicroMessenger')>0,
            // 系统或平台
            Windows:u.indexOf('Windows')>0,
            Linux:u.indexOf('Linux')>0,
            Mac:u.indexOf('Macintosh')>0,
            Android:u.indexOf('Android')>0||u.indexOf('Adr')>0,
            WP:u.indexOf('IEMobile')>0,
            BlackBerry:u.indexOf('BlackBerry')>0||u.indexOf('RIM')>0||u.indexOf('BB')>0,
            MeeGo:u.indexOf('MeeGo')>0,
            Symbian:u.indexOf('Symbian')>0,
            iOS:u.indexOf('like Mac OS X')>0,
            iPhone: u.indexOf('iPh')>0,
            iPad:u.indexOf('iPad')>0,
            iPod:u.indexOf('iPod')>0,
            //设备
            Mobile:u.indexOf('Mobi')>0||u.indexOf('iPh')>0||u.indexOf('480')>0,
            Tablet:u.indexOf('Tablet')>0||u.indexOf('iPad')>0||u.indexOf('Nexus 7')>0
        };
        //修正
        if(match.Chrome){
            match.Chrome = !(match.Opera + match.BaiDu + match.Maxthon + match.SouGou + match.UC + match.QQ + match.LBBROWSER);
        }
        if(match.Safari){
            match.Safari = !(match.Chrome + match.Opera + match.BaiDu + match.Maxthon + match.SouGou + match.UC + match.QQ + match.LBBROWSER + match.Firefox);
        }
        if(match.Mobile){
            match.Mobile = !match.iPad;
        }
        //基本信息
        var hash = {
            engine:['WebKit','Trident','Gecko','Presto'],
            // Firefox要放在Safari之后，QQin要放在QQ后，因为前者在某方面会同时也满足后者特性
            browser:['Chrome','Safari','IE','Firefox','Opera','UC','QQ', 'QQin', 'BaiDu','Maxthon','SouGou','LBBROWSER','Wechat'],
            os:['Windows','Linux','Mac','Android','iOS','WP','BlackBerry','MeeGo','Symbian'],
            device:['Mobile','Tablet']
        };
        _this.device = 'PC';
        _this.language = (function(){
            var g = (navigator.browserLanguage || navigator.language).toLowerCase();
            return g=="c"?"zh-cn":g;
        })();
        for(var s in hash){
            for(var i=0;i< hash[s].length;i++){
                var value = hash[s][i];
                if(match[value]){
                    _this[s] = value;
                }
            }
        }
        //版本信息
        var browserVersion = {
            'Chrome':function(){
                return u.replace(/^.*(Chrome|CriOS)\/([\d.]+).*$/,'$2');
            },
            'IE':function(){
                var v = u.replace(/^.*MSIE ([\d.]+).*$/,'$1');
                if(v==u){
                    v = u.replace(/^.*rv:([\d.]+).*$/,'$1');
                }
                return v!=u?v:'';
            },
            'Firefox':function(){
                return u.replace(/^.*(Firefox|FxiOS)\/([\d.]+).*$/,'$2');
            },
            'Safari':function(){
                return u.replace(/^.*Version\/([\d.]+).*$/,'$1');
            },
            'Maxthon':function(){
                return u.replace(/^.*Maxthon\/([\d.]+).*$/,'$1');
            },
            'SouGou':function(){
                return u.replace(/^.*SogouMobileBrowser\/([\d.]+).*$/,'$1');
            },
            'QQ':function(){
                return u.replace(/^.*(QQBrowser|QQ)\/([\d.]+).*$/,'$2');
            },
            'QQin':function(){
                return u.replace(/^.*QQ\/([\d.]+).*$/,'$1');
            },
            'BaiDu':function(){
                return u.replace(/^.*(BIDUBrowser|baiduboxapp)[\s\/]([\d.]+).*$/,'$2');
            },
            'UC':function(){
                return u.replace(/^.*UCBrowser\/([\d.]+).*$/,'$1');
            },
            'Wechat':function(){
                return u.replace(/^.*MicroMessenger\/([\d.]+).*$/,'$1');
            }
        };
        _this.browserVersion = '';
        if(browserVersion[_this.browser]){
            _this.browserVersion = browserVersion[_this.browser]();
        }

        var osVersion = "";
        switch (_this.os) {
            case 'Mac':
                if(/Mac OS X ([\.\_\d]+)/.exec(u)) {
                    osVersion = /Mac OS X ([\.\_\d]+)/.exec(u)[1];
                }
                break;

            case 'Android':
                if(/Android ([\.\_\d]+)/.exec(u)) {
                    osVersion = /Android ([\.\_\d]+)/.exec(u)[1];
                }
                break;

            case 'iOS':
                if(/OS ([\.\_\d]+) like Mac OS X?/.exec(u)) {
                    osVersion = /OS ([\.\_\d]+) like Mac OS X?/.exec(u)[1];
                }
                break;

        }
        _this.osVersion = osVersion.replace(/_/g,".");

        var deviceType = _this.os;
        switch (_this.os) {
            case 'Android':
                if(/;\s*([^;]+[^\s;])\s*;?\s*Build/.exec(u)) {
                    deviceType = /;\s*([^;]+[^\s;])\s*;?\s*Build/.exec(u)[1];
                }
                break;
            case 'iOS':
                var a = ["iPhone", "iPad", "iPod"];
                for(i = 0; i < a.length; i++) {
                    match[a[i]] && (deviceType = a[i]);
                }
                break;

        }
        _this.deviceType = deviceType;
        return _this;
    },
//蒙层位置判断
    maskPos: function() {
        var c = this;
        var a = c.browserRel && c.browserRel() || {}, pos = "";
        var browser = a.browser;
        var topRightArr = ['Chrome','Firefox','QQin', 'BaiDu','Wechat'],
            bottomRightArr = ['SouGou'],
            bottomCenterArr = ['Safari', 'UC','QQ'];
        if(topRightArr.indexOf(browser) > -1) {
            pos = "topRight";
        } else if(bottomRightArr.indexOf(browser) > -1) {
            pos = "bottomRight";
        } else if(bottomCenterArr.indexOf(browser) > -1){
            pos = "bottomCenter"
        }
        return {browser: browser, pos: pos};
    }
};