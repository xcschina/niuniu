/**
 * h5 SDK 
 * by tinymay
 * 2017.11.15
 * 
 */
var pubkey = "-----BEGIN PUBLIC KEY-----"
		+ "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4h7DNhpOBaHDrK51CEizEFGQ6"
		+ "sWhRFPdAj/k1BAvYPMpkqKRak1unHE3QOKDq5Fo4CJs7gbPNU+m13tudfU7oXs9l"
		+ "L26ZgDDvIJP9ogZdg4uH0Z3o40QUtkE8eQ1PfA1I2zwxWWq/nqNmZZk4rfT8W+cx"
		+ "jqyt8YdkOv/ARXRuCwIDAQAB"
		+ "-----END PUBLIC KEY-----";
var encrypt = new JSEncrypt();
encrypt.setPublicKey(pubkey);
window.encrypt = encrypt;
var commonC = {
	"roleKeyMap": [{name: "roleId"},{name: "roleName"},{name: "roleLevel"},{name: "serverName"},{name: "serverId"}],
	"payKeyMap": [{name: "way"},{name: "roleId"},{name: "roleName"},{name: "roleLevel"},{
						name: "serverName"},{name: "serverId"},{name: "userId"},{name: "appId"
					},{name: "sdkgoodsid"},{name: "billno"},{name: "amount"},{name: "count"},{
						name: "subject",canIgnore: true},{name: "extraInfo"}],
	regContact: new RegExp(/^1[345789]\d{9}$/),
	regCaptchaPart: new RegExp(/^[0-9]{6}$/),
	regPassword: new RegExp(/^[0-9a-zA-Z]{6,12}$/),
	uaObj: {},
	infoObj: {}
};
var commonM = {
	LOGLEVEL: {
		INFO: 0,
		WARNING: 1,
		ERROR: 2
	},
	ajax: function(a) {
		var sendData = {}, c = this, ua1Str = "";
		if(!c.isPureObject(a)) {
			return false;
		}
		sendData.url = a.url;
		sendData.type = (a.type || "get");
		sendData.data = a.data;
		sendData.dataType = (a.dataType || "json");
		for(i in commonC.uaObj) {
		    ua1Str = ua1Str + (i + "=" + commonC.uaObj[i] + "&");
        }
        c.log("ua1Str:",ua1Str);
		sendData.headers = {"User-Agent1": "0" + commonM.base64.encode(ua1Str.substr(0, ua1Str.length -1))};
		$.ajax(sendData)
			.success(function(res) {
				commonS.loadingToggle(false);
				if(typeof res == "string") {
					res = JSON.parse(c.base64.decode(res.substr(1)));
				}
				a.success && a.success(res)
			}).error(function(res2) {
				commonS.loadingToggle(false);
				if(typeof res2 == "string") {
					res2 = JSON.parse(c.base64.decode(res2.substr(1)));
				}
				if(!a.error) {
					commonS.tip("请求出错："+res2.status+","+res2.statusText)
				} else {
					a.error(res2);
				}
				
			});
	},
	base64: {
		_keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
		decode: function(a) {
			var b, c, d, e, f, g, h, i = this,
				j = "",
				k = 0;
			for (a = a.replace(/[^A-Za-z0-9\+\/\=]/g, ""); k < a.length;) e = i._keyStr.indexOf(a.charAt(k++)), f = i._keyStr.indexOf(a.charAt(k++)), g = i._keyStr.indexOf(a.charAt(k++)), h = i._keyStr.indexOf(a.charAt(k++)), b = e << 2 | f >> 4, c = (15 & f) << 4 | g >> 2, d = (3 & g) << 6 | h, j += String.fromCharCode(b), 64 != g && (j += String.fromCharCode(c)), 64 != h && (j += String.fromCharCode(d));
			return j = i._utf8_decode(j)
		},
		// private method for UTF-8 encoding
		_utf8_decode: function(a) {
			for (var b = "", c = 0, d = c1 = c2 = 0; c < a.length;) d = a.charCodeAt(c), 128 > d ? (b += String.fromCharCode(d), c++) : d > 191 && 224 > d ? (c2 = a.charCodeAt(c + 1), b += String.fromCharCode((31 & d) << 6 | 63 & c2), c += 2) : (c2 = a.charCodeAt(c + 1), c3 = a.charCodeAt(c + 2), b += String.fromCharCode((15 & d) << 12 | (63 & c2) << 6 | 63 & c3), c += 3);
			return b
		},
		encode : function (input) {
		    var c = this,output = "",chr1, chr2, chr3, enc1, enc2, enc3, enc4,i = 0,input = c._utf8_encode(input);
		    while (i < input.length) {
		        chr1 = input.charCodeAt(i++);chr2 = input.charCodeAt(i++);chr3 = input.charCodeAt(i++);
		        enc1 = chr1 >> 2;enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);enc4 = chr3 & 63;
		        if (isNaN(chr2)) {enc3 = enc4 = 64;} else if (isNaN(chr3)) {enc4 = 64;}
		        output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
		    }

		    return output;
		},
		// private method for UTF-8 encoding
		_utf8_encode: function (string) {
		    string = string.replace(/\r\n/g,"\n"),utftext = "";
		    for (var n = 0; n < string.length; n++) {
		        var c = string.charCodeAt(n);
		        if (c < 128) {utftext += String.fromCharCode(c);}
		        else if((c > 127) && (c < 2048)) {utftext += String.fromCharCode((c >> 6) | 192);utftext += String.fromCharCode((c & 63) | 128);}
		        else {utftext += String.fromCharCode((c >> 12) | 224);utftext += String.fromCharCode(((c >> 6) & 63) | 128);utftext += String.fromCharCode((c & 63) | 128);}
		    }
		    return utftext;
		}

	}, 
	setUaObj: function(data) {
		commonM.log("setUaObj:",JSON.stringify(data));
		for(i in data) {
			commonC.uaObj[i] = data[i];
		}
	},
	getQueryString: function(name) {
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
		var r = window.location.search.substr(1).match(reg);
		if (r != null) {
			return unescape(r[2])
		}
		return null
	},
	isFunction: function(a) {
		return typeof a === "function" ? true : false;
	},
	isPureObject: function(a) {
		return a && typeof a == "object" ? true : false;
	},
	checkPhone: function(a) {
		var c = this;
		if(typeof a == "string" && commonC.regContact.test(a)) {
			return true;
		} else {
			return false;
		}
	},
	checkCaptcha: function(a) {
		var c = this;
		if(typeof a == "string" && commonC.regCaptchaPart.test(a)) {
			return true;
		} else {
			return false;
		}
	},
	checkPassword: function(a) {
		var c = this;
		if(typeof a == "string" && commonC.regPassword.test(a)) {
			return true;
		} else {
			return false;
		}
	},
	log: function(tag, sLog, sLevel) {
		var c = this;
		if(_du) {
			if(navigator.userAgent.toLowerCase().match(/(ipad|ipod|iphone|android|coolpad|mmp|smartphone|midp|wap|xoom|symbian|j2me|blackberry|win ce)/i) != null) {
				if(typeof sLog == 'object') {
					alert(tag+"\n"+JSON.stringify(sLog));
				} else {
					alert(tag+"\n"+sLog);
				}
			} else {
				if (sLevel == c.LOGLEVEL.ERROR) {
					console.log("%c[NNError] " + tag, "color:red");
					console.log(sLog);
				} else if (sLevel == c.LOGLEVEL.WARNING) {
					console.log("%c[NNWarn] " + tag, "color:orange");
					console.log(sLog);
				} else if (sLevel == c.LOGLEVEL.INFO) {
					console.log("%c[NNInfo] " + tag, "color:gray");
					console.log(sLog);
				} else {
					console.log("%c[NNInfo] " + tag, "color:gray");
					console.log(sLog);
				}
			}
		}
	},
	checkEntityKey: function(obj, tKeyMap, tag) {
		var result = {}, c = this;
		msg =  tag + "\n";
		result.status = true;
		for (var i = 0; i < tKeyMap.length; i++) {
			var o = tKeyMap[i];
			var type = o.type;
			if(type) {
				var p = obj[o.name];
				var typeN = typeof p;
				if((type == "string" || type == "object") && typeN != type) {
					msg += "参数字段 " + o.name + ": " + p + " 的类型错误，" + "本该是：" + type + ",实际却为：" + typeN + "\n";
					result.status = false;
				} else if(type == "string|int" && typeN != type) {
					msg += "参数字段 " + o.name + ": " + p + " 的类型错误，" + "本该是：字符串或数字" + ",实际却为：" + typeN + "\n";
					result.status = false;
				}
			}
			if (!o.canIgnore && !obj.hasOwnProperty(o.name)) {
				result.status = false;
				msg += "缺少参数字段:" + o.name + "\n";
			} 
			
		}
		result.msg = msg;
		return result;
	},
	browserRel: function(userAgent){
		var u = userAgent||navigator.userAgent;
		var _this = {};
		var match = {
			// //内核
			Trident: u.indexOf('Trident')>0||u.indexOf('NET CLR')>0,
			Presto: u.indexOf('Presto')>0,
            WebKit: u.indexOf('AppleWebKit')>0,
            Gecko: u.indexOf('Gecko/')>0,
			//浏览器
			UC: u.indexOf('UC')>0||u.indexOf(' UCBrowser')>0,
			QQ: u.indexOf('QQBrowser')>0,
            QQin: u.indexOf(' QQ')>0 || u.indexOf('MQQBrowser QQ')>0 || u.indexOf('MQQBrowserQQ')>0,
			BaiDu: u.indexOf('Baidu')>0||u.indexOf('BIDUBrowser')>0,
			Maxthon: u.indexOf('Maxthon')>0,
			LBBROWSER: u.indexOf('LBBROWSER')>0,
			SouGou: u.indexOf('MetaSr')>0||u.indexOf('Sogou')>0,
			IE: u.indexOf('MSIE')>0||u.indexOf('Trident')>0,
			Firefox: u.indexOf('Firefox')>0||u.indexOf('FxiOS')>0,
			Opera: u.indexOf('Opera')>0||u.indexOf('OPR')>0,
			Safari: u.indexOf('Safari')>0,
			Chrome:u.indexOf('Chrome')>0||u.indexOf('CriOS')>0,
			Wechat:u.indexOf('MicroMessenger')>0,
			// 系统或平台
			Windows:u.indexOf('Windows')>0,
			Linux:u.indexOf('Linux')>0,
			Mac:u.indexOf('Macintosh')>0,
			Android:u.indexOf('Android')>0||u.indexOf('Adr')>0,
			WP:u.indexOf('IEMobile')>0,
			BlackBerry:u.indexOf('BlackBerry')>0||u.indexOf('RIM')>0||u.indexOf('BB')>0,
			MeeGo:u.indexOf('MeeGo')>0,
			Symbian:u.indexOf('Symbian')>0,
			iOS:u.indexOf('like Mac OS X')>0,
			iPhone: u.indexOf('iPh')>0,
			iPad:u.indexOf('iPad')>0,
            iPod:u.indexOf('iPod')>0,
			//设备
			Mobile:u.indexOf('Mobi')>0||u.indexOf('iPh')>0||u.indexOf('480')>0,
			Tablet:u.indexOf('Tablet')>0||u.indexOf('iPad')>0||u.indexOf('Nexus 7')>0
		};
		//修正
		if(match.Chrome){
			match.Chrome = !(match.Opera + match.BaiDu + match.Maxthon + match.SouGou + match.UC + match.QQ + match.LBBROWSER);
		}
		if(match.Safari){
			match.Safari = !(match.Chrome + match.Opera + match.BaiDu + match.Maxthon + match.SouGou + match.UC + match.QQ + match.LBBROWSER + match.Firefox);
		}
		if(match.Mobile){
			match.Mobile = !match.iPad;
		}
		//基本信息
		var hash = {
			engine:['WebKit','Trident','Gecko','Presto'],
			// Firefox要放在Safari之后，QQin要放在QQ后，因为前者在某方面会同时也满足后者特性
			browser:['Chrome','Safari','IE','Firefox','Opera','UC','QQ', 'QQin', 'BaiDu','Maxthon','SouGou','LBBROWSER','Wechat'],
			os:['Windows','Linux','Mac','Android','iOS','WP','BlackBerry','MeeGo','Symbian'],
			device:['Mobile','Tablet']
		};
		_this.device = 'PC';
		_this.language = (function(){
			var g = (navigator.browserLanguage || navigator.language).toLowerCase();
			return g=="c"?"zh-cn":g;
		})();
		for(var s in hash){
			for(var i=0;i< hash[s].length;i++){
				var value = hash[s][i];
				if(match[value]){
					_this[s] = value;
				}
			}
		}
		//版本信息
		var browserVersion = {
			'Chrome':function(){
				return u.replace(/^.*(Chrome|CriOS)\/([\d.]+).*$/,'$2');
			},
			'IE':function(){
				var v = u.replace(/^.*MSIE ([\d.]+).*$/,'$1');
				if(v==u){
					v = u.replace(/^.*rv:([\d.]+).*$/,'$1');
				}
				return v!=u?v:'';
			},
			'Firefox':function(){
				return u.replace(/^.*(Firefox|FxiOS)\/([\d.]+).*$/,'$2');
			},
			'Safari':function(){
				return u.replace(/^.*Version\/([\d.]+).*$/,'$1');
			},
			'Maxthon':function(){
				return u.replace(/^.*Maxthon\/([\d.]+).*$/,'$1');
			},
            'SouGou':function(){
                return u.replace(/^.*SogouMobileBrowser\/([\d.]+).*$/,'$1');
            },
			'QQ':function(){
				return u.replace(/^.*(QQBrowser|QQ)\/([\d.]+).*$/,'$2');
			},
            'QQin':function(){
                return u.replace(/^.*QQ\/([\d.]+).*$/,'$1');
            },
			'BaiDu':function(){
				return u.replace(/^.*(BIDUBrowser|baiduboxapp)[\s\/]([\d.]+).*$/,'$2');
			},
			'UC':function(){
				return u.replace(/^.*UCBrowser\/([\d.]+).*$/,'$1');
			},
			'Wechat':function(){
				return u.replace(/^.*MicroMessenger\/([\d.]+).*$/,'$1');
			}
		};
		_this.browserVersion = '';
		if(browserVersion[_this.browser]){
			_this.browserVersion = browserVersion[_this.browser]();
		}

		var osVersion = "";
		switch (_this.os) {
            case 'Mac':
            	if(/Mac OS X ([\.\_\d]+)/.exec(u)) {
                    osVersion = /Mac OS X ([\.\_\d]+)/.exec(u)[1];
                }
                break;

            case 'Android':
            	if(/Android ([\.\_\d]+)/.exec(u)) {
                    osVersion = /Android ([\.\_\d]+)/.exec(u)[1];
                }
                break;

            case 'iOS':
            	if(/OS ([\.\_\d]+) like Mac OS X?/.exec(u)) {
                    osVersion = /OS ([\.\_\d]+) like Mac OS X?/.exec(u)[1];
                }
                break;

        }
        _this.osVersion = osVersion.replace(/_/g,".");

        var deviceType = _this.os;
        switch (_this.os) {
            case 'Android':
            	if(/;\s*([^;]+[^\s;])\s*;?\s*Build/.exec(u)) {
                    deviceType = /;\s*([^;]+[^\s;])\s*;?\s*Build/.exec(u)[1];
                }
                break;
			case 'iOS':
				var a = ["iPhone", "iPad", "iPod"];
				for(i = 0; i < a.length; i++) {
					match[a[i]] && (deviceType = a[i]);
				}
                break;

        }
        _this.deviceType = deviceType;
		return _this;
	},
	escapeHTML: function(text) {
    return text
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
  },
  unescapeHTML: function(text) {
    return text
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&#039;/g, "'")
        // .replace(/\n/g,"</br>")
        .replace(/&amp;nbsp;/g, " ");
  },
  loadScript: function(url, id) {
  	if(id && (document.getElementById(id) !== null)) {
  		return false;
  	}
    var hm = document.createElement("script");
    id && (hm.id = id);
    hm.src = url;
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(hm, s);
    return hm;
  }
};
var commonS = {
	// 简单提示控制
	tip: function(text) {
    $(".brief-tip-pop .con").html(text);
    $(".brief-tip-pop").fadeIn(500).delay(2000).fadeOut(500);
	},
	btnTimeOutControl: function(ele, cls, timeoutClient, timeout) {
    clearTimeout(timeoutClient);
    timeoutClient = setTimeout(function() {
        $(ele).addClass(cls);
    }, timeout || 2000);
	},
	loadingToggle: function(ifShow) {
		if(ifShow) {
            $(".loading-mask").show();
		} else {
            $(".loading-mask").hide();
		}

	},
	popTip: function (text) {
		var c = this;
    $(".common-pop-tip-zone .tip1").html(text);
    c.popControl(".pop-bg-small",".common-pop-tip-zone","提示",false);
  },
  popControl: function(popParentClass, popClass, popTitle, hideClose) {
  		$(".tel-input").val("");
			$(".captcha-input").val("");
			$(".password-input").val("");
			$(".password-input-again").val("");
      $(popParentClass).show().siblings().hide();
      $(popClass).show().siblings().hide();
      popTitle && $(popParentClass + " .pop-title").html(popTitle);
      hideClose ? $(popParentClass + " .close-pop").hide() : $(popParentClass + " .close-pop").show();
      $(".mask").show();
      // alert("mask"+$(".mask").height()+"pop-bg top"+$(".pop-bg-small").offset().top + "pop-small-height"+$(".pop-bg-small").height()+"window.screen.availHeight"+window.screen.availHeight+"screen height"+window.screen.height);
  },
};