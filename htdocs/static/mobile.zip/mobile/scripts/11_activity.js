//获取游戏1礼包
function get_gifts_game(gift_id){
    var user_id = $('#user_id').val();
    //判断user_id
    if(!user_id){
        $('body,html').animate({scrollTop:0},0);
        $("#login").load("/ajax/login",function(responseTxt,statusTxt,xhr){
            if(statusTxt=="error"){
                $("#login").html("<h5>加载数据失败</h5>");
            }
        }).css("display","block");
        $("#login").find("input[name='mobile']").focus();
        return;
    }
    $.ajax({
        type:'post',
        url:'/activity.php?act=ajax_get_gift',
        data:{
            user_id: user_id,
            gift_id: gift_id
        },
        dataType: 'json',
        success: function (json) {
            if(json.msg==1){
                $("#desc_1_1").html("恭喜您成功领取礼包!").attr("style","line-hight:16px;font-size:16px;");
                $("#desc_2_1").html("礼包码:<span style='color:red'>"+json.code+"</span>").attr("style","line-hight:16px;font-size:16px;");
                $("#desc_3_1").html("(长按复制礼包码到游戏中使用)").attr("style","line-hight:16px;font-size:10px;color:blue;");
                $("#hide_alert").show();
                $("#black").show();
                $("#url").hide();
            }else{
                $("#desc_1_1").html("游戏:"+json.game_name).attr("style","line-hight:16px;font-size:16px;");
                $("#desc_2_1").html("礼包码:<span style='color: red;'>"+json.code+"</span>").attr("style","line-hight:16px;font-size:16px;");
                $("#desc_3_1").html("(长按复制礼包码到游戏中使用)").attr("style","line-hight:16px;font-size:10px;color:blue;");
                $("#hide_alert").show();
                $("#black").show();
                $("#url").hide();
            }
        }
    })
}
//获取优惠卷
function receive_coupon(id){
    var user_id = $('#user_id').val();
    //判断user_id
    if(!user_id){
        $('body,html').animate({scrollTop:0},0);
        $("#login").load("/ajax/login",function(responseTxt,statusTxt,xhr){
            if(statusTxt=="error"){
                $("#login").html("<h5>加载数据失败</h5>");
            }
        }).css("display","block");
        $("#login").find("input[name='mobile']").focus();
        return;
    }
    $.ajax({
        type:'post',
        url:'/activity.php?act=ajax_get_coupon',
        data:{
            user_id: user_id,
            coupon_id: id
        },
        dataType: 'json',
        success: function (json) {
            if(json.msg==1){
                $("#desc_1_1").html(json.coupon_name).attr("style","line-hight:16px;font-size:16px;");
                $("#desc_2_1").html(json.title).attr("style","line-hight:16px;font-size:12px;color:blue;");
                $("#desc_3_1").html("");
                $("#url").attr("href",json.url);
                $("#hide_alert").show();
                $("#black").show();
                $("#now_list").show();
            }
        }
    })
}

//抽奖js
var lottery={
    index:0,	//当前转动到哪个位置
    count:9,	//总共有多少个位置
    timer:0,	//setTimeout的ID，用clearTimeout清除
    speed:200,	//初始转动速度
    times:0,	//转动次数
    cycle:100,	//转动基本次数：即至少需要转动多少次再进入抽奖环节
    prize:-1,	//中奖位置
    init:function(id){
        if ($("#"+id).find(".lottery-unit").length>0) {
            $lottery = $("#"+id);
            $units = $lottery.find(".lottery-unit");
            this.obj = $lottery;
            this.count = $units.length;
            $lottery.find(".lottery-unit-"+this.index).addClass("active");
        };
    },
    roll:function(){
        var index = this.index;
        var count = this.count;
        var lottery = this.obj;
        $(lottery).find(".lottery-unit-"+index).removeClass("active");
        index += 1;
        if (index>count-1) {
            index = 0;
        };
        $(lottery).find(".lottery-unit-"+index).addClass("active");
        this.index=index;
        return false;
    },
    stop:function(index){
        this.prize=index;
        return false;
    }
};

function roll(){
    lottery.times += 1;
    lottery.roll();
    var prize_site = $("#lottery").attr("prize_site");
    if (lottery.times > lottery.cycle+10 && prize_site==lottery.index) {
        var prize_id = $("#lottery").attr("prize_id");
        var prize_name = $("#lottery").attr("prize_name");
        var gift_code = $("#lottery").attr("gift_code");
        var share_status =  $("#lottery").attr("share_status");
        clearTimeout(lottery.timer);
        win_info(prize_site,prize_id,prize_name,share_status);
        lottery.prize = -1;
        lottery.times = 0;
        click = false;
    }else{
        if (lottery.times<lottery.cycle) {
            lottery.speed -= 10;
        }else if(lottery.times==lottery.cycle) {
            var index = Math.random()*(lottery.count)|0;
            lottery.prize = index;
        }else{
            if (lottery.times > lottery.cycle+10 && ((lottery.prize==0 && lottery.index==7) || lottery.prize==lottery.index+1)) {
                lottery.speed += 110;
            }else{
                lottery.speed += 20;
            }
        }
        if (lottery.speed<40) {
            lottery.speed=40;
        };
        //console.log(lottery.times+'^^^^^^'+lottery.speed+'^^^^^^^'+lottery.prize);
        lottery.timer = setTimeout(roll,lottery.speed);
    }
    return false;
}

var click=false;

window.onload=function(){

    $("li#weixin").click(function(){
        $(".weixin_show").show();
        $(".draw_alert_box").hide();
    });
    $("#lottery #click").click(function(){
        var user_id = $('#user_id').val();
        //判断user_id
        if(!user_id){
            $('body,html').animate({scrollTop:0},0);
            $("#login").load("/ajax/login",function(responseTxt,statusTxt,xhr){
                if(statusTxt=="error"){
                    $("#login").html("<h5>加载数据失败</h5>");
                }
            }).css("display","block");
            $("#login").find("input[name='mobile']").focus();
            return;
        }
        if(click) {
            return false;
        }else{
            lottery.speed=100;
            $.ajax({
                type:'post',
                url:'/activity.php?act=ajax_draw_acticity',
                data:{
                    user_id:user_id
                },
                dataType: 'json',
                success: function (json) {
                    if(json.msg==1){
                        $("#lottery").attr("prize_site", json.prize_site);
                        $("#lottery").attr("prize_id", json.prize_id);
                        $("#lottery").attr("prize_name", json.prize_name);
                        $("#lottery").attr("share_status", json.share);
                        roll();
                        click=true;
                    }else{
                        if(json.is_share == 1){
                            $(".draw_6").show();
                            $(".draw_alert_box").show();
                            $("#black").show();
                        }else{
                            $(".draw_5").show();
                            $(".draw_alert_box").show();
                            $("#black").show();
                        }
                    }
                },
                error:function(){
                }
            });
            return false;
        }
    });
    lottery.init('lottery');
    $(".share_draw").click(function(){
        var user_id = $('#user_id').val();
        $.ajax({
            type:'post',
            url:'/activity.php?act=ajax_share_activity',
            data:{
                user_id:user_id
            },
            dataType: 'json',
            success: function (json) {

            },
            error:function(){
            }
        });
    })
};

function win_info(id,prize_id,prize_name,share_status) {
    switch(id){
        case '0':
        case '2':
        case '3':
        case '4':
        case '7':
        case '6':
            if(share_status == 1){
                $(".draw_4 .draw_alert_box p .prize_name").html(prize_name);
                $(".draw_alert_box").show();
                $(".draw_4").show();
                $("#black").show();
            }else{
                $(".draw_1 .draw_alert_box p .prize_name").html(prize_name);
                $(".draw_alert_box").show();
                $(".draw_1").show();
                $("#black").show();
            }
            break;
        case '5':
        case '1':
            if(share_status == 1){
                $(".draw_alert_box").show();
                $(".draw_3").show();
                $(".draw_2").hide();
                $(".draw_1").hide();
                $(".draw_4").hide();
                $("#black").show();
            }else{
                $(".draw_alert_box").show();
                $(".draw_2").show();
                $(".draw_3").hide();
                $(".draw_1").hide();
                $(".draw_4").hide();
                $("#black").show();
            }
            break;
    }
}




