/**
 * Created by ong on 14/10/11.
 */
page=1;
act='';
id=0;
$(document).ready(function () {
    /*$(window).scroll(function() {
        *//*判断窗体高度与竖向滚动位移大小相加 是否 超过内容页高度*//*
        if (($(window).height() + $(window).scrollTop()) >= $("body").height() && loading==true) {
            loading=false;
            page = $("input[name='page']").val();
            id = $("input[name='id']").val();
            act = $("input[name='act']").val();
            page = parseInt(page)+1;

            $("#more").html("正在加载中...");
            setTimeout("load_more(id,page,act)",1500);
        }
    });*/

    $("#more").click(function(){
        if(loading==true){
            loading=false;
            page = $("input[name='page']").val();
            id = $("input[name='id']").val();
            act = $("input[name='act']").val();
            page = parseInt(page)+1;
            $("#more").html("正在加载中...");
            setTimeout("load_more(id,page,act)",1500);
        }
    })
});
function load_more(id,page,act){
    if(act!=''){
        url="/game"+id+"/"+act+"?page="+page;
    }else{
        url="/game"+id+"?page="+page;
    }

    $.ajax({
        type:'get',
        url:url,
        data:{},
        dataType: 'json',
        beforeSend:function(){
            $("#more").html("正在加载中...");
        },
        success: function (json) {
            var content = "";
            $(json).each(function(){
                content+="<li>";
                content+="<a href='/item"+this.id+"'>";
                content+="<span class='scmdt-name'>"+this.title+"</span>";
                content+="<em class='scmdt-pri-1'>"+this.dprice+"</em><em class='scmdt-pri-2'>"+this.price+"元</em></a>";
                content+="</li>";
            })
            if(content==""){
                $("#more").html("没有更多了").show();
                loading = false;
            }else{
                $("#more").html("点击加载更多").show();
                $("#more").before(content);
                $("input[name='page']").val(page);
                loading=true;
            }
            if($(json).length<10){
                $("#more").html("没有更多了").show();
                loading=false;
            }
        },
        error:function(){
            $("#page").html("数据加载失败").show();
            loading = false;
        }
    });
}