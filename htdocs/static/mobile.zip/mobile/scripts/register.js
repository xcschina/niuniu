/**
 * Created by Administrator on 2017/8/15.
 */
$("input[name=mobile]").blur(function(){
    reg=/^13[0-9]{9}$|14[0-9]{9}$|15[0-9]{9}$|17[0-9]{9}$|18[0-9]{9}$/;
    if(!reg.test($(this).val())){ $("#register_error").html("手机号码格式不正确").show(); return ;}
    $("#register_error").html("").hide();
});

$('input[name=password]').focus(function () { $('input[name=password]').keyup(); });
$('input[name=cpassword]').focus(function () { $('input[name=cpassword]').keyup();});
$('input[name=sms_code]').blur(function(){if($('input[name=sms_code]').val()!=""){$("#code_error").html("");}})

$('input[name=password]').keyup(function () {
    var __th = $(this);
    var cpsw=$('input[name=cpassword]').val();
    if(!cpsw && cpsw==__th.val()){$("#register_error").html("").hide();}
    if (!__th.val()) { $("#register_error").html("密码不能为空").show();return;}
    if (__th.val().length < 6) { $("#register_error").html("密码为字母和数字，支持大小写，长度6-18个字符").show();return; }
    var _r = checkPassword(__th);
    if (_r < 1) { $("#register_error").html("密码为字母和数字，支持大小写，长度6-18个字符").show(); return;}
    $("#register_error").html("").hide();
});

function checkPassword(pwdinput) {
    var maths, smalls, bigs, corps, cat, num;
    var str = $(pwdinput).val()
    var len = str.length;

    var cat = /.{18}/g
    if (len == 0) return 1;
    if (len > 16) { $(pwdinput).val(str.match(cat)[0]); }
    cat = /.*[\u4e00-\u9fa5]+.*$/
    if (cat.test(str)) {
        return -1;
    }
    cat = /\d/;
    var maths = cat.test(str);
    cat = /[a-z]/;
    var smalls = cat.test(str);
    cat = /[A-Z]/;
    var bigs = cat.test(str);
    var corps = corpses(pwdinput);
    var num = maths + smalls + bigs + corps;

    if (len < 6) { return 1; }

    if (len >= 6 && len <= 8) {
        if (num == 1) return 1;
        if (num == 2 || num == 3) return 2;
        if (num == 4) return 3;
    }

    if (len > 8 && len <= 11) {
        if (num == 1) return 2;
        if (num == 2) return 3;
        if (num == 3) return 4;
        if (num == 4) return 5;
    }

    if (len > 11) {
        if (num == 1) return 3;
        if (num == 2) return 4;
        if (num > 2) return 5;
    }
}

function corpses(pwdinput) {
    var cat = /./g
    var str = $(pwdinput).val();
    var sz = str.match(cat)
    for (var i = 0; i < sz.length; i++) {
        cat = /\d/;
        maths_01 = cat.test(sz[i]);
        cat = /[a-z]/;
        smalls_01 = cat.test(sz[i]);
        cat = /[A-Z]/;
        bigs_01 = cat.test(sz[i]);
        if (!maths_01 && !smalls_01 && !bigs_01) { return true; }
    }
    return false;
}

$('input[name=cpassword]').keyup(function () {
    var psw=$('input[name=password]').val();
    var __th = $(this).val();;
    if(!psw){$("#register_error").html("重复密码不能为空").show();  return;}
    if(__th!=psw){$("#register_error").html("两次密码不一致").show(); return;}
    $("#register_error").html("").hide();
});

//点击获取验证码按钮
$("#send_code").bind("click",function(){
    var _th=$(this);
    if(_th.attr("rel")=="0"){
        return ;
    }
    if($("input[name=mobile]").val().trim().length<11){
        alert('请填写手机号码');
        return false;
    }
    var second = parseInt(179);//倒计时总秒数量
    time=window.setInterval(function(){
        _th.attr("rel","0");
        // var s="重新获取("+second+")";
        //_th.html(s);
        second--;
        if(second<1){
            window.clearTimeout(time);
            _th.css("border","1px solid #317ee7");
            _th.css("color","#317ee7");
            _th.attr("rel","1");
            _th.html("重新获取");
        }else{
            _th.css("border","1px solid #999");
            _th.css("color","#999");
            _th.attr("rel","0");
            _th.html(second+"秒后重新发送");
        }
    }, 1000);

    $.ajax({
        type:'post',
        url:'account.php?act=register_sms_m',
        data:{
            mobile:$("input[name=mobile]").val().trim(),
            pagehash:$("input[name=pagehash]").val()
        },
        dataType: 'json',
        success: function (json) {
            if(json.res==0){
                window.clearTimeout(time);
                $("#register_error").html(json.msg).show();
                _th.css("background","#f9f8f9");
            }
        }
    });
})

$("#submit").bind("click",function(){
    $("#register_error").html("");
    reg=/^13[0-9]{9}$|14[0-9]{9}|15[0-9]{9}$|18[0-9]{9}$|17[0-9]{9}$/;
    if(!reg.test($("input[name=mobile]").val())){ $("#register_error").html("手机号码格式不正确").show(); return;}
    if(!$("input[name=sms_code]").val()){$("#register_error").html("短信验证码不能为空").show(); return;}
    var pass=$('input[name=password]').val();
    var cpass=$('input[name=cpassword]').val();
    if(pass.length<6 || pass.length>18){$("#register_error").html("密码为字母和数字，支持大小写，长度6-18个字符").show(); return ;}
    if(pass!=cpass){$("#register_error").html("两次密码不一致").show(); return;}
    if(!$("input[name=i-read]").is(':checked')){ return;}
    $("#register").submit();
})


