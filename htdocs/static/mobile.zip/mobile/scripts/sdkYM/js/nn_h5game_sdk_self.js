// 悬浮球拖动处理
(function() {
	var flag, hasMoved;
	var curCoor = {
		x: 0,
		y: 0
	};
	var moveX, moveY, offX, offY;
	var touchZone = document.getElementById("touchZone");
    if(!touchZone) {
        return false;
    }
    var viewWidth,viewHeight,touchWidth,touchHeight;
	function down(e) {
		flag = true;
		var touch;
		if(e.touches) {
			touch = e.touches[0];
		} else {
			touch = e;
		}
		curCoor.x = touch.clientX;
		curCoor.y = touch.clientY;
		offX = touchZone.offsetLeft;
		offY = touchZone.offsetTop;
        viewWidth = docElVW || document.documentElement.offsetWidth;
        viewHeight = docElVH || document.documentElement.offsetHeight;
        touchWidth = touchZone.width || 50;
        touchHeight = touchZone.height || 50;
	}
	function move(e) {
		if(flag) {
            hasMoved = true;
			var touch, x, y;
			if(e.touches) {
				touch = e.touches[0];
			} else {
				touch = e;
			}
			moveX = touch.clientX - curCoor.x;
			moveY = touch.clientY - curCoor.y;
			x = moveX + offX;
			y = moveY + offY;
			// console.log("moveX:"+moveX+",moveY:"+moveY);
			// 超越右边界
			if(x + touchWidth > viewWidth) {
				x = viewWidth - touchWidth;
			}
			// 超越下边界
			if((y + touchHeight) > viewHeight) {
				y = viewHeight - touchHeight;
			}
			// 超越左边界
			if(x < 0) {
				x = 0;
			}
			// 超越上边界
			if(y < 0) {
				y = 0;
			}
			touchZone.style.left = x + 'px';
			touchZone.style.top = y + 'px';
		}
	}
	function up(e) {
	    var cx = parseInt(touchZone.style.left);
	    if(hasMoved) {
	    	// commonM.log("float ball touchmove end","(viewWidth - touchWidth) / 2:"+((viewWidth - touchWidth) / 2)+",cx"+cx+"viewWidth - touchWidth"+(viewWidth - touchWidth));
            // touchZone.style.left = cx > (viewWidth - touchWidth) / 2 ? ((viewWidth - touchWidth) + 'px') : (0 + 'px');
            touchZone.style.left = (viewWidth - touchWidth) + 'px';
        }
        // commonM.log("float ball touchmove","viewWidth:"+viewWidth+",screen:"+window.screen.width+",viewWidth - touchWidth:"+(viewWidth - touchWidth)+",touchWidth:"+touchWidth);
		flag = false;
	}
	touchZone.addEventListener("touchstart", function(e) {
		down(e);
	}, false);
	touchZone.addEventListener("touchmove", function(e) {
		e.preventDefault();
		move(e);
	}, false);
	touchZone.addEventListener("touchend", function(e) {
		up(e);
	});
    // document.body.addEventListener("touchmove", function(e) {
		// // if(e.target.id != "touchZone") {
    //         e.preventDefault();
    //         e.stopPropagation();
		// // }
    // });

})();
var floatTimeout; //悬浮球倒计时
var captchaInterval;//弹窗中验证倒计时
var beforeGameInterval;
var nn = {
	va: {
		toBindMobile: "",
		toBindCaptcha: "",
        shareCb: function(code) {
            var a = document.getElementById("gameFrame");
            a && a.contentWindow.postMessage({
                action: "cp_cb_goToShare",
                info: {
                    "code": parseInt(code)
                }
            }, "*")
        }
	},
	event: function() {
		var c = this;
		$("body").on("click", ".before-mask", function() {
            $(".before-mask").hide();
			clearInterval(beforeGameInterval);
		});
		$("body").on("click", ".btn-float-main", function() {
		    if($(".float-sub:visible").length) {
                c.floatToggle(false);
            } else {
                c.floatToggle(true);
            }
		});
		$("body").on("click", ".close-pop, .block-order-prize .btn-start-game," +
            ".block-order-prize .btn-back-grey,.block-integral-lack .btn-back-grey," +
            ".block-quit .btn-cancel,.block-more-game .btn-download-later",
            function(e) {
			e.preventDefault();
		    $(".mask").hide();
		});
		$("body").on("click", ".to-get-captcha", function() {
			c.getCaptcha();
		});
        //非微信打开登录
        $("body").on("click", ".go-login-can", function(e) {
            c.loginWithPhone(e);
        });
        $("body").on("click", ".go-visitor", function(e) {
            commonS.popControl(".pop-stripe-red-small", ".block-open-in-wechat", "请使用微信打开网页", true);
        });
        $("body").on("click", ".block-open-in-wechat .back", function(e) {
            commonS.popControl(".pop-stripe-red-small", ".block-login", "登录牛果账号", true);
        });
        //微信打开首次进入页面
		$("body").on("click", ".btn-entry-bind-phone", function() {
            commonS.popControl(".pop-stripe-red-small", ".block-bind-phone", "绑定手机");
		});
        $("body").on("click", ".btn-login-with-visitor", function() {
            c.loginWithVistor();
        });
        // 绑定手机相关
        $("body").on("click", ".go-bind-can", function(e) {
            c.bindPhone(e);
        });
		$("body").on("click", ".btn-login-with-registered", function() {
			c.loginWithRegistered();
		});
        $("body").on("click", ".btn-bind-another-phone", function() {
            commonS.popControl(".pop-stripe-red-small", ".block-bind-phone", "绑定手机");
            $(".block-bind-phone input").val("");
            clearInterval(captchaInterval);
        });
        $("body").on("click", ".btn-still-visitor", function() {
            if(commonC.infoObj.userId) {
                $(".mask").hide();
            } else {
                c.loginWithVistor();
            }

        });
		// 点击悬浮更多游戏
        $("body").on("click", ".btn-float-more", function() {
            commonS.popControl(".pop-pure-small", ".block-more-game");
            c.floatToggle(false);
        });
        // 退出账号
        $("body").on("click", ".btn-float-quit", function() {
            commonS.popControl(".pop-pure-small", ".block-quit");
            c.floatToggle(false);
        });
        $("body").on("click", ".block-quit .go-quit", function() {
            c.quit();
        });
		// 积分相关
        $("body").on("click", ".btn-float-prize", function() {
            commonS.popControl(".pop-stripe-red-large", ".block-prize", "幸福福地");
            c.floatToggle(false);
            c.getPrizeList();
        });
        $("body").on("click", ".btn-go-prize", function(e) {
            // 绑定手机了才能抽奖
            if(commonC.infoObj.mobile) {
                c.orderPrize($(e.target).data("goodsid"));
            } else {
                commonS.popControl(".pop-stripe-red-small", ".block-bind-phone", "绑定手机");
            }
        });
        $("body").on("click", ".get-more-prize", function() {
            commonS.popControl(".pop-pure-small", ".block-more-game");
        });
        // 点击关闭引导分享图层
        $("body").on("click", ".share-mask", function(e) {
            $(e.currentTarget).hide();
        });

	},
	getCaptcha: function() {
		var c = this;
		var account = $(".tel-input:visible").val().trim();
		if(!commonM.checkPhone(account)) {
    		commonS.tip("请填写正确的手机号码！");
    		$(".captcha-tip").removeClass("to-get-captcha");
    		setTimeout(function() {
    			$(".captcha-tip").addClass("to-get-captcha");
    		}, 2000);
    	}
    	else {
	    	$(".captcha-tip").removeClass("to-get-captcha").html('<span class="count-time">120</span>s后获取');
	    	var countDownRest = 120;
	    	clearInterval(captchaInterval);
	    	captchaInterval = setInterval(function() {
	    		if(countDownRest > 1) {
	    			countDownRest--;
	    			$(".count-time").html(countDownRest)
	    		}
	    		else {
                    clearInterval(captchaInterval);
	    			$(".captcha-tip").html("获取验证码").addClass("to-get-captcha");
	    		}

	    	}, 1000);
            commonM.ajax({
                url: "/integral.php?act=sms_code",
                type: "post",
                dataType: "text",
                data: {
                	mobile: encodeURIComponent(encrypt.encrypt(account))
                },
                success: function(res) {
                    var code = res.result;
                    var data = res.data || {};
	            	commonS.tip(res.desc);
	            	if(code == 2) {
	            		countDownRest = 5;
	            	} else if(code == 3) {

                    }
	        	},
                error: function(res2) {
                    countDownRest = 5;
                    commonS.tip("请求出错："+res2.status+","+res2.statusText);
                }
            })
	    }
	},
	// 非微信时登录
    loginWithPhone: function(e) {
        var c = this;
        var account = $(".tel-input:visible").val().trim();
        var verifycode = $(".captcha-input:visible").val().trim();
        $(".go-login").removeClass("go-login-can");
        setTimeout(function() {
            $(".go-login").addClass("go-login-can");
        }, 3000);
        if(!commonM.checkPhone(account)) {
            commonS.tip("请填写正确的手机号码！");
            return false;
        }
        if(!commonM.checkCaptcha(verifycode)) {
            commonS.tip("请填写正确的验证码！");
            return false;
        }
        commonS.loadingToggle(true);
        commonM.ajax({
            url: "/integral.php?act=do_login",
            type: "post",
            dataType: "text",
            data: {
                mobile: encodeURIComponent(encrypt.encrypt(account)),
                sms_code: verifycode
            },
            success: function(res) {
                commonS.loadingToggle(false);
                if(res.result == 1) {
                    window.location.reload();
                } else {
                    commonS.tip(res.desc);
                }
            },
            error: function(res2) {
                commonS.loadingToggle(false);
                commonS.tip("请求出错："+res2.status+","+res2.statusText);
            }
        })
	},
	// 微信中绑定手机(登录时或以游客登录要抽奖时)
	bindPhone: function(e) {
		var c = this;
		var account = $(".tel-input:visible").val().trim();
		var verifycode = $(".captcha-input:visible").val().trim();
        c.va.toBindMobile = account;
        c.va.toBindCaptcha = verifycode;
		$(".go-bind").removeClass("go-bind-can");
		setTimeout(function() {
			$(".go-bind").addClass("go-bind-can");
		}, 3000);
		if(!commonM.checkPhone(account)) {
			commonS.tip("请填写正确的手机号码！");
			return false;
		}
		if(!commonM.checkCaptcha(verifycode)) {
			commonS.tip("请填写正确的验证码！");
			return false;
		}
        commonS.loadingToggle(true);
		if(commonC.uaObj.userId){
		    var url = '/integral.php?act=bind_mobile';
        }else{
		    var url = '/integral.php?act=do_login';
        }
		commonM.ajax({
			url: url,
	 		type: "post",
	 		dataType: "text",
	 		data: {
	 			mobile: encodeURIComponent(encrypt.encrypt(account)),
	 			sms_code: verifycode
	 		},
	 		success: function(res) {
			    var code = res.result;
                commonS.loadingToggle(false);
	 			if(code == 1) {
                    window.location.reload();
	 				
	 			} else if (code == 2){
	 			    // 该账号已绑定手机
                    commonS.popControl(".pop-stripe-red-small", ".block-already-registered", "温馨提示");
                } else {
                        commonS.tip(res.desc)
	 			}
	 		},
            error: function(res2) {
                commonS.loadingToggle(false);
                commonS.tip("请求出错："+res2.status+","+res2.statusText);
            }
		})
	},
	// 微信时用已有手机号登录
    loginWithRegistered: function() {
	    var c = this;
        commonS.loadingToggle(true);
        commonM.ajax({
            url: "/integral.php?act=login_registered",
            type: "post",
            dataType: "text",
            data: {
                mobile: encodeURIComponent(encrypt.encrypt(c.va.toBindMobile)),
                sms_code: c.va.toBindCaptcha
            },
            success: function(res) {
                commonS.loadingToggle(false);
                if(res.result == 1) {
                    window.location.reload();

                } else {
                    commonS.tip(res.desc);
                }
            },
            error: function(res2) {
                commonS.loadingToggle(false);
                commonS.tip("请求出错："+res2.status+","+res2.statusText);
            }
        })
	},
	// 微信以游客登录
    loginWithVistor: function() {
        commonS.loadingToggle(true);
        var url = "http://wx.66173yx.com/warrant.php?act=ylc&app_id="+commonC.uaObj.appId+"&channel="+commonC.uaObj.channel;
        window.location.href = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=wxf965c4a0c7bf9851&redirect_uri="+encodeURIComponent(url)+"&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect";
        // commonM.ajax({
        //     url: "/integral.php?act=wx_warrant",
        //     type: "post",
        //     dataType: "text",
        //     data:{
        //         channel:commonC.uaObj.channel,
        //         app_id:commonC.uaObj.appId
        //     },
        //     success: function(res) {
        //         commonS.loadingToggle(false);
        //         if(res.result == 1) {
        //             window.location.reload();
        //
        //         } else {
        //             commonS.tip(res.desc);
        //         }
        //     },
        //     error: function(res2) {
        //         commonS.loadingToggle(false);
        //         commonS.tip("请求出错："+res2.status+","+res2.statusText);
        //     }
        // })
	},
	quit: function() {
        commonS.loadingToggle(true);
        commonM.ajax({
            url: "/integral.php?act=logout",
            type: "post",
            dataType: "text",
            success: function(res) {
                commonS.loadingToggle(false);
                var code = res.result;
                if(code == 1) {
                    window.location.reload();

                } else {
                    commonS.tip(res.desc);
                }
            },
            error: function(res2) {
                commonS.loadingToggle(false);
                commonS.tip("请求出错："+res2.status+","+res2.statusText);
            }
        })
	},
	// 预定奖品
	orderPrize: function(goodsid) {
		var c = this;
		if(goodsid) {
            commonS.loadingToggle(true);
            commonM.ajax({
                url: "/integral.php?act=exchange",
                type: "post",
                dataType: "text",
				data: {
                	id: goodsid
				},
                success: function(res) {
                    commonS.loadingToggle(false);
                    var code = res.result;
                    c.updateIntegral(res.integral);
                    if(code == 1) {
                        commonS.popControl(".pop-stripe-red-fireworks", ".block-order-prize", "您已成功预定该奖品");
                    } else if(code == 2) {
                        commonS.popControl(".pop-stripe-grey-small", ".block-integral-lack", "积分不足");
                    } else if(code == 3) {
                        commonS.popControl(".pop-stripe-red-small", ".block-bind-phone", "绑定手机");
                    } else if(code == 4) {
                        commonS.popControl(".pop-stripe-red-small", ".block-wechat-first", "温馨提示");
                    } else {
                        commonS.tip(res.desc);
                    }
                },
                error: function(res2) {
                    commonS.loadingToggle(false);
                    commonS.tip("请求出错："+res2.status+","+res2.statusText);
                }
            })
		}
	},
	//获取可抽奖列表
	getPrizeList: function() {
        commonM.ajax({
            url: "/integral.php?act=draw_list",
            type: "post",
            data:{app_id:commonC.uaObj.appId},
            dataType: "text",
            success: function (res) {
                var code = res.result;
                if (code == 1) {
                    var data = res.data || [];
					var con = "";
					for (var i = 0; i < data.length; i++) {
						con += '<div class="item"><div class="left">'
                            	+ '<img class="icon" src="//cdn.66173.cn' + data[i].app_icon + '" alt="" >'
								+ '<div class="text-overflow goods-name">' + data[i].good_name + '</div></div>'
								+ '<span class="background-img btn-go-prize" data-goodsid="' + data[i].id + '">' + data[i].consume + '积分抽</span>'
                        		+ '</div>'
					}
					$(".block-prize .prize-list").html(con);

                } else {
                    commonS.tip(res.desc);
                }
            },
            error: function (res2) {
                commonS.tip("请求出错：" + res2.status + "," + res2.statusText);
            }
        })
	},
	// 更新积分
	updateIntegral: function(num) {
		var a = parseInt(num);
		if(a) {
			commonC.infoObj.integral = a;
			$("#integral").val(a);
		}
	},
    // 悬浮球倒计时
    floatToggle: function(ifShow) {
	    if(ifShow) {
            $(".float-sub").show();
	        floatTimeout = setTimeout(function() {
                $(".float-sub").hide();
            }, 5000);
        } else {
            $(".float-sub").hide();
	        clearTimeout(floatTimeout);
        }
    },
    // 二维码生成
    qrcodeRender: function() {
	    var c = this;
        var hm = commonM.loadScript("//cdn.66173.cn/mobile/v2/scripts/qrcode.min.js", "qrcodeJs");
        hm.onload = hm.onreadystatechange = function() {
            hm.onload = hm.onreadystatechange = null;
            if (!this.readyState || this.readyState == "loaded" || this.readyState == "complete") {
                if ($("#qrcode").length > 0) {
                    var qrcode = new QRCode(document.getElementById("qrcode"), {
                        width: 120,
                        height: 120,
                        correctLevel: QRCode.CorrectLevel.L
                    });
                    qrcode.makeCode(commonC.infoObj.mAddress || window.location.href);
                }
                if ($("#qrcode2").length > 0) {
                    var qrcode = new QRCode(document.getElementById("qrcode2"), {
                        width: 120,
                        height: 120,
                        correctLevel: QRCode.CorrectLevel.L
                    });
                    qrcode.makeCode(commonC.infoObj.mAddress || window.location.href);
                };
            }
        }
    },
    deferLoadJs: function() {

    },
	init: function() {
		var c = this;
		var b = commonM.browserRel();
		var t = (new Date()).getTime();
		commonC.uaObj = {
			system: b.os || "",
            deviceType: b.deviceType || "",
            osVer: b.osVersion || "",
			browser: b.browser || "",
			broswerVer: b.browserVersion || "",
            lang: b.language || "",
			sdkVer: "1.0.0.1",
            token: $("#token").val(),
            channel: $("#channel").val(),
            userId: $("#userId").val(),
            userName: $("#userName").val(),
            appId: $("#appId").val(),
			timestamp: t,
			safety: md5($("#appId").val()+$("#channel").val()+t+$("#token").val())
		};
		commonC.infoObj = {
            integral: $("#integral").val(),
			mobile: $("#mobile").val(),
			userId: $("#userId").val(),
			userName: $("#userName").val(),
			wxIconUrl: $("#img").val(),
            sex: $("#sex").val(),
            isWeixinBrowser: commonM.isWeixinBrowser && commonM.isWeixinBrowser(),
            isPc: commonM.isPc && commonM.isPc(),
            mAddress: $("#mAddress").val() || window.location.href
		};

        $(window).load(function() {
            commonM.shareSelfLoad($("title").html(), $("meta[name=description]").attr("content"), $(".share-img").attr("src"), window.location.href, windwo.nn && windwo.nn.va && nn.va.shareCb);
        });
        $(".block-open-in-m .m-address").html(commonC.infoObj.mAddress).attr("href", commonC.infoObj.mAddress);
		c.qrcodeRender();
        c.event();
        setTimeout(function () {
            commonM.ajax({
                url: "integral.php?act=device",
                type: "post",
                dataType: "text"
            });
            commonM.ajax({
                url: "integral.php?act=login",
                type: "post",
                dataType: "text"
            });
        }, 500);
        // 启动页
        if($(".before-mask").length) {
            var r = 3;
            beforeGameInterval = setInterval(function () {
                if (r > 1) {
                    r--;
                    $(".before-mask .time").html(r);
                } else {
                    $(".before-mask").hide();
                    clearInterval(beforeGameInterval);
                }
            }, 1000)
        }
        // 已登录才显示游戏页面
        if(!commonC.infoObj.isPc) {
            if (commonC.infoObj.userId) {
                (function () {
                    var gameUrl = $("#gameUrl").val();
                    if(gameUrl){
                        var gameFrameDiv = document.getElementById("gameFrameDiv");
                        var iframe = document.createElement("iframe");
                        var a = "appId=" + $("#appId").val() + "&channel=" + $("#channel").val() + "&userId=" + $("#userId").val() + "&token=" + $("#token").val() + "&t=" + (new Date()).getTime();
                        gameUrl = gameUrl.indexOf("?") > 0 ? gameUrl + "&" + a : gameUrl + "?" + a;
                        iframe.setAttribute("src", gameUrl);
                        iframe.setAttribute("id", "gameFrame");
                        iframe.setAttribute("frameborder", "0");
                        gameFrameDiv.appendChild(iframe);
                    }
                })();
            } else {
                // 未登录分：微信/非微信打开
                if (commonC.infoObj.isWeixinBrowser) {
                    commonS.popControl(".pop-stripe-red-small", ".block-wechat-first", "温馨提示", true);
                } else {
                    commonS.popControl(".pop-stripe-red-small", ".block-login", "登录牛果账号", true);
                }
            }
        } else {
            commonS.popControl(".pop-pure-large", ".block-open-in-m");
        }
	}
};
nn.init();