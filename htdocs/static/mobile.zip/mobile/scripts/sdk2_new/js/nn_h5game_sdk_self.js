// 悬浮球拖动处理
(function() {
	var flag, hasMoved;
	var curCoor = {
		x: 0,
		y: 0
	};
	var moveX, moveY, offX, offY;
	var touchZone = document.getElementById("touchZone");
    var viewWidth,viewHeight,touchWidth,touchHeight;
	function down(e) {
		flag = true;
		var touch;
		if(e.touches) {
			touch = e.touches[0];
		} else {
			touch = e;
		}
		curCoor.x = touch.clientX;
		curCoor.y = touch.clientY;
		offX = touchZone.offsetLeft;
		offY = touchZone.offsetTop;
        viewWidth = docElVW || document.documentElement.offsetWidth;
        viewHeight = docElVH || document.documentElement.offsetHeight;
        touchWidth = touchZone.width || 50;
        touchHeight = touchZone.height || 50;
	}
	function move(e) {
		if(flag) {
            hasMoved = true;
			var touch, x, y;
			if(e.touches) {
				touch = e.touches[0];
			} else {
				touch = e;
			}
			moveX = touch.clientX - curCoor.x;
			moveY = touch.clientY - curCoor.y;
			x = moveX + offX;
			y = moveY + offY;
			// console.log("moveX:"+moveX+",moveY:"+moveY);
			// 超越右边界
			if(x + touchWidth > viewWidth) {
				x = viewWidth - touchWidth;
			}
			// 超越下边界
			if((y + touchHeight) > viewHeight) {
				y = viewHeight - touchHeight;
			}
			// 超越左边界
			if(x < 0) {
				x = 0;
			}
			// 超越上边界
			if(y < 0) {
				y = 0;
			}
			touchZone.style.left = x + 'px';
			touchZone.style.top = y + 'px';
		}
	}
	function up(e) {
	    var cx = parseInt(touchZone.style.left);
	    if(hasMoved) {
	    	// commonM.log("float ball touchmove end","(viewWidth - touchWidth) / 2:"+((viewWidth - touchWidth) / 2)+",cx"+cx+"viewWidth - touchWidth"+(viewWidth - touchWidth));
            // touchZone.style.left = cx > (viewWidth - touchWidth) / 2 ? ((viewWidth - touchWidth) + 'px') : (0 + 'px');
            touchZone.style.left = (viewWidth - touchWidth) + 'px';
        }
        // commonM.log("float ball touchmove","viewWidth:"+viewWidth+",screen:"+window.screen.width+",viewWidth - touchWidth:"+(viewWidth - touchWidth)+",touchWidth:"+touchWidth);
		flag = false;
	}
	touchZone.addEventListener("touchstart", function(e) {
		down(e);
	}, false);
	touchZone.addEventListener("touchmove", function(e) {
		e.preventDefault();
		move(e);
	}, false);
	touchZone.addEventListener("touchend", function(e) {
		up(e);
	});
    // document.body.addEventListener("touchmove", function(e) {
		// // if(e.target.id != "touchZone") {
    //         e.preventDefault();
    //         e.stopPropagation();
		// // }
    // });

})();

var goBindTimeout; //弹窗中绑定定时
var captchaInterval;//弹窗中验证倒计时
var beforeGameInterval;
var nn = {
	va: {
		rePhone: "",
		reCapt: "",
		regIntervalMap: {
			1: null,
			2: null,
			3: null,
			4: null
		}
	},
	event: function() {
		var c = this;
		$("body").on("click", ".before-mask", function() {
      $(".before-mask").hide();
			clearInterval(beforeGameInterval);
		});
		$("body").on("click", "#touchZone", function() {
			$(".not-bind .step2").hide().siblings().show();
			if(commonC.infoObj.mobile) {
				commonS.popControl(".pop-user-rel",".already-bind","我的信息",false);
			} else {
				commonS.popControl(".pop-user-rel",".not-bind","我的信息",false);
			}
			$(".mask").show();
		});
		$("body").on("click", ".mask .close-pop, .common-pop-tip-zone .btn-zone", function() {
			$(".mask").hide();
		});
		// 关闭公告弹窗
		$("body").on("click", ".notice-mask .close-pop", function() {
			$(".notice-mask").hide();
		})
		$("body").on("click", ".not-bind .back-pop", function() {
			$(".pop-user-rel .pop-title").html("我的信息");
			$(".not-bind .step2").hide().siblings().show();
		});
		$("body").on("click", ".not-bind .to-bind", function() {
			$(".tel-input").val("");
			$(".captcha-input").val("");
			$(".pop-user-rel .pop-title").html("手机号绑定");
			$(".not-bind .step1").hide().siblings().show();
		});
		$("body").on("click", ".to-get-captcha", function(e) {
			c.getCaptcha(e);
		});
		// 绑定手机
		$("body").on("click", ".go-bind-can", function(e) {
			c.bindPhone(e);
		});
		// 登录或退出相关
		// 退出登录
		$("body").on("click", ".log-out", function() {
			c.logOut();
		});
		// 密码登录
		$("body").on("click", ".go-login-can", function(e) {
			c.loginPhone(e);
		})
		// 验证码登录
		$("body").on("click", ".go-login-msg-can", function(e) {
			c.loginMsgPhone(e);
		})
		// 注册
		$("body").on("click", ".go-register-can", function(e) {
			c.registerPhone(e);
		})
		// 重置密码
		$("body").on("click", ".block-forget .go-reset-can", function(e) {
			c.resetPsw(e);
		})
		// 用手机号方式
		$("body").on("click", ".block-way-choose .mobile", function(e) {
			commonS.popControl(".pop-login-rel",".block-login","游戏登录",true);
		});
		// 其他方式
		$("body").on("click", ".block-login .other-way-tip", function() {
			commonS.popControl(".pop-login-rel",".block-way-choose","游戏登录",true);
		})
		// 短信验证码方式
		$("body").on("click", ".block-login .by-msg-tip", function() {
			commonS.popControl(".pop-login-rel",".block-login-msg","游戏登录",true);
		})
		// 注册方式
		$("body").on("click", ".block-login .register-tip", function() {
			commonS.popControl(".pop-login-rel",".block-register","账号注册",true);
		})
		// 返回登录
		$("body").on("click", ".block-login-rel .back-login-tip", function() {
			commonS.popControl(".pop-login-rel",".block-login","游戏登录",true);
		})
		// 忘记密码
		$("body").on("click", ".block-login-rel .forget-tip", function() {
			commonS.popControl(".pop-login-rel",".block-forget","重置密码",true);
		})
		// 查看服务协议
		$("body").on("click", ".agree-tip .text", function() {
			$(".agree-mask").show();
		})
		// 关闭服务协议
		$("body").on("click", ".agree-mask .close-pop", function() {
			$(".agree-mask").hide();
		})
		// 支付
		$("body").on("click", ".pop-pay .go-pay-can", function(e) {
			var $ele = $(e.currentTarget);
			var type = $ele.data("type");
			if(!type) {
				commonS.tip("请选择支付方式");
				return false;
			}
      window.wrapObj && wrapObj.wayPay(type);
    });
    //  支付方式选择
    $("body").on("click", ".pay-way-choose .item", function(e) {
    	var $ele = $(e.currentTarget);
			var type = $ele.data("type");
			$ele.addClass("active").siblings().removeClass("active");
			$(".pop-pay .go-pay").data("type",type);
    });
    //  返回支付选择
    $("body").on("click", ".pop-scan .back-pop", function(e) {
			commonS.popControl(".pop-pay-rel",".pop-pay","选择支付方式",false);
			// window.wrapObj && wrapObj.stopOd();
    });
    // 结束询
    $("body").on("click", ".mask .pop-pay-rel .close-pop", function() {
			// window.wrapObj && wrapObj.stopOd();
		});
	},
	getCaptcha: function(e) {
		var c = this;
		var $ele = $(e.currentTarget);
		var type = $ele.data("type");
		var index = $ele.data("index") || 1;
		var regIntervalMap = c.va.regIntervalMap;
		console.log("type:"+type)
		var account = $(".tel-input:visible").val().trim();
		if(!commonM.checkPhone(account)) {
  		commonS.tip("请填写正确的手机号码！");
  		$ele.removeClass("to-get-captcha");
  		setTimeout(function() {
  			$ele.addClass("to-get-captcha");
  		}, 2000);
  		return false;
  	}
  	$ele.removeClass("to-get-captcha").html('<span class="count-time">60</span>s后获取');
  	var countDownRest = 60;
  	clearInterval(regIntervalMap[index]);
  	regIntervalMap[index] = setInterval(function() {
  		if(countDownRest > 1) {
  			countDownRest--;
  			$ele.find(".count-time").html(countDownRest)
  		}
  		else {
  			$ele.html("获取验证码").addClass("to-get-captcha");
  			clearInterval(regIntervalMap[index])
  		}

  	}, 1000);
  	if(type == "wish_bind_not") {
      commonM.ajax({
        url: "/h5_api.php?act=check",
        type: "post",
        dataType: "text",
        data: {
        	mobile: encodeURIComponent(encrypt.encrypt(account))
        },
        success: function(res) {
          var code = res.result;
          var data = res.data || {};
        	commonS.tip(res.desc);
        	if(code == 2) {
        		countDownRest = 5;
        	} else if(code == 3) {
              commonC.infoObj.mobile = data.mobile;
              $("#mobile").val(data.mobile);
              c.infoS();
          }
      	}
      })
    } else if(type == "wish_reg_not") {
    	commonM.ajax({
        url: "/h5_api.php?act=reg_code",
        type: "post",
        dataType: "text",
        data: {
        	mobile: encodeURIComponent(encrypt.encrypt(account))
        },
        success: function(res) {
          var code = res.result;
          var data = res.data || {};
        	commonS.tip(res.desc);
        	if(code == 2) {
        		countDownRest = 5;
        	}
      	}
      })
    } else if(type == "wish_reg_yes") {
    	commonM.ajax({
        url: "/h5_api.php?act=check_code",
        type: "post",
        dataType: "text",
        data: {
        	mobile: encodeURIComponent(encrypt.encrypt(account))
        },
        success: function(res) {
          var code = res.result;
          var data = res.data || {};
        	commonS.tip(res.desc);
        	if(code == 2) {
        		countDownRest = 5;
        	}
      	}
      })
    }
	},
	showNotice: function() {
		if($("#hasNotice").val() == "1" && $("#noticeCon").val()) {
			$(".pop-notice-main").html(commonM.unescapeHTML($("#noticeCon").val()));
			$(".notice-mask").show();
		}
	},
	infoS: function() {
		var c = this;
		var data = commonC.infoObj;
		var isPC = data.browserRel.device == 'PC' ? true : false;
		var isWX = data.browserRel.browser == 'Wechat' ? true : false;
		if(data.mobile) {
			$(".already-bind .phone").html(data.mobile);
		}
		$(".bind-info-rel .register-time").html(data.registerTime);
		$(".already-bind .user-id").html(data.userName);
		$(".not-bind .user-id").html(data.userName);
		if(!isWX) {
			$(".log-out").show();
		}
		if(!data.userId) {
			$("#touchZone").hide();
			// if(isPC) {
			// 	$(".block-login").addClass("isPC");
			// 	commonS.popControl(".pop-login-rel", ".block-way-choose", "游戏登录", true);
			// } else {
			// 	commonS.popControl(".pop-login-rel", ".block-login", "游戏登录", true);
			// }
			commonS.popControl(".pop-login-rel", ".block-login", "游戏登录", true);
		} 
	},
	// 绑定手机
	bindPhone: function(e) {
		var c = this;
		var account = $(".not-bind .tel-input:visible").val().trim();
		var verifycode = $(".not-bind .captcha-input:visible").val().trim();
		var password = $(".not-bind .password-input:visible").val().trim();
		var passwordAgain = $(".not-bind .password-input-again:visible").val().trim();
		$(".go-bind").removeClass("go-bind-can");
		setTimeout(function() {
			$(".go-bind").addClass("go-bind-can");
		}, 3000);
		if(!commonM.checkPhone(account)) {
			commonS.tip("请填写正确的手机号码！");
			return false;
		}
		if(!commonM.checkCaptcha(verifycode)) {
			commonS.tip("请填写正确的验证码！");
			return false;
		}
		if(!commonM.checkPassword(password) || !commonM.checkPassword(passwordAgain)) {
			if(!password || !passwordAgain) {
				commonS.tip("请填写密码");
				return false;
			} else {
				commonS.tip("密码必须是6-12位数字或字母");
				return false;
			}
		}
		if(password != passwordAgain) {
			commonS.tip("两次密码不一致");
			return false;
		}
    commonS.loadingToggle(true);
		commonM.ajax({
			url: "/h5_api.php?act=bind",
	 		type: "post",
	 		dataType: "text",
	 		data: {
	 			mobile: encodeURIComponent(encrypt.encrypt(account)),
	 			verifycode: encodeURIComponent(encrypt.encrypt(verifycode)),
	 			password: encodeURIComponent(encrypt.encrypt(password)),
	 			passwordAgain: encodeURIComponent(encrypt.encrypt(passwordAgain))
	 		},
	 		success: function(res) {
        commonS.loadingToggle(false);
	 			if(res.result == 1) {
	 				commonS.tip(res.desc);
	 				commonC.infoObj.mobile = res.data && res.data.mobile;
	 				$("#mobile").val(res.data && res.data.mobile);
	 				$(".mask").hide();
	 				c.infoS();
	 				var a = document.getElementById("gameFrame");
					a && a.contentWindow.postMessage({
						action: "cp_cb_mBind",
						info: {
							"uinfo": {
								"isMBind": true
							}
						}
					}, "*")
	 				
	 			} else {
	 				commonS.tip(res.desc);
	 			}
	 		},
      error: function(res2) {
          commonS.loadingToggle(false);
          commonS.tip("请求出错："+res2.status+","+res2.statusText);
      }
		})
	},
	// 密码登录
	loginPhone: function(e) {
		var c = this;
		var account = $(".block-login .tel-input:visible").val().trim();
		var password = $(".block-login .password-input:visible").val().trim();
		$(".go-login").removeClass("go-login-can");
		setTimeout(function() {
			$(".go-login").addClass("go-login-can");
		}, 3000);
		if(!commonM.checkPhone(account)) {
			commonS.tip("请填写正确的手机号码！");
			return false;
		}
		if(!commonM.checkPassword(password)) {
			if(!password) {
				commonS.tip("请填写密码");
			} else {
				commonS.tip("密码必须是6-12位数字或字母");
			}
			return false;
		}
    commonS.loadingToggle(true);
		commonM.ajax({
			url: "/h5_api.php?act=accountpwd",
	 		type: "post",
	 		dataType: "text",
	 		data: {
	 			mobile: encodeURIComponent(encrypt.encrypt(account)),
	 			password: encodeURIComponent(encrypt.encrypt(password))
	 		},
	 		success: function(res) {
        commonS.loadingToggle(false);
	 			if(res.result == 1) {
	 				window.location.reload();
	 				
	 			} else {
	 				commonS.tip(res.desc);
	 			}
	 		},
      error: function(res2) {
          commonS.loadingToggle(false);
          commonS.tip("请求出错："+res2.status+","+res2.statusText);
      }
		})
	},
	// 验证码登录
	loginMsgPhone: function(e) {
		var c = this;
		var account = $(".block-login-msg .tel-input:visible").val().trim();
		var verifycode = $(".block-login-msg .captcha-input:visible").val().trim();
		$(".go-login-msg").removeClass("go-login-msg-can");
		setTimeout(function() {
			$(".go-login-msg").addClass("go-login-msg-can");
		}, 3000);
		if(!commonM.checkPhone(account)) {
			commonS.tip("请填写正确的手机号码！");
			return false;
		}
		if(!commonM.checkCaptcha(verifycode)) {
			commonS.tip("请填写正确的验证码！");
			return false;
		}
    commonS.loadingToggle(true);
		commonM.ajax({
			url: "/h5_api.php?act=accountcode",
	 		type: "post",
	 		dataType: "text",
	 		data: {
	 			mobile: encodeURIComponent(encrypt.encrypt(account)),
	 			verifycode: encodeURIComponent(encrypt.encrypt(verifycode))
	 		},
	 		success: function(res) {
        commonS.loadingToggle(false);
	 			if(res.result == 1) {
	 				window.location.reload();
	 				
	 			} else {
	 				commonS.tip(res.desc);
	 			}
	 		},
      error: function(res2) {
          commonS.loadingToggle(false);
          commonS.tip("请求出错："+res2.status+","+res2.statusText);
      }
		})
	},
	// 注册
	registerPhone: function(e) {
		var c = this;
		var account = $(".block-register .tel-input:visible").val().trim();
		var verifycode = $(".block-register .captcha-input:visible").val().trim();
		var password = $(".block-register .password-input:visible").val().trim();
		var agree = $(".block-register .agree-tip input").is(":checked");
		$(".go-register").removeClass("go-register-can");
		setTimeout(function() {
			$(".go-register").addClass("go-register-can");
		}, 3000);
		if(!commonM.checkPhone(account)) {
			commonS.tip("请填写正确的手机号码！");
			return false;
		}
		if(!commonM.checkCaptcha(verifycode)) {
			commonS.tip("请填写正确的验证码！");
			return false;
		}
		if(!commonM.checkPassword(password)) {
			if(!password) {
				commonS.tip("请填写密码");
			} else {
				commonS.tip("密码必须是6-12位数字或字母");
			}
			return false;
		}
		if(!agree) {
			commonS.tip("请勾选服务条款");
			return false;
		}
    commonS.loadingToggle(true);
		commonM.ajax({
			url: "/h5_api.php?act=accountreg",
	 		type: "post",
	 		dataType: "text",
	 		data: {
	 			mobile: encodeURIComponent(encrypt.encrypt(account)),
	 			verifycode: verifycode,
	 			password: encodeURIComponent(encrypt.encrypt(password))
	 		},
	 		success: function(res) {
        commonS.loadingToggle(false);
	 			if(res.result == 1) {
	 				window.location.reload();
	 				
	 			} else {
	 				commonS.tip(res.desc);
	 			}
	 		},
      error: function(res2) {
          commonS.loadingToggle(false);
          commonS.tip("请求出错："+res2.status+","+res2.statusText);
      }
		})
	},
	// 重置密码
	resetPsw: function(e) {
		var c = this;
		var account = $(".block-forget .tel-input:visible").val().trim();
		var verifycode = $(".block-forget .captcha-input:visible").val().trim();
		var password = $(".block-forget .password-input:visible").val().trim();
		var passwordAgain = $(".block-forget .password-input-again:visible").val().trim();
		$(".go-reset").removeClass("go-reset-can");
		setTimeout(function() {
			$(".go-reset").addClass("go-reset-can");
		}, 3000);
		if(!commonM.checkPhone(account)) {
			commonS.tip("请填写正确的手机号码！");
			return false;
		}
		if(!commonM.checkCaptcha(verifycode)) {
			commonS.tip("请填写正确的验证码！");
			return false;
		}
		if(!commonM.checkPassword(password) || !commonM.checkPassword(passwordAgain)) {
			if(!password || !passwordAgain) {
				commonS.tip("请填写密码");
				return false;
			} else {
				commonS.tip("密码必须是6-12位数字或字母");
				return false;
			}
		}
		if(password != passwordAgain) {
			commonS.tip("两次密码不一致");
			return false;
		}
    commonS.loadingToggle(true);
		commonM.ajax({
			url: "/h5_api.php?act=reset_pwd",
	 		type: "post",
	 		dataType: "text",
	 		data: {
	 			mobile: encodeURIComponent(encrypt.encrypt(account)),
	 			verifycode: encodeURIComponent(encrypt.encrypt(verifycode)),
	 			password: encodeURIComponent(encrypt.encrypt(password)),
	 			passwordAgain: encodeURIComponent(encrypt.encrypt(passwordAgain))
	 		},
	 		success: function(res) {
        commonS.loadingToggle(false);
	 			if(res.result == 1) {
	 				window.location.reload();
	 				
	 			} else {
	 				commonS.tip(res.desc);
	 			}
	 		},
      error: function(res2) {
          commonS.loadingToggle(false);
          commonS.tip("请求出错："+res2.status+","+res2.statusText);
      }
		})
	},
	logOut: function() {
		commonS.loadingToggle(true);
		commonM.ajax({
			url: "/h5_api.php?act=log_out",
	 		type: "post",
	 		dataType: "text",
	 		success: function(res) {
        commonS.loadingToggle(false);
	 			if(res.result == 1) {
	 				window.location.reload();
	 				
	 			} else {
	 				commonS.tip(res.desc);
	 			}
	 		},
      error: function(res2) {
          commonS.loadingToggle(false);
          commonS.tip("请求出错："+res2.status+","+res2.statusText);
      }
		})
	},
	init: function() {
		var c = this;
		var b = commonM.browserRel();
		var t = (new Date()).getTime();
		commonC.uaObj = {
			system: b.os || "",
      deviceType: b.deviceType || "",
      osVer: b.osVersion || "",
			browser: b.browser || "",
			broswerVer: b.browserVersion || "",
      lang: b.language || "",
			sdkVer: "1.0.0.2",
      token: $("#token").val(),
      channel: $("#channel").val(),
      userId: $("#userId").val(),
      userName: $("#userName").val(),
      appId: $("#appId").val(),
			timestamp: t,
			safety: md5($("#appId").val()+$("#channel").val()+t+$("#token").val()),
			family: $("#family").val(),
			cpext: $("#cpext").val()
		};
		commonC.infoObj = {
			mobile: $("#mobile").val(),
			registerTime: $("#registerTime").val(),
			userId: $("#userId").val(),
			userName: $("#userName").val(),
			wxIconUrl: $("#img").val(),
      sex: $("#sex").val(),
      browserRel: b
		};
		c.event();
		c.infoS();
		c.showNotice();
		commonM.loadScript("//cdn.66173.cn/mobile/v2/scripts/qrcode.min.js", "qrcodeJs");
    setTimeout(function () {
        commonM.ajax({
            url: "h5_api.php?act=device",
            type: "post",
            dataType: "text",
            error: function(res2) {

            }
        });
        commonM.ajax({
            url: "h5_api.php?act=login",
            type: "post",
            dataType: "text",
            error: function(res2) {
            	
            }
        });
    }, 500);
    var r = 3;
    beforeGameInterval = setInterval(function() {
    	if(r > 1) {
    		r--;
    		$(".before-mask .time").html(r);
			} else {
    		$(".before-mask").hide();
    		clearInterval(beforeGameInterval);
			}
		}, 1000)
	}
};
nn.init();