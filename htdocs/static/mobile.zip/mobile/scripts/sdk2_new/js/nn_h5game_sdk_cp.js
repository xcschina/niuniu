var wrapObj = {
	va: {
		payData: {},
		qrcode: null,
		qrcode2: null,
		odInterval: null
	},
	init: function() {
		var c = this;
		window.addEventListener("message", function(e) {
			var data = e.data || {};
		    var info = data.info;
		    switch (data.action) {
		        case 'cp_pay': 
		        	c.pay(info);
		          break;
		       	case 'cp_roleReport':
		       		c.roleReport(info);
		       		break;
            case 'cp_ready':
              c.duSet();
              break;
            case 'cp_rinfo':
              c.getRinfo();
              break;
            case 'cp_callBind':
          		c.callBind();
            	break;
            case 'cp_logOut':
          		window.nn && nn.logOut();
            	break;
            case 'cp_paramsInfo':
          		c.getParamsInfo();
            	break;
		        default : 
		          return
		    }
		}, false);
	},
	pay: function(data,callback){
		var c  =this;
		var b = commonC.infoObj.browserRel || {};
		var isPC = b.device == "PC" ? 1 : 2;
		var isWX = b.browser == "Wechat" ? 1 : 2;
		if(!commonM.isPureObject(data)) {
			commonS.tip("支付信息格式不对！");
			return false;
		}
	 	data.way = "2";
    data.userName = commonC.uaObj.userName;
	 	data.channel = commonC.uaObj.channel;
	 	data.isPC = isPC;
	 	data.isWX = isWX;
	 	data.pageUrl = window.location.href;
	 	c.va.payData = data;
	 	
	 	if(isWX == 1) {
	 		// commonS.popTip("微信内支付功能开发中,请使用其他浏览器打开页面进行支付");
	 		// return false;

	 		var dataClone = $.extend({},data);
		 	for(i in dataClone) {
	      dataClone[i] = encodeURIComponent(encrypt.encrypt(String(dataClone[i])));
	    }
	 		commonM.log("支付信息", data);
	 		commonS.loadingToggle(true);
		 	commonM.ajax({
		 		url: "wx_h5_pay.php",
		 		type: "post",
		 		dataType: "text",
		 		data: dataClone,
		 		success: function(res) {
	       	commonS.loadingToggle(false);
		 			commonM.log("支付返回:", res);
			 		var data = res.data || {};
			 		if(res.result == 1) {
			 			window.WeixinJSBridge && WeixinJSBridge.invoke(
	            'getBrandWCPayRequest',{
	                "appId":data.wxAppId,//微信公众号appId，由现在支付返回(在tn中)
	                "timeStamp":String(data.timeStamp),//时间戳，自1970年以来的秒数
	                "nonceStr":data.nonceStr,//随机串
	                "package":"prepay_id="+data.prepay_id,
	                "signType":data.signType,//微信签名方式:
	                "paySign":data.paySign//微信签名
	            }, function(res2) {
	            	//使用以上方式判断前端返回,微信团队郑重提示:res.err_msg将在用户支付成功后返回ok，但并不保证它绝对可靠。
	            	if(res2.err_msg == "get_brand_wcpay_request:ok"){
	            		commonS.tip("充值成功");
	            	}
	            })
				  }
				  else {
	          commonS.popTip(res.desc);
					}
		 		}
		 	});
	 	} else {
	 		// commonS.popTip("支付功能开发中，请通过微信打开，体验更全功能");
	 		commonS.popControl(".pop-pay-rel",".pop-pay","选择支付方式",false);
	 		$(".pay-way-choose .item:first-child").click();
	 	}
    
	} ,
	wayPay: function(wayName) {
		var c = this;
		var data0 = c.va.payData;
		data0.way = wayName == "alipay" ? 1 : 2;
		var dataClone = $.extend({},data0);
		for(i in dataClone) {
      dataClone[i] = encodeURIComponent(encrypt.encrypt(String(dataClone[i])));
    }
		commonM.log("支付信息", data0);
 		commonS.loadingToggle(true);
	 	commonM.ajax({
	 		url: "h5_pay.php",
	 		type: "post",
	 		dataType: "text",
	 		data: dataClone,
	 		success: function(res) {
	 			// isScan 1 扫码 2 跳链接地址
	 			// res = {
	 			// 	result: 1,
	 			// 	isScan: 1,
	 			// 	link: "http://www.baidu.com",
	 			//  	id: 123
	 			// }
       	commonS.loadingToggle(false);
	 			commonM.log("支付返回:", res);
		 		var data = res.data || {};
		 		if(res.result == 1) {
		 			var isScan = res.isScan;
		 			var link = res.link;
		 			var id = res.id;
	 				// 支付宝支付
	 				if(data0.way == 1) {
	 					if(isScan == 1) {
		 					if($("#qrcode2").length > 0) {
	              if(!c.va.qrcode2) {
	                  c.va.qrcode2 = window.QRCode && new QRCode(document.getElementById("qrcode2"), {
	                      width: 140,
	                      height: 140,
	                      correctLevel: QRCode.CorrectLevel.L
	                  });
	              }
	              c.va.qrcode2 && c.va.qrcode2.makeCode(link);
	              commonS.popControl(".pop-pay-rel",".pop-alipay-scan","支付宝支付",false);
	              // c.queryOd(id);
	            }
	          } 
	          else {
	          	link && (window.location.href = link);
	          }
	 				} 
	 				else {
	 					// 微信支付
	 					if(isScan == 1) {
		 					if($("#qrcode").length > 0) {
	              if(!c.va.qrcode) {
	                  c.va.qrcode = window.QRCode && new QRCode(document.getElementById("qrcode"), {
	                      width: 140,
	                      height: 140,
	                      correctLevel: QRCode.CorrectLevel.L
	                  });
	              }
	              c.va.qrcode && c.va.qrcode.makeCode(link);
	              commonS.popControl(".pop-pay-rel",".pop-wxpay-scan","微信支付",false);
	              // c.queryOd(id);
	            }
	          }
	          else {
	          	link && (window.location.href = link);
	          }
	 				}
			  } 
			  else {
          commonS.popTip(res.desc);
				}
	 		}
	 	});
	 
	},
	queryOd: function(id) {
		var c = this;
		var count = 10;
		c.stopOd();
		c.va.odInterval = setInterval(function() {
			count--;
			if(count < 0) {
				c.stopOd();
				return false;
			}
			console.log(count);
			commonM.ajax({
		 		url: "",
		 		type: "post",
		 		dataType: "text",
		 		data: {
		 			id: encodeURIComponent(encrypt.encrypt(String(id)))
		 		},
		 		success: function(res) {
		 			// res = {
		 			// 	result: 1
                     //
		 			// }
		 			var code = res.result;
		 			if(code == 1) {
		 				console.log("ok");
		 				commonS.tip("支付成功");
		 				$(".mask").hide();
		 				c.stopOd();
		 			} else if(code == 2) {
		 				c.stopOd();
		 			}
		 		}
		 	});
		}, 1000)
	},
	stopOd: function() {
		clearInterval(this.va.odInterval);
	},
	//角色信息报道
	roleReport: function(data){
	 	commonM.setUaObj({
	 		roleName: data.roleName,
	 		roleId: data.roleId,
	 		roleLevel: data.roleLevel,
	 		serverId: data.serverId,
	 		serverName: data.serverName
	 	});
	 	// todo post data
	 	commonM.ajax({
	 		url: "h5_api.php?act=role",
	 		type: "post",
	 		dataType: "text"
	 	});
	},
	duSet: function() {
		if(_du == false) {
			var a = document.getElementById("gameFrame");
			a && a.contentWindow.postMessage({
				action: "cp_cb_du",
				info: false
			}, "*")
		}
  },
  getRinfo: function() {
  	var i = commonC.infoObj;
  	var a = document.getElementById("gameFrame");
		a && a.contentWindow.postMessage({
			action: "cp_cb_rinfo",
			info: {
				"uinfo": {
					"wxIconUrl": i.wxIconUrl || "",
					"userName": i.userName || "",
					"sex": i.sex || "",
					"isMBind": i.mobile ? true : false
				}
			}
		}, "*")
  },
  callBind: function() {
		$(".not-bind .step1").hide().siblings().show();
  	commonS.popControl(".pop-user-rel",".not-bind","手机号绑定",true);
  },
  getParamsInfo: function() {
  	var i = commonC.uaObj;
  	var a = document.getElementById("gameFrame");
		a && a.contentWindow.postMessage({
			action: "cp_cb_paramsInfo",
			info: {
					"appId": i.appId || "",
					"channel": i.channel || "",
					"userId": i.userId || "",
					"token": i.token || "",
					"family": i.family || "",
					"cpext": i.cpext || ""
			}
		}, "*")
  }
};
wrapObj.init();