/**
 * Created by zcl on 15/5/27.
 */
$(function(){
    //游戏列表
    $("#more").bind("click",function(){
        if( $("#more").attr("id")==null){
            return ;
        }

        $.ajax({
            type:'get',
            url:'my.php?act=my_msgs',
            data:{
                page:parseInt($("#page").val())+1,
                is_read:$("is_read").val()
            },
            dataType: 'json',
            beforeSend:function(){
            },
            success: function (json) {
                var content = "";
                $(json).each(function(){
                    content+="<li><a href='my.php?act=msg_detail&id="+this.id+"'>"+this.title+"</a><em>"+this.add_time+"</em></li>";
                })
                if(content==""){
                    $("#more").html("没有更多了");
                    $("#more").attr("id","");
                }else{
                    $("#content_befor").before(content);
                    $("#page").val(parseInt($("#page").val())+1);
                }
                if($(json).length<10){
                    $("#more").html("没有更多了");
                    $("#more").attr("id","");
                }
            },
            error:function(){
                $("#more").html("加载失败");
            }
        });
    })
});