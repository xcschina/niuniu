var wrapObj = {
	init: function() {
		var c = this;
		window.addEventListener("message", function(e) {
			var data = e.data || {};
		    var info = data.info;
		    switch (data.action) {
		        case 'cp_pay': 
		        	c.pay(info);
		          break;
		       	case 'cp_roleReport':
		       		c.roleReport(info);
		       		break;
            case 'cp_ready':
              c.duSet();
              break;
            case 'cp_rinfo':
              c.getRinfo();
              break;
            case 'cp_callBind':
            	c.callBind();
            	break;
		        default : 
		          return
		    }
		}, false);
	},
	pay: function(data,callback){
		if(!commonM.isPureObject(data)) {
			commonS.tip("支付信息格式不对！");
			return false;
		}
	 	data.way = "2";
        data.userName = commonC.uaObj.userName;
	 	data.channel = commonC.uaObj.channel;
	 	commonM.log("支付信息", data);
	 	for(i in data) {
	 		data[i] = typeof data[i] == "string" ? data[i] : JSON.stringify(data[i]);
	 		data[i] = encodeURIComponent(encrypt.encrypt(data[i]));
	 	}
    commonS.loadingToggle(true);
	 	commonM.ajax({
	 		url: "wx_h5_pay.php",
	 		type: "post",
	 		dataType: "text",
	 		data: data,
	 		success: function(res) {
        commonS.loadingToggle(false);
	 			commonM.log("支付返回:", res);
		 		var data = res.data || {};
		 		if(res.result == 1) {
		 			window.WeixinJSBridge && WeixinJSBridge.invoke(
			            'getBrandWCPayRequest',{
			                "appId":data.wxAppId,//微信公众号appId，由现在支付返回(在tn中)
			                "timeStamp":data.timeStamp,//时间戳，自1970年以来的秒数
			                "nonceStr":data.nonceStr,//随机串
			                "package":"prepay_id="+data.prepay_id,
			                "signType":data.signType,//微信签名方式:
			                "paySign":data.paySign//微信签名
			            }, function(res2) {
			            	//使用以上方式判断前端返回,微信团队郑重提示:res.err_msg将在用户支付成功后返回ok，但并不保证它绝对可靠。
			            	if(res2.err_msg == "get_brand_wcpay_request:ok"){
			            		briefTipControl("充值成功");
			            	}
			            })
			    } else {
                    commonS.popTip(res.desc);
				}
	 		},
			error: function(res2) {
                commonS.loadingToggle(false);
                commonS.tip("请求出错："+res2.status+","+res2.statusText);
            }
	 	});
 		// document.getElementById("gameFrame").contentWindow.postMessage({action: "cp_pay_cb",info: res}, "*");
	} ,
	 //角色信息报道
	roleReport: function(data){
	 	commonM.setUaObj({
	 		roleName: data.roleName,
	 		roleId: data.roleId,
	 		roleLevel: data.roleLevel,
	 		serverId: data.serverId,
	 		serverName: data.serverName
	 	});
	 	// todo post data
	 	commonM.ajax({
	 		url: "h5_api.php?act=role",
	 		type: "post",
	 		dataType: "text"
	 	});
	},
	duSet: function() {
		if(_du == false) {
			var a = document.getElementById("gameFrame");
			a && a.contentWindow.postMessage({
				action: "cp_cb_du",
				info: false
			}, "*")
		}
    },
    getRinfo: function() {
    	var i = commonC.infoObj;
    	var a = document.getElementById("gameFrame");
			a && a.contentWindow.postMessage({
				action: "cp_cb_rinfo",
				info: {
					"uinfo": {
						"wxIconUrl": i.wxIconUrl || "",
						"userName": i.userName || "",
						"sex": i.sex || "",
						"isMBind": i.mobile ? true : false
					}
				}
			}, "*")
    },
    callBind: function() {
    	$(".not-bind .step1").hide().siblings().show();
    	$(".not-bind").show().siblings().hide();
    	$(".mask").show();
    }
};
wrapObj.init();