// 悬浮球拖动处理
(function() {
	var flag, hasMoved;
	var curCoor = {
		x: 0,
		y: 0
	};
	var moveX, moveY, offX, offY;
	var touchZone = document.getElementById("touchZone");
    var viewWidth,viewHeight,touchWidth,touchHeight;
	function down(e) {
		flag = true;
		var touch;
		if(e.touches) {
			touch = e.touches[0];
		} else {
			touch = e;
		}
		curCoor.x = touch.clientX;
		curCoor.y = touch.clientY;
		offX = touchZone.offsetLeft;
		offY = touchZone.offsetTop;
        viewWidth = docElVW || document.documentElement.offsetWidth;
        viewHeight = docElVH || document.documentElement.offsetHeight;
        touchWidth = touchZone.width || 50;
        touchHeight = touchZone.height || 50;
	}
	function move(e) {
		if(flag) {
            hasMoved = true;
			var touch, x, y;
			if(e.touches) {
				touch = e.touches[0];
			} else {
				touch = e;
			}
			moveX = touch.clientX - curCoor.x;
			moveY = touch.clientY - curCoor.y;
			x = moveX + offX;
			y = moveY + offY;
			// console.log("moveX:"+moveX+",moveY:"+moveY);
			// 超越右边界
			if(x + touchWidth > viewWidth) {
				x = viewWidth - touchWidth;
			}
			// 超越下边界
			if((y + touchHeight) > viewHeight) {
				y = viewHeight - touchHeight;
			}
			// 超越左边界
			if(x < 0) {
				x = 0;
			}
			// 超越上边界
			if(y < 0) {
				y = 0;
			}
			touchZone.style.left = x + 'px';
			touchZone.style.top = y + 'px';
		}
	}
	function up(e) {
	    var cx = parseInt(touchZone.style.left);
	    if(hasMoved) {
	    	// commonM.log("float ball touchmove end","(viewWidth - touchWidth) / 2:"+((viewWidth - touchWidth) / 2)+",cx"+cx+"viewWidth - touchWidth"+(viewWidth - touchWidth));
            // touchZone.style.left = cx > (viewWidth - touchWidth) / 2 ? ((viewWidth - touchWidth) + 'px') : (0 + 'px');
            touchZone.style.left = (viewWidth - touchWidth) + 'px';
        }
        // commonM.log("float ball touchmove","viewWidth:"+viewWidth+",screen:"+window.screen.width+",viewWidth - touchWidth:"+(viewWidth - touchWidth)+",touchWidth:"+touchWidth);
		flag = false;
	}
	touchZone.addEventListener("touchstart", function(e) {
		down(e);
	}, false);
	touchZone.addEventListener("touchmove", function(e) {
		e.preventDefault();
		move(e);
	}, false);
	touchZone.addEventListener("touchend", function(e) {
		up(e);
	});
    // document.body.addEventListener("touchmove", function(e) {
		// // if(e.target.id != "touchZone") {
    //         e.preventDefault();
    //         e.stopPropagation();
		// // }
    // });

})();

var goBindTimeout; //弹窗中绑定定时
var captchaInterval;//弹窗中验证倒计时
var beforeGameInterval;
var nn = {
	va: {
		rePhone: "",
		reCapt: ""
	},
	event: function() {
		var c = this;
		$("body").on("click", ".before-mask", function() {
      $(".before-mask").hide();
			clearInterval(beforeGameInterval);
		});
		$("body").on("click", "#touchZone", function() {
			$(".not-bind .step2").hide().siblings().show();
			if(commonC.infoObj.mobile) {
				commonS.popControl(".pop-user-rel",".already-bind","我的信息",false);
			} else {
				commonS.popControl(".pop-user-rel",".not-bind","我的信息",false);
			}
			$(".mask").show();
		});
		$("body").on("click", ".mask .close-pop, .common-pop-tip-zone .btn-zone", function() {
			$(".mask").hide();
		});
		// 关闭公告弹窗
		$("body").on("click", ".notice-mask .close-pop", function() {
			$(".notice-mask").hide();
		})
		$("body").on("click", ".not-bind .back-pop", function() {
			$(".pop-user-rel .pop-title").html("我的信息");
			$(".not-bind .step2").hide().siblings().show();
		});
		$("body").on("click", ".not-bind .to-bind", function() {
			$(".tel-input").val("");
			$(".captcha-input").val("");
			$(".pop-user-rel .pop-title").html("手机号绑定");
			$(".not-bind .step1").hide().siblings().show();
		});
		$("body").on("click", ".to-get-captcha", function(e) {
			c.getCaptcha(e);
		});
		// 绑定手机
		$("body").on("click", ".go-bind-can", function(e) {
			c.bindPhone(e);
		});
	},
	getCaptcha: function(e) {
		var c = this;
		var type = $(e.currentTarget).data("type");
		console.log("type:"+type)
		var account = $(".tel-input:visible").val().trim();
		if(!commonM.checkPhone(account)) {
  		commonS.tip("请填写正确的手机号码！");
  		$(".captcha-tip").removeClass("to-get-captcha");
  		setTimeout(function() {
  			$(".captcha-tip").addClass("to-get-captcha");
  		}, 2000);
  		return false;
  	}
  	$(".captcha-tip").removeClass("to-get-captcha").html('<span class="count-time">120</span>s后获取');
  	var countDownRest = 120;
  	clearInterval(captchaInterval);
  	captchaInterval = setInterval(function() {
  		if(countDownRest > 1) {
  			countDownRest--;
  			$(".count-time").html(countDownRest)
  		}
  		else {
  			$(".captcha-tip").html("获取验证码").addClass("to-get-captcha");
  			clearInterval(captchaInterval)
  		}

  	}, 1000);
  	if(type == "wish_bind_not") {
      commonM.ajax({
        url: "/h5_api.php?act=check",
        type: "post",
        dataType: "text",
        data: {
        	mobile: encodeURIComponent(encrypt.encrypt(account))
        },
        success: function(res) {
          var code = res.result;
          var data = res.data || {};
        	commonS.tip(res.desc);
        	if(code == 2) {
        		countDownRest = 5;
        	} else if(code == 3) {
              commonC.infoObj.mobile = data.mobile;
              $("#mobile").val(data.mobile);
              c.infoS();
          }
      	}
      })
    } else if(type == "wish_reg_not") {
    	commonM.ajax({
        url: "/h5_api.php?act=reg_code",
        type: "post",
        dataType: "text",
        data: {
        	mobile: encodeURIComponent(encrypt.encrypt(account))
        },
        success: function(res) {
          var code = res.result;
          var data = res.data || {};
        	commonS.tip(res.desc);
        	if(code == 2) {
        		countDownRest = 5;
        	}
      	}
      })
    } else if(type == "wish_reg_yes") {
    	commonM.ajax({
        url: "/h5_api.php?act=check_code",
        type: "post",
        dataType: "text",
        data: {
        	mobile: encodeURIComponent(encrypt.encrypt(account))
        },
        success: function(res) {
          var code = res.result;
          var data = res.data || {};
        	commonS.tip(res.desc);
        	if(code == 2) {
        		countDownRest = 5;
        	}
      	}
      })
    }
	},
	showNotice: function() {
		if($("#hasNotice").val() == "1" && $("#noticeCon").val()) {
			$(".pop-notice-main").html(commonM.unescapeHTML($("#noticeCon").val()));
			$(".notice-mask").show();
		}
	},
	infoS: function() {
		var c = this;
		var data = commonC.infoObj;
		var isPC = data.browserRel.device == 'PC' ? true : false;
		var isWX = data.browserRel.browser == 'Wechat' ? true : false;
		c.showNotice();
		if(data.mobile) {
			$(".already-bind .phone").html(data.mobile);
			$(".already-bind").show().siblings().hide();
		} else {
			$(".not-bind").show().siblings().hide();
		}
		$(".bind-info-rel .register-time").html(data.registerTime);
		$(".already-bind .user-id").html(data.userName);
		$(".not-bind .user-id").html(data.userName);
		if(!isWX) {
			$(".log-out").show();
		}
		if(!data.userId) {
			$("#touchZone").hide();
		} 
	},
	// 绑定手机
	bindPhone: function(e) {
		var c = this;
		var account = $(".not-bind .tel-input:visible").val().trim();
		var verifycode = $(".not-bind .captcha-input:visible").val().trim();
		var password = $(".not-bind .password-input:visible").val().trim();
		var passwordAgain = $(".not-bind .password-input-again:visible").val().trim();
		$(".go-bind").removeClass("go-bind-can");
		setTimeout(function() {
			$(".go-bind").addClass("go-bind-can");
		}, 3000);
		if(!commonM.checkPhone(account)) {
			commonS.tip("请填写正确的手机号码！");
			return false;
		}
		if(!commonM.checkCaptcha(verifycode)) {
			commonS.tip("请填写正确的验证码！");
			return false;
		}
		if(!commonM.checkPassword(password) || !commonM.checkPassword(passwordAgain)) {
			if(!password || !passwordAgain) {
				commonS.tip("请填写密码");
				return false;
			} else {
				commonS.tip("密码必须是6-12位数字或字母");
				return false;
			}
		}
		if(password != passwordAgain) {
			commonS.tip("两次密码不一致");
			return false;
		}
    commonS.loadingToggle(true);
		commonM.ajax({
			url: "/h5_api.php?act=bind",
	 		type: "post",
	 		dataType: "text",
	 		data: {
	 			mobile: encodeURIComponent(encrypt.encrypt(account)),
	 			verifycode: encodeURIComponent(encrypt.encrypt(verifycode)),
	 			password: encodeURIComponent(encrypt.encrypt(password)),
	 			passwordAgain: encodeURIComponent(encrypt.encrypt(passwordAgain))
	 		},
	 		success: function(res) {
        commonS.loadingToggle(false);
	 			if(res.result == 1) {
	 				commonS.tip(res.desc);
	 				commonC.infoObj.mobile = res.data && res.data.mobile;
	 				$("#mobile").val(res.data && res.data.mobile);
	 				$(".mask").hide();
	 				c.infoS();
	 				var a = document.getElementById("gameFrame");
					a && a.contentWindow.postMessage({
						action: "cp_cb_mBind",
						info: {
							"uinfo": {
								"isMBind": true
							}
						}
					}, "*")
	 				
	 			} else {
	 				commonS.tip(res.desc);
	 			}
	 		},
      error: function(res2) {
          commonS.loadingToggle(false);
          commonS.tip("请求出错："+res2.status+","+res2.statusText);
      }
		})
	},
	init: function() {
		var c = this;
		var b = commonM.browserRel();
		var t = (new Date()).getTime();
		commonC.uaObj = {
			system: b.os || "",
      deviceType: b.deviceType || "",
      osVer: b.osVersion || "",
			browser: b.browser || "",
			broswerVer: b.browserVersion || "",
      lang: b.language || "",
			sdkVer: "1.0.0.2",
      token: $("#token").val(),
      channel: $("#channel").val(),
      userId: $("#userId").val(),
      userName: $("#userName").val(),
      appId: $("#appId").val(),
			timestamp: t,
			safety: md5($("#appId").val()+$("#channel").val()+t+$("#token").val())
		};
		commonC.infoObj = {
			mobile: $("#mobile").val(),
			registerTime: $("#registerTime").val(),
			userId: $("#userId").val(),
			userName: $("#userName").val(),
			wxIconUrl: $("#img").val(),
      sex: $("#sex").val(),
      browserRel: b
		};
		c.event();
		c.infoS();
    setTimeout(function () {
        commonM.ajax({
            url: "h5_api.php?act=device",
            type: "post",
            dataType: "text",
            error: function(res2) {

            }
        });
        commonM.ajax({
            url: "h5_api.php?act=login",
            type: "post",
            dataType: "text",
            error: function(res2) {
            	
            }
        });
    }, 500);
    var r = 3;
    beforeGameInterval = setInterval(function() {
    	if(r > 1) {
    		r--;
    		$(".before-mask .time").html(r);
			} else {
    		$(".before-mask").hide();
    		clearInterval(beforeGameInterval);
			}
		}, 1000)
	}
};
nn.init();