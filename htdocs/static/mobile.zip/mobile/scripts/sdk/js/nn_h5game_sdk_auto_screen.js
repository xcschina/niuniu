"use strict";

function recalc() {
    var tZone = document.getElementById("touchZone");
    dpr = Math.round(window.devicePixelRatio || 1), browser.versions.mobile ? clientW = docEl.getBoundingClientRect().width : (clientW = 480, docEl.style.width = "480px"), docEl.setAttribute("data-dpr", dpr);
    if(clientW > 500){docEl.style.fontSize = '50px';} else {docEl.style.fontSize =clientW / 10 + "px";}
    docElVW = docEl.offsetWidth, docElVH = docEl.offsetHeight, docElVW && tZone && (tZone.style.left = docElVW-(tZone.innerWidth||50) + "px"), tZone && (tZone.style.top = "35%");
}
var browser = {
        versions: function() {
            var e = navigator.userAgent;
            navigator.appVersion;
            return {
                mobile: !!e.match(/AppleWebKit.*Mobile.*/)
            }
        }(),
        language: (navigator.browserLanguage || navigator.language).toLowerCase()
    },
    doc = window.document, docEl = doc.documentElement, docElVW, docElVH,
    resizeEvt = "orientationchange" in window ? "orientationchange" : "resize",
    dpr = 1, scale = 1, clientW = 0;
doc.addEventListener && (window.addEventListener(resizeEvt, recalc, !1), doc.addEventListener("DOMContentLoaded", recalc, !1));