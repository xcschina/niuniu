//下拉分页
$(document).ready(function() {
    $("#more").bind("click", function () {
        if ($("#more").attr("id") == null) {
            return;
        }
        $.ajax({
            type: 'get',
            url: 'my.php?act=my_gifts',
            data: {
                page: parseInt($("#page").val()) + 1,
                game_id: $("select[name=game_id] option:selected").val()
            },
            dataType: 'json',
            beforeSend: function () {
            },
            success: function (json) {
                var content = "";
                $(json).each(function () {
                    content += " <li>";
                    content += "<span class='md-name'>";
                    content += "<i class='md-state-2'></i>";
                    content += this.code;;
                    content += "</span>";
                    content += "<em class='md-price'>￥" + this.price + "</em>";
                    content += "<span class='md-service'>"+ this.game_name + "</span>";
                    content += "</li>";
                })
                if (content == "") {
                    $("#more").html("没有更多了");
                    $("#more").attr("id", "");
                } else {
                    $("#content_befor").before(content);
                    $("#page").val(parseInt($("#page").val()) + 1);
                }
                if ($(json).length < 10) {
                    $("#more").html("没有更多了");
                    $("#more").attr("id", "");
                }
            },
            error: function () {
                $("#more").html("加载失败");
            }
        });
    })
})
