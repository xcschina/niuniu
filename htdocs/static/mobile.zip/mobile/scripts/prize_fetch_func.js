// 弹窗控制
function popControl(popParentClass, popClass, popTitle) {
    $(popParentClass).show().siblings().hide();
    $(popClass).show().siblings().hide();
    $(".pop-bg .pop-title").html(popTitle);
    $(".prize-fetch .mask").show();
    popSize();
    // alert("mask"+$(".mask").height()+"pop-bg top"+$(".pop-bg-small").offset().top + "pop-small-height"+$(".pop-bg-small").height()+"window.screen.availHeight"+window.screen.availHeight+"screen height"+window.screen.height);
}
// 简单提示控制
function briefTipControl(text) {
    $(".brief-tip-pop .con").html(text);
    $(".brief-tip-pop").fadeIn(500).delay(1000).fadeOut(500);
}
// 按钮定时加class控制
function btnTimeOutControl(ele, cls, timeoutClient, timeout) {
    clearTimeout(timeoutClient);
    timeoutClient = setTimeout(function() {
        $(ele).addClass(cls);
    }, timeout || 2000);
}
// 表单校验
function checkInput(data) {
    var checkRes = {
        res: {},
        pass: true
    }
    for(var key in data) {
        if($(key+':visible').length > 0) {
            var val = $(key+':visible').val().trim();
            if(key == ".tel-input" && !regContact.test(val)) {
                briefTipControl("请填写正确的手机号");
                checkRes.pass = false;
                return checkRes;
            }
            if(key == ".captcha-input" && !regCaptchaPart.test(val)) {
                briefTipControl("请填写正确的验证码");
                checkRes.pass = false;
                return checkRes;
            }
            // if(key == ".invite-code-input" && val && !regInvite.test(val)) {
            //     briefTipControl("请填写正确的邀请码或不填");
            //     checkRes.pass = false;
            //     return checkRes;
            // }
            checkRes["res"][data[key]] = val;
        }
    }
    return checkRes;
}
// 页面UI控制
function popSize() {
    // 大弹窗高度
    $(".pop-bg-large").css("height", $(".pop-bg-large").width()*0.874);
    // 小弹窗高度
    $(".pop-bg-small").css("height", $(".pop-bg-small").width()*0.756);
    // document.body.clientHeight
    var minH = Math.min($(".mask").height(),window.screen.availHeight,window.screen.height);
    $(".pop-bg").css("top", (minH-$(".pop-bg:visible").height())/2 + 'px');
    // $(".pop-bg").css("top", ($(".mask").height()-$(".pop-bg:visible").height())/2 + 'px');
    // 关闭弹窗按钮高度
    var closeWidth = $(".pop-bg .close-pop:visible").width();
    $(".pop-bg .close-pop").css("height", closeWidth);
    // 弹窗标题高度和行高与关闭弹窗按钮相同
    $(".pop-bg .pop-title").css({
        "height": closeWidth,
        "line-height": closeWidth + 'px'
    });
}
function pageBgSize() {
    popSize();
}
function initHTMLSize() {
    var wWidth = document.documentElement.clientWidth || document.body.clientWidth;
    var size = wWidth / 7.5;
    document.getElementsByTagName('html')[0].style.fontSize = (size > 55 ? 55 : size) + 'px';
}
$(document).ready(function () {
    initHTMLSize();
    pageBgSize();
});
$(window).resize(function() {
    // initHTMLSize();
    // resize这里要先pageBgSize()再initHTMLSize()才不至于有的动态设置高宽不执行
    pageBgSize();
    initHTMLSize();
});
