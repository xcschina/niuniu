/**
 * Created by ong on 15/5/20.
 */
$(function(){
    //游戏列表
    $("ul.label-list a").click(function(){character_game_tab(this);});
});
function character_game_tab(obj){
    rel = $(obj).attr("rel");
    if(rel=="hot"){
        $("ul.soft-list2").hide();
        $("ul.soft-list").show();
    }else{
        $("ul.soft-list").hide();

        games = $.ajax({url:"?act=allgames&letter="+rel,async:false});
        games= jQuery.parseJSON(games.responseText);//转换为json对象
        $("ul.soft-list2").html("");
        html_str ='';
        $.each(games,function(idx,item){
            if(item.first_letter == rel){
                html_str+='<li><a href="/game'+item.id+'"><img src="http://cdn.66173.cn/'+item.game_icon+'" /><span>'+item.game_name+'</span><em>'+item.discount+'</em></a></li>';
            }
        });
        $("ul.soft-list2").html(html_str).show();
    }
    $("ul.label-list a").parent("li").removeClass("on");
    $(obj).parent("li").addClass("on");
}