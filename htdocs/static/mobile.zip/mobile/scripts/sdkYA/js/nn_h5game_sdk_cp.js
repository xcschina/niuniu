var wrapObj = {
	init: function() {
		var c = this;
		window.addEventListener("message", function(e) {
			var data = e.data || {};
		    var info = data.info;
		    switch (data.action) {
                case 'cp_ready':
                    c.duSet();
                    break;
                case 'cp_rinfo':
                    c.getRinfo();
                    break;
                case 'cp_goToShare':
                    c.goToShare();
                    break;
                case 'cp_goToNNBPay':
                    c.goToNNBPay();
                    break;
		        default : 
		          return
		    }
		}, false);
	},
	duSet: function() {
		if(_du == false) {
			var a = document.getElementById("gameFrame");
			a && a.contentWindow.postMessage({
				action: "cp_cb_du",
				info: false
			}, "*")
		}
    },
    getRinfo: function() {
    	var i = commonC.infoObj;
    	var a = document.getElementById("gameFrame");
		a && a.contentWindow.postMessage({
			action: "cp_cb_rinfo",
			info: {
				"uinfo": {
					"wxIconUrl": i.wxIconUrl || "",
					"userName": i.userName || "",
					"sex": i.sex || ""
				}
			}
		}, "*")
    },
    // 调起分享
    goToShare: function(callback) {
        window.nn && nn.goToShare();
    },
    // 调起牛币支付
    goToNNBPay: function() {
        window.nn && nn.goToNNBPay();
    }
};
wrapObj.init();