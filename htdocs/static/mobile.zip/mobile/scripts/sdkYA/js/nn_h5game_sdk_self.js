// 悬浮球拖动处理
(function() {
    var flag, hasMoved;
    var curCoor = {
        x: 0,
        y: 0
    };
    var moveX, moveY, offX, offY;
    var touchZone = document.getElementById("touchZone");
    if(!touchZone) {
        return false;
    }
    var viewWidth,viewHeight,touchWidth,touchHeight;
    function down(e) {
        flag = true;
        var touch;
        if(e.touches) {
            touch = e.touches[0];
        } else {
            touch = e;
        }
        curCoor.x = touch.clientX;
        curCoor.y = touch.clientY;
        offX = touchZone.offsetLeft;
        offY = touchZone.offsetTop;
        viewWidth = docElVW || document.documentElement.offsetWidth;
        viewHeight = docElVH || document.documentElement.offsetHeight;
        touchWidth = touchZone.width || 50;
        touchHeight = touchZone.height || 50;
    }
    function move(e) {
        if(flag) {
            hasMoved = true;
            var touch, x, y;
            if(e.touches) {
                touch = e.touches[0];
            } else {
                touch = e;
            }
            moveX = touch.clientX - curCoor.x;
            moveY = touch.clientY - curCoor.y;
            x = moveX + offX;
            y = moveY + offY;
            // console.log("moveX:"+moveX+",moveY:"+moveY);
            // 超越右边界
            if(x + touchWidth > viewWidth) {
                x = viewWidth - touchWidth;
            }
            // 超越下边界
            if((y + touchHeight) > viewHeight) {
                y = viewHeight - touchHeight;
            }
            // 超越左边界
            if(x < 0) {
                x = 0;
            }
            // 超越上边界
            if(y < 0) {
                y = 0;
            }
            touchZone.style.left = x + 'px';
            touchZone.style.top = y + 'px';
        }
    }
    function up(e) {
        var cx = parseInt(touchZone.style.left);
        if(hasMoved) {
            // commonM.log("float ball touchmove end","(viewWidth - touchWidth) / 2:"+((viewWidth - touchWidth) / 2)+",cx"+cx+"viewWidth - touchWidth"+(viewWidth - touchWidth));
            // touchZone.style.left = cx > (viewWidth - touchWidth) / 2 ? ((viewWidth - touchWidth) + 'px') : (0 + 'px');
            touchZone.style.left = (viewWidth - touchWidth) + 'px';
        }
        // commonM.log("float ball touchmove","viewWidth:"+viewWidth+",screen:"+window.screen.width+",viewWidth - touchWidth:"+(viewWidth - touchWidth)+",touchWidth:"+touchWidth);
        flag = false;
    }
    touchZone.addEventListener("touchstart", function(e) {
        down(e);
    }, false);
    touchZone.addEventListener("touchmove", function(e) {
        e.preventDefault();
        move(e);
    }, false);
    touchZone.addEventListener("touchend", function(e) {
        up(e);
    });
    // document.body.addEventListener("touchmove", function(e) {
    // // if(e.target.id != "touchZone") {
    //         e.preventDefault();
    //         e.stopPropagation();
    // // }
    // });

})();

var captchaInterval;//弹窗中验证倒计时
var beforeGameInterval;
var nn = {
    va: {
        toBindMobile: "",
        toBindCaptcha: "",
        prizeRecordCurPage: 0,
        shareCb: function(code) {
            var a = document.getElementById("gameFrame");
            a && a.contentWindow.postMessage({
                action: "cp_cb_goToShare",
                info: {
                    "code": parseInt(code)
                }
            }, "*")
        }
    },
    goToBack: function () {
        if(window.local_obj) {
            try {
                window.local_obj.goto_back();
            } catch(e) {
                commonS.tip("调起返回失败~");
            }
        } else {
            commonS.tip("调起返回失败~");
        }
    },
    goToShare: function() {
        if(window.local_obj) {
            try {
                window.local_obj.goto_share($("title").val(), $("meta[name=description]").val(), commonC.infoObj.mAddress, $(".share-img").attr("src"));
            } catch(e) {
                commonS.tip("调起分享失败~");
            }
        } else {
            commonS.tip("调起分享失败~");
        }
    },
    goToNNBPay: function() {
        if(window.local_obj) {
            try {
                window.local_obj.goto_nnb_recharge();
            } catch(e) {
                commonS.tip("调起充值牛币页面失败~");
            }
        } else {
            commonS.tip("调起充值牛币页面失败~");
        }
    },
    event: function() {
        var c = this;
        $("body").on("click", ".before-mask", function() {
            $(".before-mask").hide();
            clearInterval(beforeGameInterval);
        });
        $("body").on("click", ".close-pop, .block-get-prize .back, .block-get-prize .go-game", function() {
            $(".mask").hide();
        });
        $("body").on("click", ".page-header .left", function() {
            if($(".like-page-wrapper:visible").length) {
                $(".like-page-wrapper").hide();
                $(".page-header .center").html(commonC.infoObj.initTitle);
                $(".page-header .share-m").show().siblings().hide();
            } else {
                c.goToBack();
            }
        });
        // 分享
        $("body").on("click", ".page-header .share-m", function() {
            c.goToShare();
        });
        // 每日登录中开启游戏
        $("body").on("click", ".block-everyday .go-game", function(e) {
        	e.preventDefault();
            $(".mask").hide();
            var $ele = $(e.target);
            var gameid = $ele.data("gameid");
            // 不同款游戏则重载页面
            if(gameid != commonC.uaObj.appId) {
            	window.location.href = commonM.setParameterByName("appId", gameid);
			} else {
                $(".mask").hide();
            }
        });
        // 抽奖相关
        $("body").on("click", ".btn-float-prize, .block-everyday .go-prize", function() {
            $(".mask").hide();
            commonS.likePageControl(".like-page-wrapper", ".prize-exchange-section");
            $(".page-header .center").html("奖品详情");
            $(".page-header .prize-record-entry").show().siblings().hide();
            c.getPrizeInit();
        });
        $("body").on("change", ".game-choose", function(e) {
        	var gameid = $(".game-choose option:selected").data("gameid");
        	c.getAccountAndPrizeList(gameid);
        });
        $("body").on("click", ".goods-list .item", function(e) {
            $(e.currentTarget).addClass("active").siblings().removeClass("active");
            c.updatePrizePart();
        });
        $("body").on("click", ".go-prize-can", function(e) {
        	var gameid = $(".game-choose option:selected").data("gameid");
            var serverid = $(".account-choose option:selected").data("serverid");
            var roleid = $(".account-choose option:selected").data("roleid");
            var rolename = $(".account-choose option:selected").data("rolename");
            var goodsid = $(".goods-list .active").data("goodsid");
            c.drawPrize(gameid, serverid, roleid, goodsid, rolename);
        });
        // 抽奖请求返回弹窗相关
		$("body").on("click", ".block-get-prize .back", function() {
			$(".mask").hide();
		});
        $("body").on("click", ".block-get-prize .go-game", function() {
            $(".mask").hide();
            $(".like-page-wrapper").hide();
            $(".page-header .center").html(commonC.infoObj.initTitle);
            $(".page-header .share-m").show().siblings().hide();
        });
        $("body").on("click", ".block-get-prize .back", function() {
            $(".mask").hide();
        });
        $("body").on("click", ".block-integral-lack .back", function() {
            $(".mask").hide();
		})
        $("body").on("click", ".block-integral-lack .go-charge", function() {
            $(".mask").hide();
            c.goToNNBPay();
        });
    	// 我的奖品相关
		$("body").on("click", ".prize-record-entry", function() {
            commonS.likePageControl(".like-page-wrapper", ".prize-record-section");
            $(".page-header .center").html("我的奖品");
            $(".page-header .item").hide();
			c.getPrizeRecordList(1);
		});
        // // 加载更多
        // $(window).on("scroll",function() {
        //     if($(".prize-record-section").is(':visible') && commonC.infoObj.screenHeight + document.documentElement.scrollTop >= document.body.scrollHeight) {
        //         c.getPrizeRecordList(c.va.prizeRecordCurPage + 1);
        //         console.log("screenHeight + document.documentElement.scrollTop:"+(commonC.infoObj.screenHeight + document.documentElement.scrollTop)+",scrollHeight:"+document.body.scrollHeight)
        //     }
        // })
        // 加载更多奖品
        $("body").on("click", ".prize-record-section .has-more-can", function() {
            c.getPrizeRecordList(c.va.prizeRecordCurPage + 1);
        });
    },
    // 抽奖
    drawPrize: function(gameid, serverid, roleid, goodsid, rolename) {
        var c = this;
        if(!gameid) {
        	commonS.tip("请选择游戏");
        	return false;
		}
		if(!serverid || !roleid) {
            commonS.tip("请选择充值账号");
            return false;
		}
        if(!goodsid) {
            commonS.tip("请选择面值");
            return false;
        }
		commonS.loadingToggle(true);
		commonM.ajax({
			url: "/play_ground.php?act=exchange",
			type: "post",
			dataType: "text",
			data: {
                app_id: gameid,
                server_id: serverid,
                role_id: roleid,
                goods_id: goodsid,
                role_name: rolename
			},
			success: function(res) {
				commonS.loadingToggle(false);
				var code = res.result;
				var integral = res.integral;
				c.updateIntegral(integral);
                c.updatePrizePart();
				if(code == 1) {
				    $(".block-get-prize .tip1").html(res.msg_title || "");
                    $(".block-get-prize .tip2").html(res.msg_con || "");
					commonS.popControl(".pop-stripe-red-fireworks", ".block-get-prize", "恭喜您，中奖了！");
				} else if(code == 2) {
					commonS.popControl(".pop-stripe-grey-small", ".block-integral-lack", "积分不足", true);
				} else {
					commonS.tip(res.desc);
				}
			}
			, error: function() {
				commonS.loadingToggle(false);
				commonS.tip("请求出错："+res2.status+","+res2.statusText);
			}
		})

    },
    // 进入抽奖页面初始化
    getPrizeInit: function() {
        var c = this;
        commonS.loadingToggle(true);
        commonM.ajax({
            url: "/play_ground.php?act=shop_list",
            type: "post",
            dataType: "text",
            success: function (res) {
                commonS.loadingToggle(false);
                var code = res.result;
                if (code == 1) {
                    var userInfo = res.user_info || {};
                    var gameList = res.appList || [];
                    var accountList = res.servers || [];
                    var prizeList = res.good_list || [];
                    var gameCon = "", accountCon = "", prizeCon = "";
                    // 游戏列表
                    if(gameList.length) {

                        for (var i = 0; i < gameList.length; i++) {
                            var item = gameList[i];
                            gameCon += '<option data-gameid="' + item.app_id +'"' + (item.app_id == res.app_id ? 'selected': '') +'>' + item.app_name + '</option>';
                        }
                        $(".prize-select-zone .game-line .yes").html(gameCon).show();
                        $(".prize-select-zone .game-line .no").html("").hide();
                    } else {
                        $(".prize-select-zone .game-line .yes").hide();
                        $(".prize-select-zone .game-line .no").html("暂无可抽奖游戏").show();
                    }
                    // 充值账号列表
                    if(accountList.length) {
                        for (var i = 0; i < accountList.length; i++) {
                            var item = accountList[i];
                            accountCon += '<option data-serverid="' + item.AreaServerID + '" data-roleid="' + item.RoleID + '" data-rolename= "'+ item.RoleName +'">' + item.AreaServerName + '-' + item.RoleName + '</option>';
                        }
                        $(".prize-select-zone .account-line .yes").html(accountCon).show();
                        $(".prize-select-zone .account-line .no").hide();
                        $(".go-prize").addClass("go-prize-can");
                    } else {
                        $(".prize-select-zone .account-line .yes").hide();
                        $(".prize-select-zone .account-line .no").html("未创建游戏区服").show();
                        $(".go-prize").removeClass("go-prize-can");
                    }
                    // 更新充值面值列表
                    if(prizeList.length) {
                        for (var i = 0; i < prizeList.length; i++) {
                            var item = prizeList[i];
                            prizeCon += '<div class="item" data-goodsid="' + item.id + '">'
                                + '<div class="goods-name">' + item.good_name + '</div>'
                                + '<div class="consume"><span class="num">' + item.consume + '</span>积分</div>'
                                + '</div>';
                        }
                        $(".goods-list").html(prizeCon);
                        $(".goods-list .item:first").addClass("active");

                    } else {
                        $(".goods-list").html("暂无可充值面值");
                    }
                    // 更新积分及按钮状态
                    c.updateIntegral(userInfo.integral);
                    c.updatePrizePart();

                } else {
                    commonS.tip(res.desc);
                }
            }
            , error: function () {
                commonS.loadingToggle(false);
                commonS.tip("请求出错：" + res2.status + "," + res2.statusText);
            }
        })
    },
	// 获取游戏账号和可充值面值
    getAccountAndPrizeList: function(gameid) {
    	var c = this;
    	if(!gameid) {
    		$(".goods-list").html("");
    		$(".account-line .no").html("请选择游戏").show();
            $(".account-line .yes").hide();
            $(".go-prize").removeClass("go-prize-can");
		} else {
            commonM.ajax({
                url: "/play_ground.php?act=server_list",
                type: "post",
                dataType: "text",
                data: {
                    app_id: gameid
                },
                success: function (res) {
                    var code = res.result;
                    if (code == 1) {
                        var accountList = res.servers || [];
                        var prizeList = res.good_list || [];
                        var accountCon = "", prizeCon = "";
                        // 更新充值账号列表
                        if (accountList.length > 0) {
                            for (var i = 0; i < accountList.length; i++) {
                                var item = accountList[i];
                                accountCon += '<option data-serverid="' + item.AreaServerID + '" data-roleid="' + item.RoleID + '" data-rolename="'+ item.RoleName +'">' + item.AreaServerName + '-' + item.RoleName + '</option>';
                            }
                            $(".prize-select-zone .account-line .yes").html(accountCon).show();
                            $(".prize-select-zone .account-line .no").hide();
                            $(".go-prize").addClass("go-prize-can");
                        } else {
                            $(".prize-select-zone .account-line .yes").html("").hide();
                            $(".prize-select-zone .account-line .no").html("未创建游戏区服").show();
                            $(".go-prize").removeClass("go-prize-can");
                        }
                        // 更新充值面值列表
                        if (prizeList.length) {
                            for (var i = 0; i < prizeList.length; i++) {
                                var item = prizeList[i];
                                prizeCon += '<div class="item" data-goodsid="' + item.id + '">'
                                    + '<div class="goods-name">' + item.good_name + '</div>'
                                    + '<div class="consume"><span class="num">' + item.consume + '</span>积分</div>'
                                    + '</div>';
                            }
                            $(".goods-list").html(prizeCon);
                            $(".goods-list .item:first").addClass("active");

                        } else {
                            $(".goods-list").html("暂无可充值面值");
                        }
                        c.updatePrizePart();

                    } else {
                        commonS.tip(res.desc);
                    }
                }
            })
		}
	},
    //获取我的奖品列表
    getPrizeRecordList: function(page) {
        page == 1 && commonS.loadingToggle(true);
    	var c = this;
        commonM.ajax({
            url: "/play_ground.php?act=draw_log",
            type: "post",
            dataType: "text",
            data: {
                page: page
            },
            success: function (res) {
                commonS.loadingToggle(false);
                var code = res.result;
                if (code == 1) {
                    c.va.prizeRecordCurPage = parseInt(res.page);
                    var data = res.data || [];
                    var con = "";
                    if(data.length) {
                        for (var i = 0; i < data.length; i++) {
                            var item = data[i];
                            con += '<div class="item"><div class="left">'
                                + '<img src="//cdn.66173.cn' + item.app_icon + '" alt="" class="icon-prize">'
                                + '<div class="l-c">'
                                + '<div class="text-overflow goods-name">' + item.title + '</div>'
                                + '<div class="time">' + commonM.getLocalTime(item.buy_time) + '</div>'
                                + '</div></div>'
                                + '<div class="right">'
                                + '<div class="line status-line">';
                            if(item.status == 2){
                                con += '<span class="status-get done">已中奖';
                            }else if(item.status == 1){
                                con += '<span class="status-get doing">兑换中';
                            }
                            con += '</span></div>'
                                + '<div class="line consume-line">消耗<span class="num">' + item.consume + '</span>积分</div>'
                                + '</div>'
                                + '</div>'
                        }
                    } else {
                        con = '<div class="no">您还没有抽奖记录~</div>';
                    }
                    if(c.va.prizeRecordCurPage == 1) {
                        $(".prize-record-list").html(con);
                    } else {
                        $(".prize-record-list").append(con);
                    }


                    if(!$(".prize-record-list .item").length) {
                        $(".prize-record-section .get-more").html("");
                    } else {
                        if(data.length >= 10) {
                            $(".prize-record-section .get-more").html("加载更多").addClass("has-more, has-more-can");
                        } else {
                            $(".prize-record-section .get-more").html("没有了~").removeClass("has-more, has-more-can");
                        }
                    }

                } else {
                    commonS.tip(res.desc);
                }
            },
            error: function () {
                commonS.tip("请求出错：" + res2.status + "," + res2.statusText);
            }
        })
    },
    // 更新积分
    updateIntegral: function(num) {
        var a = parseInt(num);
        if(a) {
            commonC.infoObj.integral = a;
            $("#integral").val(a);
            $(".integral-tip .num").html(a);
        }
    },
	// 看积分是否够抽奖
	updatePrizePart: function() {
        if(commonC.infoObj.integral < $(".goods-list .active .num").html()) {
            $(".prize-exchange-section .not-enough").show();
            $(".prize-exchange-section .go-prize").removeClass("go-prize-can");
        } else {
            $(".prize-exchange-section .not-enough").hide();
            var gameid = $(".game-choose option:selected").length && $(".game-choose option:selected").data("gameid");
            var serverid = $(".account-choose option:selected").length && $(".account-choose option:selected").data("serverid");
            var roleid = $(".account-choose option:selected").length && $(".account-choose option:selected").data("roleid");
            if(!gameid || !serverid || !roleid) {
                $(".prize-exchange-section .go-prize").removeClass("go-prize-can");
            } else {
                $(".prize-exchange-section .go-prize").addClass("go-prize-can");
            }
		}
	},
    init: function() {
        var c = this;
        var b = commonM.browserRel();
        var t = (new Date()).getTime();
        commonC.uaObj = {
            system: b.os || "",
            deviceType: b.deviceType || "",
            osVer: b.osVersion || "",
            browser: b.browser || "",
            broswerVer: b.browserVersion || "",
            lang: b.language || "",
            sdkVer: "1.0.0.1",
            token: $("#token").val(),
            channel: $("#channel").val(),
            userId: $("#userId").val(),
            userName: $("#userName").val(),
            appId: $("#appId").val(),
            timestamp: t,
            safety: md5($("#appId").val()+$("#channel").val()+t+$("#token").val())
        };
        commonC.infoObj = {
            integral: $("#integral").val(),
            initTitle: $("title").html(),
            mobile: $("#mobile").val(),
            userId: $("#userId").val(),
            userName: $("#userName").val(),
            wxIconUrl: $("#img").val(),
            sex: $("#sex").val(),
            isFirstLogin: $("#isFirstLogin").val(),
            screenHeight: window.screen.height,
            mAddress: $("#mAddress").val()
        };
        c.event();
        if($(".before-mask").length) {
            var r = 3;
            beforeGameInterval = setInterval(function () {
                if (r > 1) {
                    r--;
                    $(".before-mask .time").html(r);
                } else {
                    $(".before-mask").hide();
                    clearInterval(beforeGameInterval);
                }
            }, 1000)
        }
        if (commonC.infoObj.userId) {
            if(commonC.infoObj.isFirstLogin == 0){
                commonS.popControl(".pop-stripe-red-fireworks", ".block-everyday", "每日登陆");
            }
            (function () {
                var gameUrl = $("#gameUrl").val();
                if(gameUrl) {
                    var gameFrameDiv = document.getElementById("gameFrameDiv");
                    var iframe = document.createElement("iframe");
                    var a = "appId=" + $("#appId").val() + "&channel=" + $("#channel").val() + "&userId=" + $("#userId").val() + "&token=" + $("#token").val() + "&appId=" + $("#appId").val() + "&t=" + (new Date()).getTime();
                    gameUrl = gameUrl.indexOf("?") > 0 ? gameUrl + "&" + a : gameUrl + "?" + a;
                    iframe.setAttribute("src", gameUrl);
                    iframe.setAttribute("id", "gameFrame");
                    iframe.setAttribute("frameborder", "0");
                    gameFrameDiv.appendChild(iframe);
                }
            })();
        }

    }
};
nn.init();