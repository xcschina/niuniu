var dataMd5;
var key_;
var pay_param;
$(document).ready(function () {
    $.getScript('//cdn.66173.cn/mobile/scripts/sdk/js/md5.min.js?y=2', function () {
        dataMd5 = window.md5;
    });
    $.getScript('//www.jxw123.com/js/h5sdk.v1.js', function () {
         jxwSv = new JxwSv({
            uid: getQueryString("uid"),			//用户id
            token: getQueryString("token")		// 蓝魔用户 token，登录口令
        });
    });
    var loginParams = [];
    loginParams['uid'] = getQueryString("uid");
    loginParams['token'] = getQueryString("token");
    key_ = loginParams;
    nn_login_ajax(loginParams);
});

function do_login(sign) {
    var loginParams = key_;
    //初始化事件
    jxwSv.initEvent();
}

function nn_login_ajax(loginParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/lanmo_login.php",{
            platform: o.platform,
            appId:o.appId,
            uid:loginParams.uid,
            token:loginParams.token
        },
        function (data) {
            if(data.result == '1'){
                do_login(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}
//登录报道
function pltLogin() {
    var loginParams  = key_;
    var t = (new Date()).getTime();
    setPlayerId(loginParams['uid'], '', t, loginParams['sign']);
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    //rsdk登录报道
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}

function pltGoPay(data, data2) {
    var login_p = key_;
    var payParams = {
        'orderid' : data2.orderid,
        'money' : data2.money,
        'product' :  data2.product,
        'appid' :  data2.app_id,
        'uid': login_p.uid
    };
    pay_param = payParams;
    nn_pay_ajax(payParams);
}

function do_pay(sign) {
    var cpPayParams = pay_param;
    cpPayParams['sign'] = sign;
    jxwSv.pay(cpPayParams,function(data){console.log(data);});
}

function nn_pay_ajax(payParams){
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/lanmo_pay.php",{
            platform: o.platform,
            appId: o.appId,
            money: payParams.money,
            product: payParams.product,
            appid: payParams.appid,
            orderid: payParams.orderid,
            uid: payParams.uid
        },
        function(data){
            if(data.result == '1'){
                do_pay(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}

function setPayResult(returnCode){
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}

function logout() {
    NMRTSDK.va.logoutCb();
}