var dataMd5;
var key_;
var pay_param;
$(document).ready(function () {
    $.getScript('//cdn.66173.cn/mobile/scripts/sdk/js/md5.min.js?y=2', function () {
        dataMd5 = window.md5;
    });
    var loginParams = [];
    key_ = loginParams;

});

function do_login(data) {
    $.post("//platform.xgame.wali.com/v2/platform/checkToken",{
        token:data.token,
        timestamp:data.timestamp,
        appId:data.appId,
        gameId:data.gameId,
        sign:data.sign
    },
    function(result){
        if(result.code === 200){
            var info = result.data;
            var t = (new Date()).getTime();
            setPlayerId(info.uid, '', t, data.sign);
            key_['sign'] = data.sign;
            key_['appId'] = data.appId;
            key_['gameId'] = data.gameId;
            key_['token'] = data.token;
            key_['user_id'] = info.uid;
            key_['timestamp'] = t;
        }else{
            alert(result.msg + '请重新登录')
        }
    });
    // sdk.login(function(code,loginParams){});
}

function nn_login_ajax(token) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/xiaomi_login.php",{
            platform: o.platform,
            app_id:o.appId,
            token:token,
            timestamp:new Date().getTime()
        },
        function(data){
            if(data.result == '1'){
                do_login(data.info)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}

//登录报道
function pltLogin() {
    var loginParams  = key_;
    var t = (new Date()).getTime();
    $.getScript('//rs.xgame.wali.com/sdk/XM_SDK.js?t='+Math.random(), function () {
        sdk = window.XM_SDK;
        sdk.init({
            appId:'10056',
            gameId:'1005601'
        });
        sdk.login(function(code,data){
            if(code === 0){
                nn_login_ajax(data.token);
            }else{
                alert('错误启动地址');
            }
        });
    });
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    //rsdk登录报道
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}

function pltGoPay(data, data2) {
    var login_p = key_;
    var payParams = {
        'token' : login_p.token,
        'timestamp' : new Date().getTime(),
        'appId' :  data2.app_id,
        'gameId' :  data2.game_id,
        'currency' :  1,
        'amount' :  data2.amount,
        'price' :  data2.price,
        'sname' :  data2.sname,
        'extend': data2.extend
    };
    pay_param = payParams;
    nn_pay_ajax(payParams);
}

function do_pay(payParams,sign) {
    var cpPayParams = pay_param;
    $.post("//platform.xgame.wali.com/v2/platform/pay",{
            token: payParams.token,
            timestamp: payParams.timestamp,
            appId: payParams.appId,
            gameId: payParams.gameId,
            currency: payParams.currency,
            amount: payParams.amount,
            price: payParams.price,
            sname: payParams.sname,
            extend: payParams.extend,
            sign:sign
        },
        function(result){
            if(result.code == 200){
                var data = result.data;
                sdk.pay(data.orderId,function(code,data){
                    // if(code === 0){
                    //     alert('支付成功');
                    // }else{
                    //     alert('支付失败');
                    // }
                });
            }
        });
    // sdk.pay(cpPayParams['extend'],function(cpPayParams){console.log(cpPayParams);});
}

function nn_pay_ajax(payParams){
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/xiaomi_pay.php",{
            platform: o.platform,
            app_id: o.appId,
            token: payParams.token,
            timestamp: payParams.timestamp,
            appId: payParams.appId,
            gameId: payParams.gameId,
            currency: payParams.currency,
            amount: payParams.amount,
            price: payParams.price,
            sname: payParams.sname,
            extend: payParams.extend
        },
        function(data){
            if(data.result == '1'){
                do_pay(payParams,data.sign);
            }else{
                alert(data.desc + '请重新支付')
            }
        });
}

function setPayResult(returnCode){
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}

function logout() {
    NMRTSDK.va.logoutCb();
}

