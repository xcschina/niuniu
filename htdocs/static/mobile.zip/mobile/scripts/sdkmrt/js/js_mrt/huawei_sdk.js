function pltLogin() {
    window.HiSpaceObject && window.HiSpaceObject.getPlayerId();
}
function pltShowFloatBall() {
    window.HiSpaceObject && window.HiSpaceObject.showBuoy();
}
function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}



function pltGoPay(data, data2) {
    var p = {
        userName: data2.userName,
        userID: data2.userID,
        applicationID: data2.applicationID,
        amount: String((parseFloat(data2.amount)).toFixed(2)),
        productName: data2.productName,
        requestId: data2.requestId,
        productDesc: data2.productDesc,
        extReserved: data2.extReserved,
        sign: data2.sign,
        signType: data2.signType,
        screentOrient: data.screenOrient? parseInt(data.screenOrient) : 1
    };
    NMRTCommonM.log("pay:",JSON.stringify(p));
    window.HiSpaceObject && window.HiSpaceObject.startPay(JSON.stringify(p));
}

function setPayResult(returnCode) {
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}
function logout() {
    NMRTSDK.va.logoutCb();
}