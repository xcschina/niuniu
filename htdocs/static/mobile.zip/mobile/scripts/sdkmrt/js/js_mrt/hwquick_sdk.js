var hw_callback;
var app_id;
var success;
function pltLogin() {
    var chID = getQueryString("chID");
    app_id = chID
    var params = {"appid":app_id,"forceLogin":1}
    HwFastappObject.gameLogin(JSON.stringify(params));
}
HwFastappObject.onGameLoginResult = function onGameLoginResult(Callback){
    hw_callback = Callback;
    success = 0;
    showFloatWindow();
    if(Callback.gameUserData.ts == undefined){
    }else{
        setPlayerId(hw_callback.gameUserData.playerId,'',hw_callback.gameUserData.ts,hw_callback.gameUserData.gameAuthSign);
    }
}
function showFloatWindow(){
    var params = {"appid":app_id}
    HwFastappObject.showFloatWindow(JSON.stringify(params));
}
function hideFloatWindow(){
    var params = {"appid":app_id}
    HwFastappObject.hideFloatWindow(JSON.stringify(params));
}
function pltRoleReport(data) {   //创建角色报道
    var params = {
        "appid":app_id,
        "area":data.serverName,
        "rank":data.roleLevel,
        "role":data.roleName
    };
    if(data.roleReportType==1){
        console.log('创建角色')
        HwFastappObject.savePlayerInfo(JSON.stringify(params));
    }else if(data.roleReportType==2){
        console.log('进入游戏角色报道')
        HwFastappObject.savePlayerInfo(JSON.stringify(params));
    } else if(data.roleReportType == 3) {
        console.log('角色升级')
        HwFastappObject.savePlayerInfo(JSON.stringify(params));
    }
}
HwFastappObject.onSavePlayerInfoResult = function onSavePlayerInfoResult(str){
    //角色报道回调
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}

function pltGoPay(data, data2) {
    var orderInfo = {
        "amount": String((parseFloat(data2.amount)).toFixed(2)),
        "applicationID": data2.applicationID,
        "productDesc": data2.productDesc,
        "productName": data2.productName,
        "requestId": data2.requestId,
        "serviceCatalog": "X6",    //游戏设置为"X6"，应用设置为"X5"
        "merchantId": data2.merchantId,
        "merchantName": data2.userName,
        "sign": data2.sign,
        "urlver": data2.urlver,
        "sdkChannel": data2.sdkChannel,
        "publicKey": data2.param2
    }
    var param2 = {"orderInfo":orderInfo}
    HwFastappObject.pay(JSON.stringify(param2));
}

HwFastappObject.onPayResult = function onPayResult(str){
    // alert("支付结果: "+str.code+",message: "+str.data);
}

function setPayResult(returnCode) {
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}
function logout() {
    NMRTSDK.va.logoutCb();
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

system.onmessage = function(data) {
    if (data == "showfloatwindow") {
        if (success == 0) {
            showFloatWindow();
        }
    }
    if (data == "hidefloatwindow") {
        hideFloatWindow();
    }
}

