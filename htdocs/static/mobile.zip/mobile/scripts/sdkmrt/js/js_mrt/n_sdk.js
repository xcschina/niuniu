function pltLogin() {
    var data =  new Array();
    data['appId'] = getQueryString("appId");
    data['platform'] = getQueryString("channel");
    data['userId'] = getQueryString("userId");
    data['token'] = getQueryString("token");
    data['timestamp'] = getQueryString("timestamp");
    if(data['userId'] == null || !data['userId']){
        pltLogoutCb()
    }else{
        setPlayerId(data)
    }
    // window.parent.postMessage({
    //     action: "cp_login"
    // },"*");

}
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function pltLogoutCb() {
    NMRTSDK.va.logoutCb();
}
function pltRoleReport(data) {
    window.parent.postMessage({
        action: "cp_roleReport",
        info: data
    },"*");
}
function pltShowFloatBall() {
    window.parent.postMessage({
        action: "cp_show_float"
    },"*");
}
function pltHideFloatBall() {
    window.parent.postMessage({
        action: "cp_hide_float"
    },"*");
}
function setPlayerId(data) {
    console.log(data);
    alert()
    console.log(data);
    var o = NMRTCommonC.uaObj || {};
    o.userId = data.userId;
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: data.userId,
        appId: o.appId,
        token: data.token
    })
    NMRTSDK.loginCb();
}
function pltGoPay(data, data2) {
    var p = {
        userName: data2.userName,
        userID: data2.userID,
        applicationID: data2.applicationID,
        amount: String((parseFloat(data2.amount)).toFixed(2)),
        productName: data2.productName,
        requestId: data2.requestId,
        productDesc: data2.productDesc,
        extReserved: data2.extReserved,
        sign: data2.sign,
        signType: data2.signType,
        screentOrient: data.screenOrient? parseInt(data.screenOrient) : 1
    }
    window.parent.postMessage({
        action: "cp_pay",
        info: p
    },"*");
}

function setPayResult(info) {
    var returnCode = info.returnCode;
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}

(function() {
    var nsdk = {
        _registerReceiveMessage: function() {
            window.addEventListener("message", function(e) {
                var data = e.data || {};
                var info = data.info;
                switch (data.action) {
                    case "cp_cb_du":
                        if(info == false) {
                            NMRTSDK.va._du = false;
                        }
                        break;
                    case "cp_cb_login":
                        setPlayerId(info);
                        break;
                    case "cp_cb_logoutCb":
                        pltLogoutCb(info);
                        break;
                    case "cp_cb_pay":
                        setPayResult(info);
                        break;
                    default:
                        return
                }
            }, false)
        },
        pltInit: function(du) {
            NMRTSDK.va._du = du ? true : false;
            this._registerReceiveMessage();
            window.parent.postMessage({
                action: "cp_ready"
            }, "*")
        }
    }
    nsdk.pltInit(NMRTSDK.va._du);
})();