var dataMd5;
var key_;
var pay_param;
$(document).ready(function () {
    $.getScript('//cdn.66173.cn/mobile/scripts/sdk/js/md5.min.js?y=2', function () {
        dataMd5 = window.md5;
    });
    var loginParams = [];
    loginParams['packageName'] = getQueryString("packageName");
    loginParams['callbackUrl'] = getQueryString("callbackUrl");
    key_ = loginParams;

});

//登录报道
function pltLogin() {
    var loginParams  = key_;
    var t = (new Date()).getTime();
    $.getScript('//cdofs.oppomobile.com/cdo-activity/static/201809/30/gamehall/sdk/oppo-sdk-1.6.0.js', function () {
        oppo = window.OPPO;
        //设置屏幕横（landscape）/竖（portrait）屏
        oppo.setWebviewOrientation('portrait');
        var version = oppo.getAppVersion();
        if(version >= 1200){
            oppo.setLoadingProgress(20);
        }
        if(version >= 1300){
            android.setBackBtnVisible(false);
        }
        oppo.login({
            packageName: loginParams['packageName'],//需要修改成开发者在oppo开放平台填写的包名才能成功调用此方法
            callback: function(res){
                // alert("login:"+JSON.stringify(res));
                if(res.code == 200){
                    setPlayerId(res.userId, '', t, res.token);
                    if(version >= 1200){
                        oppo.loadingComplete();
                    }
                }else{
                    alert('错误启动地址');
                }
            }
        });
    });
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    //rsdk登录报道
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}

function pltGoPay(data, data2) {
    var payParams = {
        'appName' : data2.appName,
        'appVersion' :  data2.appVersion,
        'appKey' :  data2.appKey,
        'productDesc' :  data2.productDesc,
        'price' :  data2.price,
        'productName' :  data2.productName,
        'orderId': data2.orderId
    };
    pay_param = payParams;
    oppo.checkPay(function(res){
        if(res){
            nn_pay_ajax(payParams);
        }else{
            alert('支付调起失败：'+ res);
        }
    });
}

function nn_pay_ajax(payParams){
    var loginParams  = key_;
    oppo.pay({
        packageName: loginParams['packageName'], //开发者在oppo开放平台填写的包名
        appName: payParams['appName'],
        appVersion: payParams['appVersion'],
        appKey: payParams['appKey'], //在oppo开放平台得到的appKey
        orderId: payParams['orderId'], //开发者在自己业务系统下的订单号
        price: payParams['price'], //单位 分
        productName:payParams['productName'],
        productDesc: payParams['productDesc'],
        callbackUrl: loginParams['callbackUrl'],
        //接收支付平台付款通知的地址，与oppo android SDK的支付通知处理一致
        callback: function(res) {
            if(res.code == 200 ){
                console.log("支付请求成功");
            }else{
                alert("支付请求失败：" + res.msg);
            }
        }
    });
}

function setPayResult(returnCode){
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}

function logout() {
    NMRTSDK.va.logoutCb();
}

