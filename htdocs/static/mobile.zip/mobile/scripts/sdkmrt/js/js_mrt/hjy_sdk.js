var dataMd5;
var key_;
var pay_param;
$(document).ready(function () {
    $.getScript('//cdn.66173.cn/mobile/scripts/sdk/js/md5.min.js?y=2', function () {
        dataMd5 = window.md5;
    })
    var loginParams = [];
    loginParams['gameId'] = getQueryString("gameId");
    loginParams['uid'] = getQueryString("uid");
    loginParams['userName'] = getQueryString("userName");
    loginParams['time'] = getQueryString("time");
    loginParams['sign'] = getQueryString("sign");
    key_ = loginParams;
    nn_login_ajax(loginParams);
})
function do_login(sign) {
    var loginParams = key_;
    if(loginParams['sign'] != sign){
        alert('登录验证失败！请重新登录');
    }
}
function nn_login_ajax(loginParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/hjy_login.php",{
            platform: o.platform,
            appId:o.appId,
            gameId:loginParams.gameId,
            uid:loginParams.uid,
            userName:loginParams.userName,
            time:loginParams.time
        },
        function (data) {
            if(data.result == '1'){
                do_login(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}
//登录报道
function pltLogin() {
    var loginParams  = key_
    var t = (new Date()).getTime();
    setPlayerId(loginParams['uid'], '', t, loginParams['sign']);
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    //rsdk登录报道
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}
function pltGoPay(data, data2) {
    var login_p = key_;
    var payParams = {
        'gameId' : login_p.gameId,
        'uid' : login_p.uid,
        'time' : timest(),
        'server' :  data2.server,
        'role' :  data2.role,
        'goodsId' :  data2.goodsId,
        'goodsName' :  data2.goodsName,
        'money' :  data2.money,
        'cpOrderId' : data2.cpOrderId,
        'signType' : 'md5'
    }
    pay_param = payParams;
    nn_pay_ajax(payParams);
}
function do_pay(sign) {
    var cpPayParams = pay_param
    cpPayParams['sign'] = sign;
    sdk.pay(cpPayParams);
}
function nn_pay_ajax(payParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/hjy_pay.php",{
            platform: o.platform,
            appId: o.appId,
            gameId: payParams.gameId,
            uid: payParams.uid,
            time: payParams.time,
            server: payParams.server,
            role: payParams.role,
            goodsId: payParams.goodsId,
            goodsName: payParams.goodsName,
            money: payParams.money,
            cpOrderId: payParams.cpOrderId,
        },
        function (data) {
            if(data.result == '1'){
                do_pay(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}

function setPayResult(returnCode) {
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}
function logout() {
    NMRTSDK.va.logoutCb();
}
//设备报答
function pltRoleReport(data) {
    //创建角色报
    var login_p = key_;
    if(data.roleReportType==1){
        console.log('创建角色')
        var roleParam = {
            isCreateRole: true,
            gameId: login_p.gameId,
            roleCreateTime: timest(),
            uid: login_p.uid,
            username: login_p.userName,
            serverId: data.serverId,
            serverName: data.serverName,
            userRoleId: data.roleId,
            userRoleName: data.roleName,
            userRoleLevel: data.roleLevel,
            userRoleBalance: 0,
            vipLevel: 0
        };
        sdk.uploadGameRole(roleParam);
    }else if(data.roleReportType==2){
        console.log('进入游戏')
    } else if(data.roleReportType == 3) {
        console.log('角色升级')
        var roleParam = {
            isCreateRole: false,
            gameId: login_p.gameId,
            roleCreateTime: timest(),
            uid: login_p.uid,
            username: login_p.userName,
            serverId: data.serverId,
            serverName: data.serverName,
            userRoleId: data.roleId,
            userRoleName: data.roleName,
            userRoleLevel: data.roleLevel,
            userRoleBalance: 0,
            vipLevel: 0
        };
        sdk.uploadGameRole(roleParam);
    }
}

function timest() {
    var tmp = Date.parse( new Date() ).toString();
    tmp = tmp.substr(0,10);
    return tmp;
}