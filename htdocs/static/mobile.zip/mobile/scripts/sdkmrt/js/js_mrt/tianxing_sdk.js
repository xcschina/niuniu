var dataMd5;
var key_;
var pay_param;
$(document).ready(function () {
    $.getScript('//cdn.66173.cn/mobile/scripts/sdk/js/md5.min.js?y=2', function () {
        dataMd5 = window.md5;
    })
    var loginParams = [];
    loginParams['channelExt'] = getQueryString("channelExt");
    loginParams['email'] = getQueryString("email");
    loginParams['game_appid'] = getQueryString("game_appid");
    loginParams['new_time'] = getQueryString("new_time");
    loginParams['loginplatform2cp'] = getQueryString("loginplatform2cp");
    loginParams['user_id'] = getQueryString("user_id");
    loginParams['sdklogindomain'] = getQueryString("sdklogindomain");
    loginParams['sdkloginmodel'] = getQueryString("sdkloginmodel");
    loginParams['sign'] = getQueryString("sign");
    key_ = loginParams;
    nn_login_ajax(loginParams);
})
function do_login(sign) {
    var loginParams = key_;
    if(loginParams['sign'] != sign){
        alert('登录验证失败！请重新登录');
    }
}
function nn_login_ajax(loginParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/tianxing_login.php",{
            platform: o.platform,
            appId:o.appId,
            channelExt:loginParams.channelExt,
            email:loginParams.email,
            game_appid:loginParams.game_appid,
            new_time:loginParams.new_time,
            loginplatform2cp:loginParams.loginplatform2cp,
            user_id:loginParams.user_id,
            sdklogindomain:loginParams.sdklogindomain,
            sdkloginmodel:loginParams.sdkloginmodel,
            sign:loginParams.sign,
        },
        function (data) {
            if(data.result == '1'){
                do_login(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}
//登录报道
function pltLogin() {
    var loginParams  = key_
    var t = (new Date()).getTime();
    setPlayerId(loginParams['user_id'], '', t, loginParams['sign']);
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    //rsdk登录报道
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}
function pltGoPay(data, data2) {
    var login_p = key_;
    var payParams = {
        'amount' : data2.money,
        'channelExt' : login_p.channelExt,
        'game_appid' :  login_p.game_appid,
        'props_name' :  data2.goodsName,
        'trade_no' :  data2.cpOrderId,
        'user_id' :  login_p.user_id,
        'sdkloginmodel' :  login_p.sdkloginmodel,
    }
    pay_param = payParams;
    nn_pay_ajax(payParams);
}
function do_pay(sign) {

    var cpPayParams = pay_param
    cpPayParams['sign']=sign;
    tianxing.h5paySdk(cpPayParams,function(data){console.log(data);});

}
function nn_pay_ajax(payParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/tianxing_pay.php",{
            platform: o.platform,
            appId: o.appId,
            amount: payParams.amount,
            channelExt: payParams.channelExt,
            game_appid: payParams.game_appid,
            props_name: payParams.props_name,
            user_id: payParams.user_id,
            trade_no: payParams.trade_no,
            sdkloginmodel: payParams.sdkloginmodel,
        },
        function (data) {
            if(data.result == '1'){
                do_pay(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}

function setPayResult(returnCode) {
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}
function logout() {
    NMRTSDK.va.logoutCb();
}
//设备报答
function pltRoleReport(data) {
    //创建角色报道
    var login_p = key_;
    console.log('创建角色')
    var roleParam = {
        user_id: login_p.user_id,
        game_appid: login_p.game_appid,
        server_id: data.serverId,
        server_name:  data.serverName,
        role_id: data.roleId,
        role_name: data.roleName,
        level: data.roleLevel,
        sign: data.roleLevel,
    };
    tianxing.jointCreateRole(roleParam,function(data){console.log(data);});
}