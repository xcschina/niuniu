var dataMd5;
var key_;
var pay_param;
$(document).ready(function () {
    $.getScript('//cdn.66173.cn/mobile/scripts/sdk/js/md5.min.js?y=2', function () {
        dataMd5 = window.md5;
    });
    var loginParams = [];
    loginParams['user_id'] = getQueryString("user_id");
    loginParams['agent'] = getQueryString("agent");
    loginParams['time'] = getQueryString("time");
    loginParams['sign'] = getQueryString("sign");
    key_ = loginParams;
    dataDelivery('server');
    nn_login_ajax(loginParams);
});

function do_login(sign) {
    var loginParams = key_;
}

function nn_login_ajax(loginParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/iqiyi_login.php",{
            platform: o.platform,
            appId:o.appId,
            user_id:loginParams.user_id,
            agent:loginParams.agent,
            time:loginParams.time,
            sign:loginParams.sign
        },
        function(data){
            if(data.result == '1'){
                do_login(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}
//登录报道
function pltLogin() {
    var loginParams  = key_;
    var t = (new Date()).getTime();
    setPlayerId(loginParams['user_id'], '', t, loginParams['sign']);
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    //rsdk登录报道
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}

function pltGoPay(data, data2) {
    var login_p = key_;
    var payParams = {
        'game_id' : data2.game_id,
        'user_id' : login_p.user_id,
        'server_id' :  data2.server_id,
        'money' :  data2.money,
        'extra_param':data2.extra_param
    };
    pay_param = payParams;
    nn_pay_ajax(payParams);
}

function do_pay() {
    var cpPayParams = pay_param;
    var str = 'game_id='+cpPayParams['game_id']+'&user_id='+cpPayParams['user_id']+'&server_id='
                +cpPayParams['server_id']+'&money='+cpPayParams['money']+"&extra_param="+cpPayParams['extra_param'];
    window.parent.postMessage(str,'http://togame.iqiyi.com');
}

function nn_pay_ajax(payParams){
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/iqiyi_pay.php",{
            platform: o.platform,
            appId: o.appId,
            game_id: payParams.game_id,
            user_id: payParams.user_id,
            server_id: payParams.server_id,
            money: payParams.money
        },
        function(data){
            if(data.result == '1'){
                do_pay()
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}

function setPayResult(returnCode){
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}

function logout() {
    NMRTSDK.va.logoutCb();
}

function pltRoleReport(data){   //创建角色报道
    if(data.roleReportType==1){
        console.log('创建角色');
        dataDelivery('role');
    }else if(data.roleReportType==2){
        console.log('进入游戏');
        dataDelivery('server');
    }else if(data.roleReportType == 3){
        console.log('角色升级');
        dataDelivery('start');
    }
}

function dataDelivery(msg){  //数据投递
    var obj = {
        type:'dataCount',
        msg : msg
    };
    try{
        window.top.postMessage({
            type:'dataCount',
            msg : 'start'
        },'http://togame.pps.tv');
    }catch(e){
        alert('出错啦');
    }

}