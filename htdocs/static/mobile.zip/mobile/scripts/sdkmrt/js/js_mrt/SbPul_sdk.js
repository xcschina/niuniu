function pltShowFloatBall() {
    console.log("指尖显示悬浮球----");
}
function pltHideFloatBall() {
    console.log("指尖隐藏悬浮球-----");
}

function pltLogin() {
    var loginParams = {
        qqesuid: getQueryString("qqesuid"),  //平台用户id
        channelid: getQueryString("channelid"), //渠道id
        channeluid: getQueryString("channeluid"), //渠道用户id
        qqesnickname: getQueryString("qqesavatar"),//	平台用户昵称(可选)
        qqesavatar: getQueryString("qqesuid"),//平台用户头像(不需要参与签名)
        cpgameid: getQueryString("cpgameid"),//cp游戏id
        ext: getQueryString("ext"),//透传用户信息字段，支付的时候必须原样回传
        qqestimestamp: getQueryString("qqestimestamp"),//请求时间戳
        sign: getQueryString("sign")//签名字符串，算法： 除非字段标注为不需要参与签名，否则请求参数都参与签名
    };
    key_ = loginParams;
    var login_p = key_;
    var t = (new Date()).getTime();
    console.log('pltLogin')
    console.log(loginParams.qqesuid)
    console.log(loginParams.sign)
    setPlayerId(loginParams.qqesuid, '', t, loginParams.sign);
}
function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    NMRTSDK.loginCb();
}
function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function pltLogoutCb() {
    console.log("指尖退出账号回调---");
    NMRTSDK.va.logoutCb();
}

function pltRoleReport(data) {   //创建角色报道
    var login_p = key_;
    if(data.roleReportType==1){
        var roleInfo = {
            qqesuid:login_p.qqesuid,//平台用户id(用户唯一id，可以用来和cp用户关联)
            channelid:login_p.channelid,//渠道id
            channeluid:login_p.channeluid,//渠道用户id
            cpgameid:login_p. cpgameid,//cp游戏id
            nickName:data.roleName,//游戏昵称
            serverId:data.serverId,//区服id
            serverName:data.serverName,//区服名称
            roleName:"无",
        };
        SbPulSdk.createRole(roleInfo);
        beginGame(data);
    }else if(data.roleReportType==3){
        var roleInfo ={
            cpgameid:login_p.cpgameid,//cp游戏id
            qqesuid:login_p.qqesuid,//平台用户id(用户唯一id，可以用来和cp用户关联)
            channelid:login_p.channelid,//渠道id
            channeluid:login_p.channeluid,//渠道用户id
            nickName:data.roleName,//游戏昵称
            serverId:data.serverId,//区服id
            serverName:data.serverName,//区服名称
            roleName:"无",
            roleId:data.roleId,//游戏角色Id
            level:data.roleLevel,// 游戏角色等级
            vip:"0"//用户vip等级
        };
        SbPulSdk.userUpgrade(roleInfo);
        // alert("角色升级"+JSON.stringify(roleInfo));
    }
}
function beginGame(data) {  //开始游戏
    var login_p = key_;
    var roleInfo = {
        cpgameid:login_p.cpgameid,//cp游戏id
        qqesuid:login_p.qqesuid,//平台用户id(用户唯一id，可以用来和cp用户关联)
        channelid:login_p.channelid,//渠道id
        channeluid:login_p.channeluid,//渠道用户id
        nickName:"熊大",//游戏昵称
        serverId:data.serverId,//区服id
        serverName:data.serverName,//区服名称
        roleName:data.roleName,//游戏职业名称(如:道士,战士,法师)
        level:data.roleLevel,//游戏角色等级
        vip:"0"//用户vip等级
    };
    SbPulSdk.beginGame(roleInfo);
}

function pltGoPay(data,data2) {  //发起支付请求
    var login_p = key_;
    var timestamp = (new Date()).getTime();
    var sign2 ="cpgameid="+login_p.cpgameid+"&channelid="+login_p.channelid+"&channeluid="+login_p.channeluid+"&cpguid="+data.cpguid+"&ext="+login_p.ext+"&fee="+data.fee+"&goodsname="+ data.goodsname+"&order="+data.order+"&qqesuid="+login_p.qqesuid+"&timestamp="+ login_p.qqestimestamp+"&sign="+login_p.sign;
    var cpPayParams = {
        cpgameid:login_p.cpgameid,//cp的游戏id
        qqesuid	:login_p.qqesuid,//平台用户id
        channelid:login_p.channelid,//渠道id
        channeluid:login_p.channeluid,// 渠道用户id
        qqestimestamp:timestamp,//请求时间戳(用来防止重放攻击)
        ext:login_p.ext,//登录时获取的透传字段， 这里需要原样回传。

        cpguid:data.cpguid,//cp在我们平台的唯一ID(后台可查看)
        serverID:data.serverId,//支付用户服务区Id（不参与签名）
        serverName:data.serverName,//支付用户所在服务区（不参与签名）
        roleName:data.roleName,//支付用户角色名称（不参与签名）

        order:data2.requestId,//生成的订单号(请保证每次下单的订单号都不同)
        goodsname:data2.productName,//商品名称
        fee: String((parseFloat(data2.amount)).toFixed(2)),// 商品价格(元),(最多两位小数点)
        sign:md5(sign2) //签名字符串，算法： 除非字段标注为不需要参与签名，否则请求参数都参与签名，按参数值自然升序，然后拼接成字符串(比如a=1&b=2&c=3&签名秘钥)，然后md5生成签名字符串
    };
    SbPulSdk.pay(cpPayParams);
    console.log("调用到指尖支付----")
}