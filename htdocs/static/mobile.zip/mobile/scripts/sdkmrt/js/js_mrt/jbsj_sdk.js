var dataMd5;
var key_;
var pay_param;
$(document).ready(function () {
    $.getScript('//cdn.66173.cn/mobile/scripts/sdk/js/md5.min.js?y=2', function () {
        dataMd5 = window.md5;
    })
    var loginParams = [];
    loginParams['username'] = getQueryString("username");
    loginParams['time'] = getQueryString("time");
    loginParams['serverid'] = getQueryString("serverid");
    loginParams['sign'] = getQueryString("sign");
    key_ = loginParams;
    nn_login_ajax(loginParams);
})
function do_login(sign) {
    var loginParams = key_;
    if(loginParams['sign'] != sign){
        alert('登录验证失败！请重新登录');
    }
}
function nn_login_ajax(loginParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/jbsj_login.php",{
            platform: o.platform,
            appId:o.appId,
            username:loginParams.username,
            time:loginParams.time,
            serverid:loginParams.serverid,
        },
        function (data) {
            if(data.result == '1'){
                do_login(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}
//登录报道
function pltLogin() {
    var loginParams  = key_
    var t = (new Date()).getTime();
    setPlayerId(loginParams['username'], '', t, loginParams['sign']);
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    //rsdk登录报道
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}
function pltGoPay(data, data2) {
    var login_p = key_;
    var payParams = {
        'uid' : login_p.username,
        'orderno' : data2.orderid,
        'sno' :  login_p.serverid,
        'timestamp' :  data2.timestamp,
        'fee' :  data2.fee,
        'amount' :  data2.amount,
        'gameid' :  data2.gameid,
        'payment' :  '3'
    }
    pay_param = payParams;
    nn_pay_ajax(payParams);
}
function do_pay(sign) {
    var cpPayParams = pay_param
    var pay_url = 'https://dyz.basicworld.cn/gamepay/pay';
    pay_url = pay_url + "?uid=" + cpPayParams['uid'] + "&sno=" + cpPayParams['sno']+ "&orderno=" + cpPayParams['orderno']+ "&gameid=" + cpPayParams['gameid'];
    pay_url = pay_url  + "&amount=" + cpPayParams['fee'] + "&realamount=" + cpPayParams['fee']+ "&gold=" + cpPayParams['amount'];
    pay_url = pay_url  + "&payment=" + cpPayParams['payment']+ "&ticket=" + sign + "&timestamp=" + cpPayParams['timestamp'];
    window.location.href = pay_url;

}
function nn_pay_ajax(payParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/jbsj_pay.php",{
            platform: o.platform,
            appId: o.appId,
            uid: payParams.uid,
            orderno: payParams.orderno,
            sno: payParams.sno,
            timestamp: payParams.timestamp,
            payment: payParams.payment,
            amount: payParams.amount,
            fee: payParams.fee,
        },
        function (data) {
            if(data.result == '1'){
                do_pay(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}

function setPayResult(returnCode) {
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}
function logout() {
    NMRTSDK.va.logoutCb();
}
//设备报答
function pltRoleReport(data) {
    //创建角色报道
}
