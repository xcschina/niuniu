var dataMd5;
var key_;
var pay_param;
$(document).ready(function () {
    $.getScript('//cdn.66173.cn/mobile/scripts/sdk/js/md5.min.js?y=2', function () {
        dataMd5 = window.md5;
    })
    var loginParams = [];
    loginParams['qqesuid'] = getQueryString("qqesuid");
    loginParams['qqesnickname'] = getQueryString("qqesnickname");
    loginParams['channelid'] = getQueryString("channelid");
    loginParams['channeluid'] = getQueryString("channeluid");
    loginParams['cpgameid'] = getQueryString("cpgameid");
    loginParams['ext'] = getQueryString("ext");
    loginParams['qqestimestamp'] = getQueryString("qqestimestamp");
    key_ = loginParams;
    nn_login_ajax(loginParams);
})
function do_login(sign) {
    var loginParams = key_;
    loginParams['sign'] = sign;
    SbPulSdk.init(loginParams, function () {})
}
function nn_login_ajax(loginParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/zhijian_login.php",{
            platform: o.platform,
            appId:o.appId,
            qqesuid:loginParams.qqesuid,
            qqesnickname:loginParams.qqesnickname,
            channelid:loginParams.channelid,
            channeluid:loginParams.channeluid,
            cpgameid:loginParams.cpgameid,
            ext:loginParams.ext,
            qqestimestamp:loginParams.qqestimestamp
        },
        function (data) {
            if(data.result == '1'){
                do_login(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}
//登录报道
function pltLogin() {
    var loginParams  = key_
    var t = (new Date()).getTime();
    setPlayerId(loginParams['qqesuid'], '', t, loginParams['sign']);
}

function getQueryString(name) {
    var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) return unescape(r[2]); return null;
}

function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    //rsdk登录报道
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    });
}
function pltGoPay(data, data2) {
    var login_p = key_;
    var cpPayParams = {
        order: data2.orderid,
        cpgameid: data2.cpgameid,
        qqesuid: login_p.qqesuid,
        channelid: login_p.channelid,
        channeluid: login_p.channeluid,
        cpguid: data2.cpguid,
        goodsname: data2.goodsname,
        fee: data2.fee,
        serverID: data.serverId,
        serverName: data.serverName,
        roleName: "无",
        ext: login_p.ext,
        timestamp: data2.timestamp,
    };
    pay_param = cpPayParams;
    var payParams = {
        'channelid' : login_p.channelid,
        'channeluid' : login_p.channeluid,
        'cpgameid' :  data2.cpgameid,
        'cpguid' : data2.cpguid,
        'ext' : login_p.ext,
        'fee' : data2.fee,
        'goodsname' : data2.goodsname,
        'order' : data2.orderid,
        'qqesuid' : login_p.qqesuid,
        'timestamp' : data2.timestamp,
        'channelid' : login_p.channelid,
    }
    nn_pay_ajax(payParams);
}
function do_pay(sign) {
    var cpPayParams = pay_param
    cpPayParams['sign'] = sign;
    console.log(cpPayParams)
    SbPulSdk.pay(cpPayParams)

}
function nn_pay_ajax(payParams) {
    var o = NMRTCommonC.uaObj || {};
    $.post("//ins.66173yx.com/pay/zhijian_pay.php",{
            platform: o.platform,
            appId: o.appId,
            channelid: payParams.channelid,
            channeluid: payParams.channeluid,
            cpgameid: payParams.cpgameid,
            cpguid: payParams.cpguid,
            ext: payParams.ext,
            fee: payParams.fee,
            goodsname: payParams.goodsname,
            order: payParams.order,
            qqesuid: payParams.qqesuid,
            timestamp: payParams.timestamp,
            channelid: payParams.channelid
        },
        function (data) {
            if(data.result == '1'){
                do_pay(data.sign)
            }else{
                alert(data.desc + '请重新登录')
            }
        });
}

function setPayResult(returnCode) {
    var code;
    if(returnCode == 0) {
        code = 1;
    } else if(returnCode == 30000) {
        code = 2;
    } else {
        code = 3;
    }
    NMRTSDK.va.payCb({
        returnCode: code
    });

}
function logout() {
    NMRTSDK.va.logoutCb();
}
//设备报答
function pltRoleReport(data) {   //创建角色报道
    var login_p = key_;
    if(data.roleReportType==1){
        console.log('创建角色')
        var roleInfo = {
            qqesuid:login_p.qqesuid,//平台用户id(用户唯一id，可以用来和cp用户关联)
            channelid:login_p.channelid,//渠道id
            channeluid:login_p.channeluid,//渠道用户id
            cpgameid:login_p. cpgameid,//cp游戏id
            nickName:data.roleName,//游戏昵称
            serverId:data.serverId,//区服id
            serverName:data.serverName,//区服名称
            roleName:"无",
        };
        SbPulSdk.createRole(roleInfo);
        beginGame(data);
    }else if(data.roleReportType==2){
        console.log('进入游戏')
        beginGame(data);
    } else if(data.roleReportType == 3) {
        console.log('角色升级')
        var roleInfo = {
            cpgameid: login_p.cpgameid,//cp游戏id
            qqesuid: login_p.qqesuid,//平台用户id(用户唯一id，可以用来和cp用户关联)
            channelid: login_p.channelid,//渠道id
            channeluid: login_p.channeluid,//渠道用户id
            serverId: data.serverId,//区服id
            serverName: data.serverName,//区服名称
            roleName: data.roleName,
            roleId: data.roleId,//游戏角色Id
            nickName: data.roleName,//游戏昵称
            level: data.roleLevel,// 游戏角色等级
            vip: "0"//用户vip等级
        };
        SbPulSdk.userUpgrade(roleInfo);
    }
}
//进入游戏
function beginGame(data) {  //开始游戏
    var login_p = key_;
    var roleInfo = {
        cpgameid:login_p.cpgameid,//cp游戏id
        qqesuid:login_p.qqesuid,//平台用户id(用户唯一id，可以用来和cp用户关联)
        channelid:login_p.channelid,//渠道id
        channeluid:login_p.channeluid,//渠道用户id
        nickName:data.roleName,//游戏昵称
        serverId:data.serverId,//区服id
        serverName:data.serverName,//区服名称
        roleName:data.roleName,//游戏职业名称(如:道士,战士,法师)
        level:data.roleLevel,//游戏角色等级
        vip:"0"//用户vip等级
    };
    SbPulSdk.beginGame(roleInfo);
}
