window.NMRTSDKMAP = [{
	"pfId": "nn",
	"sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/n_sdk.js?t=" + (new Date()).getTime(),
    "payUrl": "//ins.66173yx.com/pay/n.php",
	"sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt_local/n_sdk.js"
},{
	"pfId": "hwquick",
	"payUrl": "//ins.66173yx.com/pay/hwquick.php",
	"sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/hwquick_sdk.js",
	"sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/hwquick_sdk.js"
},{
    "pfId": "xiaomi",
    "payUrl": "//ins.66173yx.com/pay/xiaomi.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/xiaomi_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/xiaomi_sdk.js"
},{
    "pfId": "huawei",
    "payUrl": "//ins.66173yx.com/pay/huawei.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/huawei_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt_local/huawei_sdk.js"
},{
    "pfId": "hjy",
    "payUrl": "//ins.66173yx.com/pay/hjy.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/hjy_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/hjy_sdk.js",
},{
    "pfId": "jbsj",
    "payUrl": "//ins.66173yx.com/pay/jbsj.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/jbsj_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/jbsj_sdk.js",
},{
    "pfId": "tianxing",
    "payUrl": "//ins.66173yx.com/pay/tianxing.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/tianxing_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/tianxing_sdk.js",
},{
    "pfId": "zhijian",
    "payUrl": "//ins.66173yx.com/pay/zhijian.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/zhijian_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/zhijian_sdk.js",
    // "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt_local/zhijian_sdk.js"
},{
    "pfId": "xunrui",      //3500  迅瑞
    "payUrl": "//ins.66173yx.com/pay/xunrui.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/xunrui_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/xunrui_sdk.js"
},{
    "pfId": "lanmo",      //蓝魔
    "payUrl": "//ins.66173yx.com/pay/lanmo.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/lanmo_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/lanmo_sdk.js"
},{
    "pfId": "iqiyi",      //爱奇艺
    "payUrl": "//ins.66173yx.com/pay/iqiyi.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/iqiyi_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/iqiyi_sdk.js"
},{
    "pfId": "xiaomi_h5",      //小米
    "payUrl": "//ins.66173yx.com/pay/xiaomi.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/xiaomi_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/xiaomi_sdk.js"
},{
    "pfId": "oppo_h5",      //OPPO
    "payUrl": "//ins.66173yx.com/pay/oppo.php",
    "sdkSrc": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/oppo_sdk.js",
    "sdkSrcLocal": "//cdn.66173.cn/mobile/scripts/sdkmrt/js/js_mrt/oppo_sdk.js"
}];

(function() {
	var commonC = {
		//角色参数
		"roleKeyMap": [
			{name: "roleId"},
			{name: "roleName"},
			{name: "roleLevel"},
			{name: "serverName"},
			{name: "serverId"},
			{name: "roleReportType"},
			{name: "roleCreatedTime"},
			{name: "roleLevelMTime"},
			{name: "power"},
			{name: "partyName"},
			{name: "guildId"},
			{name: "guildName"},
			{name: "guildLevel"},
			{name: "guildLeaderId"},
			{name: "roleAttachParams"},
			{name: "restCoinNum"}],
		//支付参数
		"payKeyMap": [
			{name: "platform"},
			{name: "appId"},
			{name: "userId"},
			{name: "roleId"},
			{name: "roleName"},
			{name: "roleLevel"},
			{name: "serverName"},
			{name: "serverId"},
			{name: "sdkgoodsid"},
			{name: "billno"},
			{name: "amount"},
			{name: "count"},
			{name: "productName"},
			{name: "productDesc"},
			{name: "subject"},
			{name: "extraInfo",canIgnore: true},
			{name: "screenOrient"}],
		uaObj: {},
		infoObj: {}
	};
	var commonM = {
		LOGLEVEL: {
			INFO: 0,
			WARNING: 1,
			ERROR: 2
		},
		ajax: function(a) {
			var sendData = {}, c = this, ua1Str = "";
			if(!c.isPureObject(a)) {
				return false;
			}
			sendData.url = a.url;
			sendData.type = (a.type || "get");
			sendData.data = a.data;
			sendData.dataType = (a.dataType || "json");
			for(i in commonC.uaObj) {
			    ua1Str = ua1Str + (i + "=" + commonC.uaObj[i] + "&");
	        }
	    // c.log("ua1Str:",ua1Str);
			sendData.headers = {"User-Agent1": "0" + commonM.base64.encode(ua1Str.substr(0, ua1Str.length -1))};
			$.ajax(sendData)
				.success(function(res) {
					if(typeof res == "string") {
						res = JSON.parse(c.base64.decode(res.substr(1)));
					}
					a.success && a.success(res)
				}).error(function(res2) {
					if(typeof res2 == "string") {
						res2 = JSON.parse(c.base64.decode(res2.substr(1)));
					}
					if(!a.error) {
						commonS.tip("请求出错："+res2.status+","+res2.statusText)
					} else {
						a.error(res2);
					}
					
				});
		},
		base64: {
			_keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
			decode: function(a) {
				var b, c, d, e, f, g, h, i = this,
					j = "",
					k = 0;
				for (a = a.replace(/[^A-Za-z0-9\+\/\=]/g, ""); k < a.length;) e = i._keyStr.indexOf(a.charAt(k++)), f = i._keyStr.indexOf(a.charAt(k++)), g = i._keyStr.indexOf(a.charAt(k++)), h = i._keyStr.indexOf(a.charAt(k++)), b = e << 2 | f >> 4, c = (15 & f) << 4 | g >> 2, d = (3 & g) << 6 | h, j += String.fromCharCode(b), 64 != g && (j += String.fromCharCode(c)), 64 != h && (j += String.fromCharCode(d));
				return j = i._utf8_decode(j)
			},
			// private method for UTF-8 encoding
			_utf8_decode: function(a) {
				for (var b = "", c = 0, d = c1 = c2 = 0; c < a.length;) d = a.charCodeAt(c), 128 > d ? (b += String.fromCharCode(d), c++) : d > 191 && 224 > d ? (c2 = a.charCodeAt(c + 1), b += String.fromCharCode((31 & d) << 6 | 63 & c2), c += 2) : (c2 = a.charCodeAt(c + 1), c3 = a.charCodeAt(c + 2), b += String.fromCharCode((15 & d) << 12 | (63 & c2) << 6 | 63 & c3), c += 3);
				return b
			},
			encode : function (input) {
			    var c = this,output = "",chr1, chr2, chr3, enc1, enc2, enc3, enc4,i = 0,input = c._utf8_encode(input);
			    while (i < input.length) {
			        chr1 = input.charCodeAt(i++);chr2 = input.charCodeAt(i++);chr3 = input.charCodeAt(i++);
			        enc1 = chr1 >> 2;enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);enc4 = chr3 & 63;
			        if (isNaN(chr2)) {enc3 = enc4 = 64;} else if (isNaN(chr3)) {enc4 = 64;}
			        output = output + this._keyStr.charAt(enc1) + this._keyStr.charAt(enc2) + this._keyStr.charAt(enc3) + this._keyStr.charAt(enc4);
			    }

			    return output;
			},
			// private method for UTF-8 encoding
			_utf8_encode: function (string) {
			    string = string.replace(/\r\n/g,"\n"),utftext = "";
			    for (var n = 0; n < string.length; n++) {
			        var c = string.charCodeAt(n);
			        if (c < 128) {utftext += String.fromCharCode(c);}
			        else if((c > 127) && (c < 2048)) {utftext += String.fromCharCode((c >> 6) | 192);utftext += String.fromCharCode((c & 63) | 128);}
			        else {utftext += String.fromCharCode((c >> 12) | 224);utftext += String.fromCharCode(((c >> 6) & 63) | 128);utftext += String.fromCharCode((c & 63) | 128);}
			    }
			    return utftext;
			}

		}, 
		setUaObj: function(data) {
			for(i in data) {
				commonC.uaObj[i] = data[i];
			}
		},
		getQueryString: function(name) {
			var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
			var r = window.location.search.substr(1).match(reg);
			if (r != null) {
				return unescape(r[2])
			}
			return null
		},
		isFunction: function(a) {
			return typeof a === "function" ? true : false;
		},
		isPureObject: function(a) {
			return a && typeof a == "object" ? true : false;
		},
		log: function(tag, sLog, sLevel, allAlert) {
			var c = this;
			if(window.NMRTSDK && NMRTSDK.va._du) {
				if(allAlert || navigator.userAgent.toLowerCase().match(/(ipad|ipod|iphone|android|coolpad|mmp|smartphone|midp|wap|xoom|symbian|j2me|blackberry|win ce)/i) != null) {
					if(typeof sLog == 'object') {
						alert(tag+"\n"+JSON.stringify(sLog));
					} else {
						alert(tag+"\n"+sLog);
					}
				} else {
					if (sLevel == c.LOGLEVEL.ERROR) {
						console.log("%c[NNError] " + tag, "color:red");
						console.log(sLog);
					} else if (sLevel == c.LOGLEVEL.WARNING) {
						console.log("%c[NNWarn] " + tag, "color:orange");
						console.log(sLog);
					} else if (sLevel == c.LOGLEVEL.INFO) {
						console.log("%c[NNInfo] " + tag, "color:gray");
						console.log(sLog);
					} else {
						console.log("%c[NNInfo] " + tag, "color:gray");
						console.log(sLog);
					}
				}
			}
		},
		checkEntityKey: function(obj, tKeyMap, tag) {
			var result = {}, c = this;
			msg =  tag + "\n";
			result.status = true;
			for (var i = 0; i < tKeyMap.length; i++) {
				var o = tKeyMap[i];
				var type = o.type;
				if(type) {
					var p = obj[o.name];
					var typeN = typeof p;
					if((type == "string" || type == "object") && typeN != type) {
						msg += "参数字段 " + o.name + ": " + p + " 的类型错误，" + "本该是：" + type + ",实际却为：" + typeN + "\n";
						result.status = false;
					} else if(type == "string|int" && typeN != type) {
						msg += "参数字段 " + o.name + ": " + p + " 的类型错误，" + "本该是：字符串或数字" + ",实际却为：" + typeN + "\n";
						result.status = false;
					}
				}
				if (!o.canIgnore && !obj.hasOwnProperty(o.name)) {
					result.status = false;
					msg += "缺少参数字段:" + o.name + "\n";
				} 
				
			}
			result.msg = msg;
			return result;
		},
		browserRel: function(userAgent){
			var u = userAgent||navigator.userAgent;
			var _this = {};
			var match = {
				// //内核
				Trident: u.indexOf('Trident')>0||u.indexOf('NET CLR')>0,
				Presto: u.indexOf('Presto')>0,
	            WebKit: u.indexOf('AppleWebKit')>0,
	            Gecko: u.indexOf('Gecko/')>0,
				//浏览器
				UC: u.indexOf('UC')>0||u.indexOf(' UCBrowser')>0,
				QQ: u.indexOf('QQBrowser')>0,
	            QQin: u.indexOf(' QQ')>0 || u.indexOf('MQQBrowser QQ')>0 || u.indexOf('MQQBrowserQQ')>0,
				BaiDu: u.indexOf('Baidu')>0||u.indexOf('BIDUBrowser')>0,
				Maxthon: u.indexOf('Maxthon')>0,
				LBBROWSER: u.indexOf('LBBROWSER')>0,
				SouGou: u.indexOf('MetaSr')>0||u.indexOf('Sogou')>0,
				IE: u.indexOf('MSIE')>0||u.indexOf('Trident')>0,
				Firefox: u.indexOf('Firefox')>0||u.indexOf('FxiOS')>0,
				Opera: u.indexOf('Opera')>0||u.indexOf('OPR')>0,
				Safari: u.indexOf('Safari')>0,
				Chrome:u.indexOf('Chrome')>0||u.indexOf('CriOS')>0,
				Wechat:u.indexOf('MicroMessenger')>0,
				// 系统或平台
				Windows:u.indexOf('Windows')>0,
				Linux:u.indexOf('Linux')>0,
				Mac:u.indexOf('Macintosh')>0,
				Android:u.indexOf('Android')>0||u.indexOf('Adr')>0,
				WP:u.indexOf('IEMobile')>0,
				BlackBerry:u.indexOf('BlackBerry')>0||u.indexOf('RIM')>0||u.indexOf('BB')>0,
				MeeGo:u.indexOf('MeeGo')>0,
				Symbian:u.indexOf('Symbian')>0,
				iOS:u.indexOf('like Mac OS X')>0,
				iPhone: u.indexOf('iPh')>0,
				iPad:u.indexOf('iPad')>0,
	            iPod:u.indexOf('iPod')>0,
				//设备
				Mobile:u.indexOf('Mobi')>0||u.indexOf('iPh')>0||u.indexOf('480')>0,
				Tablet:u.indexOf('Tablet')>0||u.indexOf('iPad')>0||u.indexOf('Nexus 7')>0
			};
			//修正
			if(match.Chrome){
				match.Chrome = !(match.Opera + match.BaiDu + match.Maxthon + match.SouGou + match.UC + match.QQ + match.LBBROWSER);
			}
			if(match.Safari){
				match.Safari = !(match.Chrome + match.Opera + match.BaiDu + match.Maxthon + match.SouGou + match.UC + match.QQ + match.LBBROWSER + match.Firefox);
			}
			if(match.Mobile){
				match.Mobile = !match.iPad;
			}
			//基本信息
			var hash = {
				engine:['WebKit','Trident','Gecko','Presto'],
				// Firefox要放在Safari之后，QQin要放在QQ后，因为前者在某方面会同时也满足后者特性
				browser:['Chrome','Safari','IE','Firefox','Opera','UC','QQ', 'QQin', 'BaiDu','Maxthon','SouGou','LBBROWSER','Wechat'],
				os:['Windows','Linux','Mac','Android','iOS','WP','BlackBerry','MeeGo','Symbian'],
				device:['Mobile','Tablet']
			};
			_this.device = 'PC';
			_this.language = (function(){
				var g = (navigator.browserLanguage || navigator.language).toLowerCase();
				return g=="c"?"zh-cn":g;
			})();
			for(var s in hash){
				for(var i=0;i< hash[s].length;i++){
					var value = hash[s][i];
					if(match[value]){
						_this[s] = value;
					}
				}
			}
			//版本信息
			var browserVersion = {
				'Chrome':function(){
					return u.replace(/^.*(Chrome|CriOS)\/([\d.]+).*$/,'$2');
				},
				'IE':function(){
					var v = u.replace(/^.*MSIE ([\d.]+).*$/,'$1');
					if(v==u){
						v = u.replace(/^.*rv:([\d.]+).*$/,'$1');
					}
					return v!=u?v:'';
				},
				'Firefox':function(){
					return u.replace(/^.*(Firefox|FxiOS)\/([\d.]+).*$/,'$2');
				},
				'Safari':function(){
					return u.replace(/^.*Version\/([\d.]+).*$/,'$1');
				},
				'Maxthon':function(){
					return u.replace(/^.*Maxthon\/([\d.]+).*$/,'$1');
				},
	            'SouGou':function(){
	                return u.replace(/^.*SogouMobileBrowser\/([\d.]+).*$/,'$1');
	            },
				'QQ':function(){
					return u.replace(/^.*(QQBrowser|QQ)\/([\d.]+).*$/,'$2');
				},
	            'QQin':function(){
	                return u.replace(/^.*QQ\/([\d.]+).*$/,'$1');
	            },
				'BaiDu':function(){
					return u.replace(/^.*(BIDUBrowser|baiduboxapp)[\s\/]([\d.]+).*$/,'$2');
				},
				'UC':function(){
					return u.replace(/^.*UCBrowser\/([\d.]+).*$/,'$1');
				},
				'Wechat':function(){
					return u.replace(/^.*MicroMessenger\/([\d.]+).*$/,'$1');
				}
			};
			_this.browserVersion = '';
			if(browserVersion[_this.browser]){
				_this.browserVersion = browserVersion[_this.browser]();
			}

			var osVersion = "";
			switch (_this.os) {
	            case 'Mac':
	            	if(/Mac OS X ([\.\_\d]+)/.exec(u)) {
	                    osVersion = /Mac OS X ([\.\_\d]+)/.exec(u)[1];
	                }
	                break;

	            case 'Android':
	            	if(/Android ([\.\_\d]+)/.exec(u)) {
	                    osVersion = /Android ([\.\_\d]+)/.exec(u)[1];
	                }
	                break;

	            case 'iOS':
	            	if(/OS ([\.\_\d]+) like Mac OS X?/.exec(u)) {
	                    osVersion = /OS ([\.\_\d]+) like Mac OS X?/.exec(u)[1];
	                }
	                break;

	        }
	        _this.osVersion = osVersion.replace(/_/g,".");

	        var deviceType = _this.os;
	        switch (_this.os) {
	            case 'Android':
	            	if(/;\s*([^;]+[^\s;])\s*;?\s*Build/.exec(u)) {
	                    deviceType = /;\s*([^;]+[^\s;])\s*;?\s*Build/.exec(u)[1];
	                }
	                break;
				case 'iOS':
					var a = ["iPhone", "iPad", "iPod"];
					for(i = 0; i < a.length; i++) {
						match[a[i]] && (deviceType = a[i]);
					}
	                break;

	        }
	        _this.deviceType = deviceType;
			return _this;
		}
	};
	var commonS = {
		// 简单提示控制
		tip: function(text) {
	    $(".brief-tip-pop .con").html(text);
	    $(".brief-tip-pop").fadeIn(500).delay(1000).fadeOut(500);
		},
		btnTimeOutControl: function(ele, cls, timeoutClient, timeout) {
	    clearTimeout(timeoutClient);
	    timeoutClient = setTimeout(function() {
	        $(ele).addClass(cls);
	    }, timeout || 2000);
		},
		loadingToggle: function(ifShow) {
			if(ifShow) {
	            $(".loading-mask").show();
			} else {
	            $(".loading-mask").hide();
			}

		},
		popTip: function (text) {
	    $(".common-pop-tip-zone .tip1").html(text);
	    $(".common-pop-tip-zone").show().siblings().hide();
	    $(".mask").show();
	  },
	  popControl: function(popParentClass, popClass, popTitle, hideClose) {
	      $(popParentClass).show().siblings().hide();
	      $(popClass).show().siblings().hide();
	      popTitle && $(popParentClass + " .pop-title").html(popTitle);
	      hideClose ? $(popParentClass + " .close-pop").hide() : $(popParentClass + " .close-pop").show();
	      $(".mask").show();
	      // alert("mask"+$(".mask").height()+"pop-bg top"+$(".pop-bg-small").offset().top + "pop-small-height"+$(".pop-bg-small").height()+"window.screen.availHeight"+window.screen.availHeight+"screen height"+window.screen.height);
	  },
	};
    window.NMRTCommonM = commonM;
	window.NMRTCommonC = commonC;
	window.NMRTCommonS = commonS;
})();