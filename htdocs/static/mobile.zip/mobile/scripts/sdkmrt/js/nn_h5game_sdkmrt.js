(function() {
    var pubkey, encrypt;
    pubkey = "-----BEGIN PUBLIC KEY-----"
        + "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4h7DNhpOBaHDrK51CEizEFGQ6"
        + "sWhRFPdAj/k1BAvYPMpkqKRak1unHE3QOKDq5Fo4CJs7gbPNU+m13tudfU7oXs9l"
        + "L26ZgDDvIJP9ogZdg4uH0Z3o40QUtkE8eQ1PfA1I2zwxWWq/nqNmZZk4rfT8W+cx"
        + "jqyt8YdkOv/ARXRuCwIDAQAB"
        + "-----END PUBLIC KEY-----";
    var encrypt = new JSEncrypt();
    encrypt.setPublicKey(pubkey);
    window.encrypt = encrypt;
    var commonM, commonC, commonS;
    var beforeGameInterval;
    var NMRTSDK = {
        va: {
            apiPre: "//ins.66173yx.com/",
            initCb: function(){},
            loginCb: function(){},
            logoutCb: function(){},
            payCb: function(){},
            sdfConfIndex: null,
            sdkInited: false,
            _du: false,
            isLocal: false,
            hasLS: window.localStorage ? true : false,
            nSid: window.localStorage && localStorage.getItem("nSid") || null
        },
        noop: function() {},
        isSdkInited: function() {
            return this.va.sdkInited;
        },
        login: function(cb) {
            var c = this;
            if(!c.isSdkInited()) {
                console.log("sdk尚未完成初始化");
                return false;
            }
            commonM.isFunction(cb) && (c.va.loginCb = cb);
            window.pltLogin && pltLogin();
        },
        loginCb: function() {
            var c  =this;
            commonM.ajax({
                url: c.va.apiPre + "h5_super_api.php?act=login",
                dataType: "text",
                type: "post"
            });
            c.reportDevice();
        },
        setLogoutCb: function(cb) {
            var c = this;
            if(!c.isSdkInited()) {
                console.log("sdk尚未完成初始化");
                return false;
            }
            commonM.isFunction(cb) && (c.va.logoutCb = cb);
        },
        showFloatBall: function() {
            var c = this;
            if(!c.isSdkInited()) {
                console.log("sdk尚未完成初始化");
                return false;
            }
            window.pltShowFloatBall && pltShowFloatBall();
        },
        hideFloatBall: function() {
            var c = this;
            if(!c.isSdkInited()) {
                console.log("sdk尚未完成初始化");
                return false;
            }
            window.pltHideFloatBall && pltHideFloatBall();
        },
        // 支付
        pay: function(data, cb){

            var c = this;

            data["platform"] = commonC.uaObj.platform;
            var dataClone = $.extend({},data);
            if(!c.isSdkInited()) {
                console.log("sdk尚未完成初始化");
                return false;
            }
            if(!commonM.isPureObject(data)) {
                alert("支付信息格式不对！");
                return false;
            }
            commonM.isFunction(cb) && (c.va.payCb = cb);
            var checkResult = commonM.checkEntityKey(data, commonC.payKeyMap, "支付:");
            if(checkResult.status == false) {
                commonM.log("",checkResult.msg,commonM.LOGLEVEL.ERROR, true);
            }else {
                commonM.log("支付成功调用:",JSON.stringify(data),commonM.LOGLEVEL.INFO,true);
            }
            for(i in dataClone) {
                dataClone[i] = encodeURIComponent(encrypt.encrypt(String(dataClone[i])));
            }
            // if(c.va.isLocal) {
            //     window.pltGoPay && pltGoPay(data, {});
            //     return false;
            // }
            commonM.ajax({
                url: window.NMRTSDKMAP[c.va.sdfConfIndex].payUrl || "",
                type: "post",
                dataType: "json",
                data: dataClone,
                success: function(res) {
                    commonS.loadingToggle(false);
                    commonM.log("支付返回:", res);
                    var data2 = res.data || {};
                    if(res.result == 1) {
                        window.pltGoPay && pltGoPay(data, data2);
                    }
                    else {
                        commonS.popTip(res.desc);
                    }
                },
                error: function(res2) {
                    commonS.loadingToggle(false);
                    commonS.tip("请求出错："+res2.status+","+res2.statusText);
                }
            });
        },
        //角色信息报道
        roleReport: function(data){
            console.log('角色信息报道')
            var c = this;
            if(!c.isSdkInited()) {
                console.log("sdk尚未完成初始化");
                return false;
            }
            if(!commonM.isPureObject(data)) {
                commonM.log("角色报道信息格式不对！");
                return false;
            }
            var checkResult = commonM.checkEntityKey(data, commonC.roleKeyMap, "角色报道:");
            if(checkResult.status == false) {
                commonM.log("角色报道传参有误:",checkResult.msg,commonM.LOGLEVEL.ERROR);
            }else {
                commonM.log("角色报道成功调用:",JSON.stringify(data));
            }
            window.pltRoleReport && pltRoleReport(data);
            commonM.setUaObj({
                roleName: data.roleName,
                roleId: data.roleId,
                roleLevel: data.roleLevel,
                serverId: data.serverId,
                serverName: data.serverName,
                roleReportType: data.roleReportType,
                roleCreatedTime: data.roleCreatedTime,
                roleLevelMTime: data.roleLevelMTime,
                power: data.power,
                partyName: data.partyName,
                guildId: data.guildId,
                guildName: data.guildName,
                guildLevel: data.guildLevel,
                guildLeaderId: data.guildLeaderId,
                roleAttachParams: data.roleAttachParams,
                restCoinNum: data.restCoinNum
            });
            commonM.ajax({
                url: c.va.apiPre + "h5_super_api.php?act=role",
                type: "post",
                dataType: "text"
            });
            console.log('nn角色通知')
        },
        reportDevice: function() {
            var c = this;
            console.log(commonC.uaObj);
            commonM.ajax({
                url: c.va.apiPre + "h5_super_api.php?act=device",
                type: "post",
                dataType: "text"
            });
        },
        getSdkConfig: function(sdks) {
            var c = this;
            var i, sdk, len = sdks.length;
            for (i = 0; i < len; i++) {
                sdk = sdks[i];
                if (sdk != null && sdk.pfId == commonC.uaObj.platform) {
                    c.va.sdfConfIndex = i;
                    return sdk;
                }
            }
        },
        initSDK: function(sdk) {
            var c = this;
            var sdkSrc = c.va.isLocal ? sdk.sdkSrcLocal : sdk.sdkSrc;
            $.getScript(sdkSrc, function() {
                c.va.sdkInited = true;
                commonM.isFunction(c.va.initCb) && c.va.initCb();
            });
        },
        init: function(data, cb) {
            var c = this, sdk;
            $.getScript('//cdn.66173.cn/mobile/scripts/sdkmrt/js/comSet.js', function () {
                commonM = window.NMRTCommonM;
                commonC = window.NMRTCommonC;
                commonS = window.NMRTCommonS;
                var b = commonM.browserRel();
                var t = (new Date()).getTime();
                var platform = commonM.getQueryString("platform") || "huawei";
                if(commonM.getQueryString("isND") == 1) {
                    c.va._du = true;
                } else if(commonM.getQueryString("isND") == 2) {
                    c.va._du = false;
                } else {
                    c.va._du = data.debug ? true : false;
                }
                if(commonM.getQueryString("isNL") == 1) {
                    c.va.isLocal = true;
                } else if(commonM.getQueryString("isNL") == 2) {
                    c.va.isLocal = false;
                } else {
                    c.va.isLocal = data.isLocal ? true : false;
                }
                commonM.isFunction(cb) && (c.va.initCb = cb);
                if(c.va.hasLS && !localStorage.getItem("nSid")) {
                    var sid = t + '_' + parseInt(Math.random() * 10000);
                    localStorage.setItem("nSid", sid);
                    c.va.nSid = sid;
                }
                commonC.uaObj = {
                    system: b.os || "",
                    deviceType: b.deviceType || "",
                    osVer: b.osVersion || "",
                    browser: b.browser || "",
                    broswerVer: b.browserVersion || "",
                    lang: b.language || "",
                    sdkVer: "1.0.0.1",
                    platform: platform,
                    appId: data.appId,
                    timestamp: t,
                    safety: md5(data.appId+data.channel+t),
                    sid: c.va.nSid || t + '_' + parseInt(Math.random() * 10000)
                };
                commonC.infoObj = {
                    browserRel: b
                };
                if(platform) {
                    sdk = c.getSdkConfig(window.NMRTSDKMAP);
                    if (sdk) {
                        c.initSDK(sdk);
                    }
                } else {
                    alert(" 无渠道 ")
                }
                if(platform =='zhijian'){
                    $.getScript('//sdk.zhijiangames.com/channelsdk/sbpulsdk.js?v=1209', function () {
                        SbPulSdk = window.SbPulSdk;
                    })
                }
                if(platform =='hjy'){
                    $.getScript('//wap.hjygame.com/sdk/cy.sdk.js', function () {
                        sdk = window.sdk;
                    })
                }
                if(platform =='tianxing'){
                    $.getScript('//h5.tianxinghd.com/Public/static/xigusdk/xgh5sdk.js', function () {
                        tianxing = new GameXG;
                    })
                }
                if(platform =='xunrui'){
                    $.getScript('//www.3500.com/statics/js/lib.v1.js', function () {
                        xunrui = new Game35({
                            uid: commonM.getQueryString("uid"),			//用户id
                            token: commonM.getQueryString("token")		// 3500用户 token，登录口令
                        });
                    })
                }
                // if(platform =='lanmo'){
                //     $.getScript('//www.jxw123.com/js/h5sdk.v1.js', function () {
                //         jxwSv = new JxwSv({
                //             uid: commonM.getQueryString("uid"),			//用户id
                //             token: commonM.getQueryString("token")		// 蓝魔用户 token，登录口令
                //         });
                //     })
                // }
                setTimeout(function () {
                    c.reportDevice();
                }, 500);
            })
        }
    };
    window.NMRTSDK = NMRTSDK;

})();