function pltLogin() {
    window.parent.postMessage({
        action: "cp_t_login"
    },"*");
}
function pltLogoutCb() {
    NMRTSDK.va.logoutCb();
}
function pltShowFloatBall() {
    window.parent.postMessage({
        action: "cp_show_float"
    },"*");
}
function pltHideFloatBall() {
    window.parent.postMessage({
        action: "cp_hide_float"
    },"*");
}
function setPlayerId(data) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = data.userId;
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: data.userId,
        appId: o.appId,
        token: data.token
    })
    NMRTSDK.loginCb();
}
function pltGoPay(data, data2) {
    alert("调用牛牛订单接口");
}

(function() {
    var nsdk = {
        _registerReceiveMessage: function() {
            window.addEventListener("message", function(e) {
                var data = e.data || {};
                var info = data.info;
                switch (data.action) {
                    case "cp_cb_du":
                        if(info == false) {
                            NMRTSDK.va._du = false;
                        }
                        break;
                    case "cp_cb_login":
                        setPlayerId(info);
                        break;
                    case "cp_cb_logoutCb":
                        pltLogoutCb(info);
                        break;
                    case "cp_cb_pay":
                        setPayResult(info);
                        break;
                    case "cp_cb_t_login":
                        window.parent.postMessage({
                            action: "cp_login"
                        },"*");
                        break;
                    default:
                        return
                }
            }, false)
        },
        pltInit: function(du) {
            NMRTSDK.va._du = du ? true : false;
            this._registerReceiveMessage();
            window.parent.postMessage({
                action: "cp_ready"
            }, "*")
        }
    }
    nsdk.pltInit(NMRTSDK.va._du);


})();
