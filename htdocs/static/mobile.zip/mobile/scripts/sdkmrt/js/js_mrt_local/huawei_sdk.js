function pltLogin() {
    setPlayerId("测试用户id","测试渠道appId",1523863748147,"aaa");
}
function pltShowFloatBall() {
    alert("显示悬浮球");
}
function pltHideFloatBall() {
    alert("华为暂无隐藏悬浮球接口");
}
function setPlayerId(playerId, appId, ts, sign) {
    var o = NMRTCommonC.uaObj || {};
    o.userId = playerId;
    NMRTSDK.loginCb();
    var token = window.md5 && md5("userId=" + playerId + "&platformAppId=" + appId + "&ts=" + ts + "&sign=" + sign);
    NMRTSDK.va.loginCb({
        platform: o.platform,
        userId: playerId,
        appId: o.appId,
        token: token
    })
}

function pltGoPay(data, data2) {
    alert("调用华为订单接口");
}
function logout() {
    NMRTSDK.va.logoutCb();
}