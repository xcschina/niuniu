var wrapObj = {
	init: function() {
		var c = this;
		window.addEventListener("message", function(e) {
			var data = e.data || {};
		    var info = data.info;
		    switch (data.action) {
		    		case 'cp_login':
		    			c.login();
		    			break;
		        case 'cp_pay': 
		        	c.pay(info);
		          break;
		       	case 'cp_roleReport':
		       		c.roleReport(info);
		       		break;
		       	case 'cp_show_float':
		       		c.showFloatBall();
		       		break;
		       	case 'cp_hide_float':
		       		c.hideFloatBall();
		       		break;
            case 'cp_ready':
              c.duSet();
              break;
            case 'cp_t_login':
            	c.tLogin();
            	break;
		        default : 
		          return
		    }
		}, false);
	},
	logPre: function() {
		var ua = commonC.uaObj;
		if(!ua.userId) {
			$("#touchZone").hide();
			commonS.popControl(".pop-login-rel", ".block-login", "游戏登录", true);
			return false;
		}
		return true;
	},
	login: function() {
		var c = this;
		var ua = commonC.uaObj;
		var isLogin = c.logPre();
		if(!isLogin) {
			return false;
		}
		$("#touchZone").show();
		var a = document.getElementById("gameFrame");
		a && a.contentWindow.postMessage({
			action: "cp_cb_login",
			info: {
				platform: ua.platform,
				userId: ua.userId,
				appId: ua.appId,
				token: ua.token
			}
		}, "*")
		
	},
	pay: function(data){
		var c = this;
		var isLogin = c.logPre();
		if(!isLogin) {
			return false;
		}
		if(!commonM.isPureObject(data)) {
			commonS.tip("支付信息格式不对！");
			return false;
		}
	 	data.way = "2";
    data.userName = commonC.uaObj.userName;
	 	data.channel = commonC.uaObj.channel;
	 	commonM.log("支付信息", data);
	 	for(i in data) {
	 		data[i] = typeof data[i] == "string" ? data[i] : JSON.stringify(data[i]);
	 		data[i] = encodeURIComponent(encrypt.encrypt(data[i]));
	 	}
    if(commonC.uaObj.browser != "Wechat") {
    	commonS.popTip("支付功能开发中，请通过微信打开，体验更全功能");
    } else {
    	commonS.loadingToggle(true);
		 	commonM.ajax({
		 		url: "wx_h5_pay.php",
		 		type: "post",
		 		dataType: "text",
		 		data: data,
		 		success: function(res) {
	       	commonS.loadingToggle(false);
		 			commonM.log("支付返回:", res);
			 		var data = res.data || {};
			 		if(res.result == 1) {
			 			window.WeixinJSBridge && WeixinJSBridge.invoke(
				            'getBrandWCPayRequest',{
				                "appId":data.wxAppId,//微信公众号appId，由现在支付返回(在tn中)
				                "timeStamp":data.timeStamp,//时间戳，自1970年以来的秒数
				                "nonceStr":data.nonceStr,//随机串
				                "package":"prepay_id="+data.prepay_id,
				                "signType":data.signType,//微信签名方式:
				                "paySign":data.paySign//微信签名
				            }, function(res2) {
				            	//使用以上方式判断前端返回,微信团队郑重提示:res.err_msg将在用户支付成功后返回ok，但并不保证它绝对可靠。
				            	if(res2.err_msg == "get_brand_wcpay_request:ok"){
				            		briefTipControl("充值成功");
				            	}
				            })
				    } else {
	                    commonS.popTip(res.desc);
					}
		 		},
				error: function(res2) {
	        commonS.loadingToggle(false);
	        commonS.tip("请求出错："+res2.status+","+res2.statusText);
	      }
		 	});
		}
 		// document.getElementById("gameFrame").contentWindow.postMessage({action: "cp_pay_cb",info: res}, "*");
	} ,
	 //角色信息报道
	roleReport: function(data){
		var c = this;
		var isLogin = c.logPre();
		if(!isLogin) {
			return false;
		}
	 	commonM.setUaObj({
	 		roleName: data.roleName,
	 		roleId: data.roleId,
	 		roleLevel: data.roleLevel,
	 		serverId: data.serverId,
	 		serverName: data.serverName
	 	});
	 	// todo post data
	 	commonM.ajax({
	 		url: "h5_api.php?act=role",
	 		type: "post",
	 		dataType: "text"
	 	});
	},
	showFloatBall: function() {
		var c = this;
		var isLogin = c.logPre();
		if(!isLogin) {
			return false;
		}
		$("#touchZone").show();
	},
	hideFloatBall: function() {
		$("#touchZone").hide();
	},
	duSet: function() {
		if(_du == false) {
			var a = document.getElementById("gameFrame");
			a && a.contentWindow.postMessage({
				action: "cp_cb_du",
				info: false
			}, "*")
		}
  },
  tLogin: function() {
  	var ua = commonC.uaObj;
  	ua.userId = "测试userId";
  	var a = document.getElementById("gameFrame");
		a && a.contentWindow.postMessage({
			action: "cp_cb_t_login",
			info: false
		}, "*")
  }
};
wrapObj.init();