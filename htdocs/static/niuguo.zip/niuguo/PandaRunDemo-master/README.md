# PandaRunDemo
游戏使用creator开发，支持无限跑，速度逐渐加快，可以收集金币。AD左右移动，J支持二段跳。
游戏一开始没焦点，需要用鼠标点一下游戏。
试玩地址：
https://github.com/maikx2333/PandaRunDemo/blob/master/build/web-desktop/index.html
