$(document).ready(function(){
    $("#sidebar-menu ul.list-unstyled a").click(function(){sidebar_menu_load($(this).attr("data-url"));});
    //frameSet();
    // $("a.menu").click(function(){
    //     $(this).next("div").toggle("fast");
    //     menuToggle(this);
    //     if($(this).attr("href")=="#;"){
    //         return false;
    //     }
    // });
    // $("a").bind("focus",function() {
    //     if(this.blur) {this.blur()};
    // });
    // msgbox();
    //$(window).resize(function() {setTimeout("frameSet()",500);});
    $("button[type='button']").click(function () {
        alert('test');
        return false;
    });
    // $('[data-toggle="ajaxform"]').on('submit', function(e) {
    //     $(this).ajaxSubmit(function() {
    //         //$('#output2').html("提交成功！欢迎下次再来！").show();
    //         alert('test');
    //     });
    //     e.preventDefault();
    // });
});
function frameSet(){
    if($.browser.msie){
        w = document.body.clientWidth-206;
    }else{
        w = document.body.clientWidth-206;
    }
    h = document.documentElement.clientHeight;
    // $("div#menu_bar").css("height",h+"px");
    // $("div#main").css("height",h+"px");
    // $("div#trigger").css("height",(h+1)+"px");
    // $("#main_data").css("width",w+"px");
    // $("#main").css("width",w+"px");
    $("#main_data").css("height",(h-65)+"px");
}
function sidebar_menu_load(url) {
    $("#main_data").load(url,function(){ $("#main_data").fadeIn(100);});
    return false;
}
$(function() {
    $(document).on("submit","form", function() {
        if($(this).attr("data-toggle")=='ajaxform'){
            $(this).ajaxSubmit({
                beforeSubmit:function (formData, jqForm, options) {
                    console.log('before');
                },
                success: function (responseText,statusText) {
                    alert("返回值"+responseText);
                },
                error:function (result) {
                    alert("发生错误,HTTP代码:"+result.status);
                    alert(result.responseText);
                }
            });
            //关闭模态窗口
            if(target = $(this).attr("data-animation")){
                $('#'+target).modal('hide');
            }
            return false;
        }
    });
});